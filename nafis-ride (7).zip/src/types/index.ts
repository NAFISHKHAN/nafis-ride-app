export type VehicleType = 'bike' | 'auto' | 'eriksha';

export type RideStatus =
  | 'idle'
  | 'searching'
  | 'captain_assigned'
  | 'arrived'
  | 'in_trip'
  | 'completed'
  | 'cancelled';

export interface LocationPoint {
  id: string;
  name: string;
  hindiName: string;
  lat: number;
  lng: number;
  landmark?: string;
  isOfficialZone: boolean;
}

export interface VehicleOption {
  type: VehicleType;
  name: string;
  hindiName: string;
  tagline: string;
  icon: string;
  capacity: number;
  baseFare: number;
  perKmRate: number;
  minFare: number;
  speedKmH: number;
}

export interface CaptainKycDoc {
  aadhaarNumber: string;
  aadhaarPhotoUrl: string;
  aadhaarBackPhotoUrl?: string;
  drivingLicenseNumber: string;
  dlPhotoUrl: string;
  dlExpiryDate?: string;
  dlClass?: string;
  rcNumber?: string;
  rcPhotoUrl?: string;
  insuranceNumber?: string;
  insurancePhotoUrl?: string;
  pucCertificateNumber?: string;
  profilePhotoUrl: string;
  vehicleRegistration: string;
  submittedAt: string;
  verificationNotes?: string;
}

export interface Captain {
  id: string;
  name: string;
  phone: string;
  email: string;
  vehicleType: VehicleType;
  vehicleModel: string;
  vehiclePlate: string;
  photoUrl: string;
  rating: number;
  totalTrips: number;
  isOnline: boolean;
  kycStatus: 'pending' | 'approved' | 'rejected';
  kycDocs?: CaptainKycDoc;
  walletBalance: number;
  todayEarnings: number;
  upiId: string;
  bloodGroup?: string;
  emergencyContact?: string;
  idCardIssuedDate?: string;
  idCardExpiryDate?: string;
  lat: number;
  lng: number;
  currentRideId?: string | null;
  joinedDate: string;
}

export interface PaymentDetails {
  method: 'upi_intent' | 'upi_qr' | 'cashless_wallet' | 'cash';
  utrNumber: string;
  paidAt: string;
  amount: number;
  captainCredit?: number; // 95%
  platformCommission?: number; // 5%
  appName?: string;
  payerName?: string;
  receiptId: string;
  webhookVerified?: boolean;
  transactionId?: string;
}

export interface Ride {
  id: string;
  riderId: string;
  riderName: string;
  riderPhone: string;
  captainId?: string;
  captainName?: string;
  captainPhone?: string;
  captainPhoto?: string;
  vehicleType: VehicleType;
  vehiclePlate?: string;
  vehicleModel?: string;
  pickupLocation: LocationPoint;
  dropLocation: LocationPoint;
  distanceKm: number;
  fare: number;
  estimatedMinutes: number;
  otp: string;
  status: RideStatus;
  paymentMethod: 'cash' | 'upi_qr' | 'upi_intent' | 'cashless_wallet';
  paymentStatus: 'pending' | 'paid';
  paymentDetails?: PaymentDetails;
  rating?: number;
  createdAt: string;
  arrivedAt?: string;
  startedAt?: string;
  completedAt?: string;
}

export interface UserProfile {
  id: string;
  name: string;
  phone: string;
  email: string;
  role: 'rider' | 'passenger' | 'captain' | 'admin';
  token: string;
  walletBalance?: number;
  isVerified?: boolean;
  savedPlaces?: { name: string; location: LocationPoint }[];
}

export interface SosAlert {
  id: string;
  rideId?: string;
  senderName: string;
  senderPhone: string;
  userName?: string;
  userPhone?: string;
  locationAddress?: string;
  role: 'passenger' | 'captain';
  coordinates: {
    lat: number;
    lng: number;
    address: string;
  };
  timestamp: string;
  status: 'active' | 'resolved';
  resolvedBy?: string;
  resolvedAt?: string;
  notes?: string;
  locationLink?: string;
  smsReceipt?: {
    messageId: string;
    recipient: string;
    status: string;
    deliveredAt: string;
    alertType: string;
  };
}

export interface FareSettings {
  bike: { baseFare: number; perKm: number; minFare: number };
  auto: { baseFare: number; perKm: number; minFare: number };
  eriksha: { baseFare: number; perKm: number; minFare: number };
  maxRideLimitKm: number;
  commissionPercentage: number;
  founderName: string;
  supportEmail: string;
  sosHelpline: string;
}
