import React, { useState, useEffect, useCallback } from 'react';
import {
  X,
  Clock,
  MapPin,
  Search,
  RefreshCw,
  Calendar,
  IndianRupee,
  Navigation,
  CheckCircle2,
  XCircle,
  RotateCcw,
  Receipt,
  ShieldCheck,
  ChevronRight,
  AlertCircle,
  Filter,
  User,
  Phone,
} from 'lucide-react';
import { Ride, LocationPoint, VehicleType } from '../../types';
import { rideStore } from '../../services/store';

interface MyTripsProps {
  isOpen: boolean;
  onClose: () => void;
  defaultPhone?: string;
  onSelectRebook?: (pickup: LocationPoint, drop: LocationPoint, vehicleType: VehicleType) => void;
}

export const MyTrips: React.FC<MyTripsProps> = ({
  isOpen,
  onClose,
  defaultPhone,
  onSelectRebook,
}) => {
  const userProfile = rideStore.getUserProfile();
  const initialPhone = defaultPhone || userProfile?.phone || '+91 98295 12044';

  const [phoneInput, setPhoneInput] = useState<string>(initialPhone);
  const [searchedPhone, setSearchedPhone] = useState<string>(initialPhone);
  const [trips, setTrips] = useState<Ride[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [activeFilter, setActiveFilter] = useState<'all' | 'completed' | 'other'>('all');
  const [selectedReceiptRide, setSelectedReceiptRide] = useState<Ride | null>(null);

  const fetchTripsForPhone = useCallback(async (phoneToQuery: string) => {
    setIsLoading(true);
    setError(null);
    const cleaned = phoneToQuery.replace(/\D/g, '').slice(-10);

    try {
      const res = await fetch(`/api/rides/history?phone=${encodeURIComponent(cleaned)}`);
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}: Failed to fetch ride history`);
      }
      const data = await res.json();
      if (data && data.success && Array.isArray(data.history)) {
        setTrips(data.history);
      } else {
        // Fallback to local store
        const localHistory = rideStore.getRideHistory();
        const localFiltered = localHistory.filter((r) => {
          const rPhone = String(r.riderPhone || '').replace(/\D/g, '').slice(-10);
          return rPhone === cleaned;
        });
        setTrips(localFiltered);
      }
      setSearchedPhone(phoneToQuery);
    } catch (err: any) {
      console.warn('[MyTrips] Backend fetch fallback to store:', err);
      // Fallback to local store history
      const localHistory = rideStore.getRideHistory();
      const localFiltered = localHistory.filter((r) => {
        const rPhone = String(r.riderPhone || '').replace(/\D/g, '').slice(-10);
        return rPhone === cleaned;
      });
      setTrips(localFiltered);
      setSearchedPhone(phoneToQuery);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    if (isOpen) {
      fetchTripsForPhone(phoneInput);
    }
  }, [isOpen, fetchTripsForPhone]);

  if (!isOpen) return null;

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneInput.trim()) return;
    fetchTripsForPhone(phoneInput);
  };

  const filteredTrips = trips.filter((t) => {
    if (activeFilter === 'completed') return t.status === 'completed';
    if (activeFilter === 'other') return t.status !== 'completed';
    return true;
  });

  const totalSpent = trips
    .filter((t) => t.status === 'completed' || t.paymentStatus === 'paid')
    .reduce((sum, t) => sum + (t.fare || 0), 0);

  const getVehicleLabel = (type: VehicleType) => {
    switch (type) {
      case 'bike':
        return { label: 'बाइक (Bike)', icon: '🛵', color: 'text-amber-400 bg-amber-500/10 border-amber-500/30' };
      case 'auto':
        return { label: 'ऑटो (Auto)', icon: '🛺', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30' };
      case 'eriksha':
        return { label: 'ई-रिक्शा (E-Rickshaw)', icon: '⚡', color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30' };
      default:
        return { label: type, icon: '🚗', color: 'text-slate-400 bg-slate-800 border-slate-700' };
    }
  };

  const getStatusBadge = (status: Ride['status']) => {
    switch (status) {
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>सफलतापूर्वक पूर्ण (Completed)</span>
          </span>
        );
      case 'in_trip':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-500/15 text-blue-400 border border-blue-500/30">
            <Navigation className="w-3.5 h-3.5 animate-spin" />
            <span>यात्रा में (In Trip)</span>
          </span>
        );
      case 'captain_assigned':
      case 'arrived':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-500/15 text-amber-400 border border-amber-500/30">
            <Clock className="w-3.5 h-3.5" />
            <span>कप्तान आ रहा है (Assigned)</span>
          </span>
        );
      case 'searching':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-cyan-500/15 text-cyan-400 border border-cyan-500/30">
            <Clock className="w-3.5 h-3.5 animate-pulse" />
            <span>सर्च जारी (Searching)</span>
          </span>
        );
      case 'cancelled':
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-800 text-slate-400 border border-slate-700">
            <XCircle className="w-3.5 h-3.5" />
            <span>रद्द की गई (Cancelled)</span>
          </span>
        );
    }
  };

  return (
    <div
      id="modal-my-trips"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-fadeIn"
    >
      <div className="relative w-full max-w-xl max-h-[90vh] bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl flex flex-col overflow-hidden text-slate-100">
        {/* Header */}
        <div className="flex-shrink-0 px-5 py-4 border-b border-slate-800 bg-slate-900/90 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center shadow-inner">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-100 flex items-center gap-2">
                <span>मेरी राइड्स (My Trips)</span>
                <span className="text-xs font-normal text-amber-400 px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20">
                  {trips.length} राइड्स
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                अलवर यात्रा इतिहास एवं ई-रसीद लेज़र (Alwar Ride History)
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            id="btn-close-my-trips"
            className="p-2 rounded-xl text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition-colors"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Filter Bar */}
        <div className="flex-shrink-0 p-4 border-b border-slate-800/80 bg-slate-950/50 space-y-3">
          <form onSubmit={handleSearchSubmit} className="flex items-center gap-2">
            <div className="relative flex-1">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
              <input
                type="text"
                id="input-my-trips-phone"
                value={phoneInput}
                onChange={(e) => setPhoneInput(e.target.value)}
                placeholder="मोबाइल नंबर से राइड खोजें..."
                className="w-full pl-9 pr-3 py-2 bg-slate-900 border border-slate-700 focus:border-amber-400 rounded-xl text-xs text-slate-100 placeholder-slate-500 focus:outline-none transition-colors"
              />
            </div>

            <button
              type="submit"
              id="btn-search-my-trips"
              disabled={isLoading}
              className="px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-colors disabled:opacity-50"
            >
              <Search className="w-3.5 h-3.5" />
              <span>खोजें</span>
            </button>

            <button
              type="button"
              onClick={() => fetchTripsForPhone(phoneInput)}
              id="btn-refresh-my-trips"
              disabled={isLoading}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
              title="रिफ्रेश करें (Refresh)"
            >
              <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin text-amber-400' : ''}`} />
            </button>
          </form>

          {/* Quick Metrics & Filter Chips */}
          <div className="flex items-center justify-between pt-1">
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setActiveFilter('all')}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-colors ${
                  activeFilter === 'all'
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'text-slate-400 hover:bg-slate-800'
                }`}
              >
                सभी ({trips.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveFilter('completed')}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-colors ${
                  activeFilter === 'completed'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'text-slate-400 hover:bg-slate-800'
                }`}
              >
                पूर्ण ({trips.filter((t) => t.status === 'completed').length})
              </button>
              <button
                type="button"
                onClick={() => setActiveFilter('other')}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-medium transition-colors ${
                  activeFilter === 'other'
                    ? 'bg-slate-700 text-slate-200 border border-slate-600'
                    : 'text-slate-400 hover:bg-slate-800'
                }`}
              >
                अन्य ({trips.filter((t) => t.status !== 'completed').length})
              </button>
            </div>

            {totalSpent > 0 && (
              <div className="text-right">
                <span className="text-[10px] text-slate-400 block">कुल व्यय (Total):</span>
                <span className="text-xs font-bold text-emerald-400">₹{totalSpent}</span>
              </div>
            )}
          </div>
        </div>

        {/* Trips List Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
          {isLoading ? (
            <div className="py-16 text-center space-y-3">
              <RefreshCw className="w-8 h-8 mx-auto text-amber-400 animate-spin" />
              <p className="text-sm font-medium text-slate-300">
                सर्वर से राइड इतिहास लोड हो रहा है...
              </p>
              <p className="text-xs text-slate-500">
                (Querying backend ledger for +91 {searchedPhone.replace(/\D/g, '').slice(-10)})
              </p>
            </div>
          ) : filteredTrips.length === 0 ? (
            <div className="py-14 text-center space-y-3 bg-slate-950/40 rounded-2xl border border-slate-800/80 p-6">
              <div className="w-12 h-12 rounded-2xl bg-slate-800/80 text-slate-400 flex items-center justify-center mx-auto">
                <Clock className="w-6 h-6" />
              </div>
              <h3 className="text-sm font-bold text-slate-200">
                कोई राइड इतिहास नहीं मिला (No Trips Found)
              </h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                मोबाइल नंबर <span className="text-amber-400 font-mono">+{searchedPhone}</span> पर कोई पिछली राइड पंजीकृत नहीं है।
              </p>
              <button
                type="button"
                onClick={() => {
                  setPhoneInput('+91 98295 12044');
                  fetchTripsForPhone('+91 98295 12044');
                }}
                className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-amber-400 border border-slate-700 transition-colors"
              >
                डेमो अलवर राइडर नंबर लोड करें (+91 98295 12044)
              </button>
            </div>
          ) : (
            filteredTrips.map((trip) => {
              const vehicle = getVehicleLabel(trip.vehicleType);
              return (
                <div
                  key={trip.id}
                  id={`trip-card-${trip.id}`}
                  className="bg-slate-850 bg-slate-900/90 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 rounded-2xl p-4 transition-all shadow-md space-y-3"
                >
                  {/* Card Header: Vehicle & Status & Fare */}
                  <div className="flex items-start justify-between gap-2 border-b border-slate-800/80 pb-3">
                    <div className="flex items-center gap-2.5">
                      <span className={`px-2.5 py-1 rounded-lg text-xs font-bold border flex items-center gap-1 ${vehicle.color}`}>
                        <span>{vehicle.icon}</span>
                        <span>{vehicle.label}</span>
                      </span>

                      <div className="flex items-center gap-1 text-slate-400 text-xs">
                        <Calendar className="w-3.5 h-3.5 text-slate-500" />
                        <span>{trip.createdAt || 'हाल ही में (Recent)'}</span>
                      </div>
                    </div>

                    <div className="text-right flex flex-col items-end">
                      <div className="text-base font-extrabold text-amber-400 flex items-center">
                        <span>₹{trip.fare}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 uppercase tracking-wider">
                        {trip.paymentMethod === 'cashless_wallet'
                          ? 'Nafis Wallet'
                          : trip.paymentMethod === 'upi_qr'
                          ? 'UPI QR'
                          : trip.paymentMethod === 'upi_intent'
                          ? 'Instant UPI'
                          : 'Cash'}
                      </span>
                    </div>
                  </div>

                  {/* Status Banner */}
                  <div className="flex items-center justify-between">
                    <div>{getStatusBadge(trip.status)}</div>
                    <span className="text-[10px] font-mono text-slate-500">ID: {trip.id}</span>
                  </div>

                  {/* Route Summary */}
                  <div className="bg-slate-950/60 rounded-xl p-3 border border-slate-800/60 space-y-2.5 text-xs">
                    <div className="flex items-start gap-2.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 mt-1 flex-shrink-0 shadow-sm shadow-emerald-400/40" />
                      <div className="flex-1">
                        <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
                          पिकअप (Pickup)
                        </p>
                        <p className="text-slate-200 font-medium leading-snug">
                          {trip.pickupLocation?.name || 'Alwar'}
                        </p>
                      </div>
                    </div>

                    <div className="pl-1 text-[11px] font-mono text-slate-400 flex items-center gap-2">
                      <span className="border-l-2 border-dashed border-slate-700 h-4 ml-0.5" />
                      <span className="text-amber-400/90 font-medium">
                        {trip.distanceKm ? `${trip.distanceKm} KM` : '3.5 KM'}
                      </span>
                      <span className="text-slate-600">•</span>
                      <span className="text-slate-400">~{trip.estimatedMinutes || 12} मिनट</span>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <span className="w-2.5 h-2.5 rounded-full bg-amber-400 mt-1 flex-shrink-0 shadow-sm shadow-amber-400/40" />
                      <div className="flex-1">
                        <p className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
                          ड्रॉप (Drop)
                        </p>
                        <p className="text-slate-200 font-medium leading-snug">
                          {trip.dropLocation?.name || 'Kati Ghati'}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Captain Details (if available) */}
                  {trip.captainName && (
                    <div className="flex items-center justify-between text-xs pt-1 px-1 text-slate-300">
                      <div className="flex items-center gap-2">
                        {trip.captainPhoto ? (
                          <img
                            src={trip.captainPhoto}
                            alt={trip.captainName}
                            referrerPolicy="no-referrer"
                            className="w-6 h-6 rounded-full object-cover border border-slate-700"
                          />
                        ) : (
                          <div className="w-6 h-6 rounded-full bg-slate-800 flex items-center justify-center text-[10px] font-bold text-amber-400">
                            {trip.captainName.charAt(0)}
                          </div>
                        )}
                        <div>
                          <span className="font-semibold text-slate-200">{trip.captainName}</span>
                          {trip.vehiclePlate && (
                            <span className="ml-1.5 text-[10px] text-slate-400 font-mono">
                              ({trip.vehiclePlate})
                            </span>
                          )}
                        </div>
                      </div>

                      <span className="text-[10px] text-emerald-400/90 font-medium">
                        88% कैप्टन / 12% नफीस
                      </span>
                    </div>
                  )}

                  {/* Card Action Buttons */}
                  <div className="pt-1 flex items-center justify-end gap-2">
                    <button
                      type="button"
                      id={`btn-view-receipt-${trip.id}`}
                      onClick={() => setSelectedReceiptRide(trip)}
                      className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-slate-100 text-xs font-semibold flex items-center gap-1.5 border border-slate-700 transition-colors"
                    >
                      <Receipt className="w-3.5 h-3.5 text-amber-400" />
                      <span>ई-रसीद (Receipt)</span>
                    </button>

                    {onSelectRebook && trip.pickupLocation && trip.dropLocation && (
                      <button
                        type="button"
                        id={`btn-rebook-${trip.id}`}
                        onClick={() => {
                          onSelectRebook(trip.pickupLocation, trip.dropLocation, trip.vehicleType);
                          onClose();
                        }}
                        className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 shadow-sm transition-colors"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>दोबारा बुक करें</span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Digital Receipt Modal Overlay (if selected) */}
        {selectedReceiptRide && (
          <div className="absolute inset-0 z-50 bg-slate-950/90 backdrop-blur-sm p-4 flex flex-col justify-center animate-fadeIn">
            <div className="bg-slate-900 border border-slate-700 rounded-2xl p-5 max-w-sm mx-auto w-full shadow-2xl space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-amber-500 flex items-center justify-center text-slate-950 font-black text-xs">
                    NR
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider">
                      नफीस राइड ई-रसीद (Receipt)
                    </h4>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {selectedReceiptRide.paymentDetails?.receiptId || `NR-REC-${selectedReceiptRide.id.slice(-5)}`}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedReceiptRide(null)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-2 text-xs">
                <div className="flex justify-between text-slate-400">
                  <span>तारीख व समय (Date):</span>
                  <span className="text-slate-200 font-mono">{selectedReceiptRide.createdAt}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>सवारी आईडी (Ride ID):</span>
                  <span className="text-slate-200 font-mono">{selectedReceiptRide.id}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>वाहन प्रकार (Vehicle):</span>
                  <span className="text-slate-200 uppercase font-semibold">{selectedReceiptRide.vehicleType}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>दूरी (Distance):</span>
                  <span className="text-slate-200">{selectedReceiptRide.distanceKm} KM</span>
                </div>
                <div className="border-t border-slate-800 pt-2 flex justify-between text-slate-300">
                  <span>कैप्टन को भुगतान (88% Payout):</span>
                  <span className="text-slate-200 font-bold">
                    ₹{Math.round(selectedReceiptRide.fare * 0.88)}
                  </span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>प्लेटफ़ॉर्म शुल्क (12% Fee):</span>
                  <span className="text-amber-400 font-bold">
                    ₹{Math.round(selectedReceiptRide.fare * 0.12)}
                  </span>
                </div>
                <div className="border-t border-slate-800 pt-2 flex justify-between text-sm font-bold text-emerald-400">
                  <span>कुल भुगतान (Total Fare):</span>
                  <span>₹{selectedReceiptRide.fare}</span>
                </div>
              </div>

              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-[11px] text-slate-400 space-y-1">
                <div className="flex justify-between">
                  <span>भुगतान माध्यम:</span>
                  <span className="text-slate-200 uppercase font-mono">{selectedReceiptRide.paymentMethod}</span>
                </div>
                {selectedReceiptRide.paymentDetails?.utrNumber && (
                  <div className="flex justify-between">
                    <span>UTR / Ref No:</span>
                    <span className="text-slate-200 font-mono text-[10px]">
                      {selectedReceiptRide.paymentDetails.utrNumber}
                    </span>
                  </div>
                )}
                <div className="text-[10px] text-slate-500 pt-1 border-t border-slate-900">
                  Helpline: +91 70236 08919 • Founder: Nafis Khan
                </div>
              </div>

              <button
                type="button"
                onClick={() => setSelectedReceiptRide(null)}
                className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 transition-colors"
              >
                बंद करें (Close)
              </button>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="flex-shrink-0 px-5 py-3 border-t border-slate-800 bg-slate-900/95 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-1.5 text-[11px]">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>100% सुरक्षित एवं प्रमाणित अलवर राइड लेज़र</span>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs transition-colors"
          >
            वापस जाएं (Done)
          </button>
        </div>
      </div>
    </div>
  );
};
