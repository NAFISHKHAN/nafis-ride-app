import React, { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  MapPin,
  Navigation,
  ShieldAlert,
  Clock,
  Sparkles,
  Phone,
  CheckCircle,
  AlertCircle,
  QrCode,
  Star,
  ChevronRight,
  RotateCcw,
  Volume2,
  Wallet,
  Receipt,
} from 'lucide-react';
import { AlwarMap } from '../map/AlwarMap';
import { LocationPoint, VehicleType } from '../../types';
import {
  OPERATIONAL_ZONES,
  VEHICLE_OPTIONS,
  FOUNDER_NAME,
  FOUNDER_TAGLINE,
  SUPPORT_EMAIL,
  MAX_RIDE_LIMIT_KM,
} from '../../data/constants';
import { rideStore, calculateFare, calculateDistanceKm, estimateDurationMinutes } from '../../services/store';
import { audioService } from '../../services/audioService';
import { CashlessPaymentModal } from '../payment/CashlessPaymentModal';
import { MyTrips } from './MyTrips';

interface PassengerHomeProps {
  onOpenSos: () => void;
  onOpenSplash: () => void;
}

export const PassengerHome: React.FC<PassengerHomeProps> = ({
  onOpenSos,
  onOpenSplash,
}) => {
  const [captains, setCaptains] = useState(rideStore.getCaptains());
  const [activeRide, setActiveRide] = useState(rideStore.getActiveRide());
  const settings = rideStore.getSettings();

  const [pickup, setPickup] = useState<LocationPoint>(OPERATIONAL_ZONES[0]); // Alwar Core
  const [drop, setDrop] = useState<LocationPoint>(OPERATIONAL_ZONES[5]); // Kati Ghati
  const [selectedVehicle, setSelectedVehicle] = useState<VehicleType>('bike');
  const [selectionMode, setSelectionMode] = useState<'pickup' | 'drop' | null>(null);

  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showQrModal, setShowQrModal] = useState(false);
  const [isCashlessModalOpen, setIsCashlessModalOpen] = useState(false);
  const [isMyTripsOpen, setIsMyTripsOpen] = useState(false);
  const [driverRating, setDriverRating] = useState<number>(5);
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false);

  useEffect(() => {
    const unsubscribe = rideStore.subscribe(() => {
      setCaptains([...rideStore.getCaptains()]);
      setActiveRide(rideStore.getActiveRide());
    });
    return unsubscribe;
  }, []);

  useEffect(() => {
    if (activeRide?.status === 'completed' && !feedbackSubmitted) {
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 },
        colors: ['#f59e0b', '#10b981', '#ffffff', '#eab308'],
      });
    }
  }, [activeRide?.status, feedbackSubmitted]);

  const currentDistance = calculateDistanceKm(pickup.lat, pickup.lng, drop.lat, drop.lng);
  const currentFare = calculateFare(currentDistance, selectedVehicle, settings);
  const currentEta = estimateDurationMinutes(currentDistance, selectedVehicle);
  const isDistanceExceeded = currentDistance > MAX_RIDE_LIMIT_KM;

  const handleBookRide = () => {
    setErrorMessage(null);
    const result = rideStore.createRideRequest(pickup, drop, selectedVehicle);
    if (!result.success) {
      setErrorMessage(result.error || 'Failed to book ride');
      audioService.playChime('sos');
    } else {
      audioService.playChime('booked');
    }
  };

  const handleCancel = () => {
    rideStore.cancelRide();
  };

  const handleCompletePaymentAndRate = () => {
    setFeedbackSubmitted(true);
    audioService.playChime('cash');
    setTimeout(() => {
      rideStore.dismissCompletedRide();
      setFeedbackSubmitted(false);
      setShowQrModal(false);
    }, 1500);
  };

  return (
    <div className="relative w-full h-full flex flex-col bg-slate-950 text-slate-100 overflow-hidden select-none">
      {/* Top App Header */}
      <header className="flex-shrink-0 z-20 bg-slate-900/95 border-b border-slate-800 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-amber-500 flex items-center justify-center font-extrabold text-slate-950 shadow-md">
            NR
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="font-extrabold text-base tracking-tight text-amber-400 leading-none">
                NAFIS RIDE
              </h1>
              <span className="text-[9px] bg-amber-500/20 text-amber-300 font-bold px-1.5 py-0.2 rounded border border-amber-500/30">
                ALWAR
              </span>
            </div>
            <p className="text-[10px] text-slate-400 leading-tight mt-0.5">
              Rapid, Affordable & Safe
            </p>
          </div>
        </div>

        {/* Action Header Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsMyTripsOpen(true)}
            id="btn-passenger-my-trips"
            className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 font-semibold text-xs border border-slate-700 flex items-center gap-1.5 shadow-sm transition-colors active:scale-95"
            title="मेरी राइड्स (My Trips)"
          >
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span>My Trips</span>
          </button>

          <button
            onClick={onOpenSos}
            id="btn-passenger-sos"
            className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs shadow-lg shadow-red-600/30 flex items-center gap-1.5 animate-pulse active:scale-95 transition-transform"
          >
            <ShieldAlert className="w-4 h-4" />
            <span>SOS 🆘</span>
          </button>
        </div>
      </header>

      {/* Main Map View Area */}
      <div className="relative flex-1 w-full min-h-[220px]">
        <AlwarMap
          pickupLocation={pickup}
          dropLocation={drop}
          captains={captains}
          activeVehicleType={selectedVehicle}
          selectionMode={selectionMode}
          onSelectLocation={(loc, mode) => {
            if (mode === 'pickup') setPickup(loc);
            else setDrop(loc);
            setSelectionMode(null);
          }}
        />

        <button
          onClick={() => {
            const temp = pickup;
            setPickup(drop);
            setDrop(temp);
          }}
          id="btn-swap-locations"
          title="Swap Pickup & Drop"
          className="absolute right-3 bottom-3 z-10 p-2.5 bg-slate-900/90 hover:bg-slate-800 border border-slate-700 text-amber-400 rounded-xl shadow-lg transition-transform active:rotate-180"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Bottom Booking & Trip Card Sheet */}
      <div className="flex-shrink-0 z-20 bg-slate-900 border-t border-slate-800 p-4 max-h-[55vh] overflow-y-auto">
        {activeRide && activeRide.status !== 'completed' ? (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span
                  className={`w-3 h-3 rounded-full ${
                    activeRide.status === 'searching'
                      ? 'bg-amber-400 animate-ping'
                      : activeRide.status === 'captain_assigned'
                      ? 'bg-cyan-400'
                      : activeRide.status === 'arrived'
                      ? 'bg-emerald-400 animate-bounce'
                      : 'bg-emerald-500'
                  }`}
                />
                <span className="text-xs font-bold uppercase tracking-wider text-amber-400">
                  {activeRide.status === 'searching' && '🔍 Searching for nearby Captain in Alwar...'}
                  {activeRide.status === 'captain_assigned' && '🛵 Captain Confirmed & Heading to You'}
                  {activeRide.status === 'arrived' && '📍 Captain Has Arrived at Pickup!'}
                  {activeRide.status === 'in_trip' && '🚀 On Trip to Destination...'}
                </span>
              </div>

              <div className="text-right">
                <span className="text-[10px] text-slate-400">Trip OTP: </span>
                <span className="text-sm font-black font-mono text-emerald-400 tracking-wider bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                  {activeRide.otp}
                </span>
              </div>
            </div>

            {activeRide.status === 'searching' && (
              <div className="py-4 text-center bg-slate-950/60 border border-slate-800 rounded-2xl flex flex-col items-center justify-center gap-2">
                <div className="relative w-16 h-16 flex items-center justify-center">
                  <div className="absolute inset-0 rounded-full bg-amber-500/20 animate-ping" />
                  <div className="w-10 h-10 rounded-full bg-amber-500/40 flex items-center justify-center text-amber-300 font-bold">
                    📡
                  </div>
                </div>
                <p className="text-xs text-amber-200 font-medium">
                  Scanning verified Alwar Captains within 5 KM...
                </p>
                <span className="text-[11px] text-slate-400">
                  Fair Rapido-style tariffs strictly applied
                </span>
              </div>
            )}

            {activeRide.status !== 'searching' && (
              <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-3.5 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <img
                    src={activeRide.captainPhoto || 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=200'}
                    alt="Captain"
                    className="w-12 h-12 rounded-xl object-cover border-2 border-amber-500 shadow-md"
                  />
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h3 className="font-bold text-sm text-slate-100">{activeRide.captainName}</h3>
                      <span className="text-[10px] bg-amber-500/20 text-amber-300 font-bold px-1.5 rounded">
                        ★ 4.9
                      </span>
                    </div>
                    <div className="text-xs font-mono font-bold text-amber-400 mt-0.5">
                      {activeRide.vehiclePlate}
                    </div>
                    <div className="text-[10px] text-slate-400">{activeRide.vehicleModel}</div>
                  </div>
                </div>

                <div className="flex flex-col items-end gap-1.5">
                  <a
                    href={`tel:${activeRide.captainPhone || '+919829000000'}`}
                    className="p-2.5 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-400 flex items-center gap-1 text-xs font-bold"
                  >
                    <Phone className="w-3.5 h-3.5" />
                    <span>Call</span>
                  </a>
                </div>
              </div>
            )}

            <div className="bg-slate-950/50 rounded-xl p-2.5 border border-slate-800/80 flex items-center justify-between text-xs">
              <div className="space-y-1">
                <div className="flex items-center gap-1 text-slate-300">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  <span className="font-medium truncate max-w-[140px]">{activeRide.pickupLocation.name}</span>
                </div>
                <div className="flex items-center gap-1 text-slate-300">
                  <span className="w-2 h-2 rounded-full bg-red-400" />
                  <span className="font-medium truncate max-w-[140px]">{activeRide.dropLocation.name}</span>
                </div>
              </div>
              <div className="text-right">
                <div className="text-base font-extrabold text-amber-400">₹{activeRide.fare}</div>
                <div className="text-[10px] text-slate-400">{activeRide.distanceKm} KM • {activeRide.estimatedMinutes} mins</div>
              </div>
            </div>

            {activeRide.status !== 'in_trip' && (
              <button
                onClick={handleCancel}
                id="btn-cancel-ride"
                className="w-full py-2.5 bg-slate-800 hover:bg-slate-700/80 text-rose-400 border border-rose-500/30 rounded-xl text-xs font-semibold"
              >
                राइड रद्द करें (Cancel Ride)
              </button>
            )}
          </div>
        ) : activeRide?.status === 'completed' ? (
          <div className="space-y-3.5 text-center">
            <div className="w-12 h-12 mx-auto rounded-full bg-emerald-500/20 border-2 border-emerald-500 flex items-center justify-center text-emerald-400">
              <CheckCircle className="w-6 h-6" />
            </div>

            <div>
              <h2 className="text-lg font-extrabold text-emerald-400">मंज़िल पर पहुँच गए! (Trip Completed)</h2>
              <p className="text-xs text-slate-300 mt-0.5">
                नफीस राइड चुनने के लिए शुक्रिया। आपका कुल देय किराया:
              </p>
            </div>

            <div className="bg-slate-950 border border-amber-500/40 rounded-2xl p-4">
              <div className="text-3xl font-black text-amber-400">₹{activeRide.fare}</div>
              <div className="text-xs text-slate-400 mt-1">
                {activeRide.distanceKm} KM • {activeRide.vehicleType.toUpperCase()}
              </div>

              <div className="mt-2">
                {activeRide.paymentStatus === 'paid' ? (
                  <span className="inline-flex items-center gap-1 text-[11px] px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold">
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>कैशलेस भुगतान प्राप्त (Paid via {activeRide.paymentDetails?.appName || 'UPI'})</span>
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 text-[11px] px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold">
                    <span>भुगतान बाकी (Pending Payment)</span>
                  </span>
                )}
              </div>

              <div className="mt-3 pt-3 border-t border-slate-800 flex flex-col gap-2">
                <button
                  onClick={() => setIsCashlessModalOpen(true)}
                  id="btn-open-cashless-payment"
                  className="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 font-black rounded-xl text-xs shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 active:scale-98 transition-all"
                >
                  <Wallet className="w-4 h-4" />
                  <span>
                    {activeRide.paymentStatus === 'paid'
                      ? 'डिजिटल टैक्स रसीद देखें (View Tax Invoice)'
                      : 'कैशलेस भुगतान करें (UPI Deep Link & Webhook)'}
                  </span>
                </button>

                <button
                  onClick={() => setShowQrModal(!showQrModal)}
                  className="flex items-center justify-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-xs font-bold rounded-xl"
                >
                  <QrCode className="w-4 h-4 text-amber-400" />
                  <span>{showQrModal ? 'QR कोड छुपाएं' : 'कप्तान का त्वरित UPI QR कोड देखें'}</span>
                </button>
              </div>

              {showQrModal && (
                <div className="mt-3 p-4 bg-white rounded-xl text-slate-950 flex flex-col items-center">
                  <img
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=upi://pay?pa=nafiskhan.ride@upi&pn=NafisRideCaptain&am=${activeRide.fare}&cu=INR`}
                    alt="Payment QR"
                    className="w-36 h-36 border-2 border-slate-300 rounded-lg p-1"
                  />
                  <span className="text-[11px] font-mono font-bold mt-2 text-slate-700">
                    Scan via PhonePe, GPay, Paytm
                  </span>
                  <span className="text-[10px] text-slate-500 font-semibold">
                    UPI ID: nafiskhan.ride@upi
                  </span>
                </div>
              )}
            </div>

            <div className="py-1">
              <p className="text-xs text-slate-300 mb-1.5">कप्तान को रेटिंग दें (Rate Captain):</p>
              <div className="flex justify-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => setDriverRating(star)}
                    className="p-1 text-xl"
                  >
                    <Star
                      className={`w-6 h-6 ${
                        star <= driverRating ? 'text-amber-400 fill-amber-400' : 'text-slate-600'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>

            <button
              onClick={handleCompletePaymentAndRate}
              id="btn-finish-payment"
              className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black rounded-xl shadow-lg shadow-emerald-500/20"
            >
              {feedbackSubmitted ? 'यात्रा समाप्त (Trip Finished)' : 'यात्रा पूर्ण & नई राइड (Done & Done)'}
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {errorMessage && (
              <div className="bg-red-950/80 border border-red-500 rounded-xl p-3 flex items-start gap-2 text-xs text-red-200">
                <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                <span>{errorMessage}</span>
              </div>
            )}

            <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-3 space-y-2.5">
              <div className="flex items-center gap-2.5">
                <div className="w-3 h-3 rounded-full bg-emerald-400 ring-4 ring-emerald-400/20 flex-shrink-0" />
                <div className="flex-1">
                  <label className="text-[10px] text-slate-400 block font-medium">
                    पिकअप लोकेशन (Pickup)
                  </label>
                  <select
                    value={pickup.id}
                    onChange={(e) => {
                      const found = OPERATIONAL_ZONES.find((z) => z.id === e.target.value);
                      if (found) setPickup(found);
                    }}
                    className="w-full bg-transparent text-xs font-bold text-slate-100 focus:outline-none cursor-pointer"
                  >
                    {OPERATIONAL_ZONES.map((zone) => (
                      <option key={zone.id} value={zone.id} className="bg-slate-900 text-white">
                        {zone.name}
                      </option>
                    ))}
                  </select>
                </div>
                <button
                  onClick={() => setSelectionMode('pickup')}
                  className={`text-[10px] px-2 py-1 rounded border font-semibold ${
                    selectionMode === 'pickup'
                      ? 'bg-emerald-500 text-slate-950 border-emerald-400'
                      : 'bg-slate-800 text-slate-300 border-slate-700'
                  }`}
                >
                  Map Pick
                </button>
              </div>

              <div className="h-[1px] bg-slate-800 ml-6" />

              <div className="flex items-center gap-2.5">
                <div className="w-3 h-3 rounded-full bg-red-400 ring-4 ring-red-400/20 flex-shrink-0" />
                <div className="flex-1">
                  <label className="text-[10px] text-slate-400 block font-medium">
                    ड्रॉप लोकेशन (Drop Destination)
                  </label>
                  <select
                    value={drop.id}
                    onChange={(e) => {
                      const found = OPERATIONAL_ZONES.find((z) => z.id === e.target.value);
                      if (found) setDrop(found);
                    }}
                    className="w-full bg-transparent text-xs font-bold text-slate-100 focus:outline-none cursor-pointer"
                  >
                    {OPERATIONAL_ZONES.map((zone) => (
                      <option key={zone.id} value={zone.id} className="bg-slate-900 text-white">
                        {zone.name}
                      </option>
                    ))}
                  </select>
                </div>
                <button
                  onClick={() => setSelectionMode('drop')}
                  className={`text-[10px] px-2 py-1 rounded border font-semibold ${
                    selectionMode === 'drop'
                      ? 'bg-red-500 text-white border-red-400'
                      : 'bg-slate-800 text-slate-300 border-slate-700'
                  }`}
                >
                  Map Pick
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between px-1">
              <div className="flex items-center gap-1.5 text-xs text-slate-400">
                <Clock className="w-3.5 h-3.5 text-amber-400" />
                <span>Est: {currentEta} mins ({currentDistance} KM)</span>
              </div>

              <div
                className={`text-[11px] px-2.5 py-0.5 rounded-full font-bold border ${
                  isDistanceExceeded
                    ? 'bg-red-950 text-red-400 border-red-600'
                    : 'bg-emerald-950/60 text-emerald-400 border-emerald-500/40'
                }`}
              >
                {isDistanceExceeded
                  ? `Exceeds ${MAX_RIDE_LIMIT_KM}KM Max Limit`
                  : `Within Safe ${MAX_RIDE_LIMIT_KM}KM Zone`}
              </div>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {VEHICLE_OPTIONS.map((v) => {
                const fare = calculateFare(currentDistance, v.type, settings);
                const isSelected = selectedVehicle === v.type;
                return (
                  <button
                    key={v.type}
                    onClick={() => setSelectedVehicle(v.type)}
                    className={`relative p-2.5 rounded-xl border text-left flex flex-col justify-between transition-all ${
                      isSelected
                        ? 'bg-amber-500/15 border-amber-400 shadow-md ring-1 ring-amber-400'
                        : 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xl">{v.icon}</span>
                      <span className="text-xs font-black text-amber-400">₹{fare}</span>
                    </div>
                    <div>
                      <div className="text-[11px] font-extrabold text-slate-200 leading-tight">
                        {v.name}
                      </div>
                      <div className="text-[9px] text-slate-400 mt-0.5 leading-none">
                        ₹{settings[v.type].baseFare} + ₹{settings[v.type].perKm}/km
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            <button
              onClick={handleBookRide}
              disabled={isDistanceExceeded}
              id="btn-confirm-booking"
              className={`w-full py-3.5 rounded-xl font-black text-sm flex items-center justify-center gap-2 shadow-lg transition-transform active:scale-[0.99] ${
                isDistanceExceeded
                  ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
                  : 'bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 shadow-amber-500/20'
              }`}
            >
              <span>{selectedVehicle.toUpperCase()} बुक करें (Book for ₹{currentFare})</span>
              <ChevronRight className="w-4 h-4" />
            </button>

            <div className="pt-2 border-t border-slate-800/80 text-center space-y-1">
              <div className="flex items-center justify-center gap-2 text-[11px] text-slate-400">
                <button
                  onClick={onOpenSplash}
                  className="hover:text-amber-400 underline flex items-center gap-1"
                >
                  <Navigation className="w-3 h-3 text-amber-400" />
                  <span>नफीस राइड गाइड (Overview)</span>
                </button>
                <span>•</span>
                <a href={`mailto:${SUPPORT_EMAIL}`} className="hover:text-amber-400 underline">
                  Support
                </a>
              </div>
              <p className="text-[10px] font-bold text-amber-400 tracking-wide">
                {FOUNDER_TAGLINE}
              </p>
            </div>
          </div>
        )}
      </div>

      {activeRide && (
        <CashlessPaymentModal
          isOpen={isCashlessModalOpen}
          onClose={() => setIsCashlessModalOpen(false)}
          ride={activeRide}
        />
      )}

      <MyTrips
        isOpen={isMyTripsOpen}
        onClose={() => setIsMyTripsOpen(false)}
        defaultPhone={rideStore.getUserProfile()?.phone}
        onSelectRebook={(p, d, v) => {
          setPickup(p);
          setDrop(d);
          setSelectedVehicle(v);
        }}
      />
    </div>
  );
};
