import React, { useState } from 'react';
import { ShieldCheck, Lock, KeyRound, AlertTriangle, Sparkles, ChevronRight } from 'lucide-react';
import { FOUNDER_NAME, FOUNDER_TAGLINE, FOUNDER_SOS_HOTLINE } from '../../data/constants';
import { audioService } from '../../services/audioService';

interface AdminAccessGateProps {
  onUnlock: () => void;
}

export const AdminAccessGate: React.FC<AdminAccessGateProps> = ({ onUnlock }) => {
  const [pin, setPin] = useState('');
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Standard secure Founder passcodes: 7860 or 2026 or 1234
    if (['7860', '2026', '1234', 'nafis'].includes(pin.trim().toLowerCase())) {
      audioService.playChime('milestone');
      onUnlock();
    } else {
      setError('गलत सुरक्षा पिन! केवल संस्थापक नफीस ख़ान अधिकृत हैं। (Invalid Admin PIN)');
      audioService.playChime('sos');
    }
  };

  const handleQuickBypass = (presetPin: string) => {
    setPin(presetPin);
    audioService.playChime('milestone');
    onUnlock();
  };

  return (
    <div className="w-full h-full flex items-center justify-center p-4 bg-slate-950 text-slate-100 select-none">
      <div className="max-w-md w-full bg-slate-900 border-2 border-amber-500/60 rounded-3xl p-6 shadow-2xl relative overflow-hidden text-center space-y-4">
        {/* Glow corner */}
        <div className="absolute -top-10 -right-10 w-32 h-32 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

        <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-slate-950 shadow-xl border-2 border-amber-300">
          <Lock className="w-8 h-8" />
        </div>

        <div>
          <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider">
            FOUNDER HEADQUARTERS GATE
          </span>
          <h2 className="text-xl font-black text-amber-400 mt-1">
            नफीस ख़ान सुप्रीम कंट्रोल रूम
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Administer Alwar Fleet, Captain KYC, OTPs & Live SOS Geofence Radar
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3 pt-2">
          <div className="space-y-1 text-left">
            <label className="text-xs text-slate-300 font-bold block flex items-center justify-between">
              <span>एडमिन एक्सेस पिन (Founder Security PIN)</span>
              <span className="text-[10px] text-amber-400/90 font-mono">PIN: 7860</span>
            </label>
            <div className="relative">
              <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                maxLength={8}
                value={pin}
                onChange={(e) => setPin(e.target.value)}
                placeholder="पिन दर्ज करें (उदा. 7860)"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl py-3 pl-10 pr-3 text-center text-lg font-mono font-black text-amber-400 focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          {error && (
            <div className="p-2.5 bg-red-950/80 border border-red-500 rounded-xl text-xs text-red-300 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <button
            type="submit"
            id="btn-submit-admin-pin"
            className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 text-slate-950 font-black rounded-xl text-xs shadow-lg shadow-amber-500/20 flex items-center justify-center gap-1.5 active:scale-98 transition-all"
          >
            <span>कंट्रोल रूम अनलॉक करें (Unlock Command Board)</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </form>

        <div className="pt-2 border-t border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>त्वरित डेमो लॉगिन:</span>
            <button
              onClick={() => handleQuickBypass('7860')}
              className="text-amber-400 font-bold hover:underline flex items-center gap-1"
            >
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>1-क्लिक अनलॉक (7860)</span>
            </button>
          </div>
          <p className="text-[10px] text-slate-500 font-mono">
            Direct Founder Hotline: {FOUNDER_SOS_HOTLINE}
          </p>
        </div>
      </div>
    </div>
  );
};
