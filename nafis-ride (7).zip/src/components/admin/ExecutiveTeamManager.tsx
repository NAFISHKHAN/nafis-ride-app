import React, { useState } from 'react';
import {
  Users,
  ShieldCheck,
  Phone,
  Mail,
  Award,
  Crown,
  Sparkles,
  MapPin,
  Clock,
  Briefcase,
  CheckCircle2,
} from 'lucide-react';
import {
  FOUNDER_NAME,
  FOUNDER_TAGLINE,
  FOUNDER_SOS_HOTLINE,
  SUPPORT_EMAIL,
  ADMIN_EMERGENCY_NUMBER,
} from '../../data/constants';

interface ExecutiveMember {
  id: string;
  name: string;
  title: string;
  department: string;
  phone: string;
  email: string;
  experience: string;
  alwarZone: string;
  isFounder?: boolean;
  avatar: string;
  status: 'ACTIVE' | 'ON_DUTY' | 'DISPATCH_READY';
}

const INITIAL_TEAM: ExecutiveMember[] = [
  {
    id: 'exec_01',
    name: `${FOUNDER_NAME} (नफीस ख़ान)`,
    title: 'Founder & Chief Executive Officer (संस्थापक एवं मुख्य कार्यकारी)',
    department: 'Apex Governance & Strategic Vision',
    phone: FOUNDER_SOS_HOTLINE,
    email: SUPPORT_EMAIL,
    experience: 'Visionary Pioneer • Alwar Mobility Leader',
    alwarZone: 'All 7 Alwar Tehsils & NCR Corridors',
    isFounder: true,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80',
    status: 'ACTIVE',
  },
  {
    id: 'exec_02',
    name: 'Rashid Khan (रशीद ख़ान)',
    title: 'Chief Operating Officer (मुख्य परिचालन अधिकारी)',
    department: 'Fleet Scaling & Captain Welfare',
    phone: ADMIN_EMERGENCY_NUMBER,
    email: 'ops@nafisride.in',
    experience: '8+ Yrs NCR Logistics & Fleet Management',
    alwarZone: 'Kishangarh & Mew Baroda Corridor',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80',
    status: 'ON_DUTY',
  },
  {
    id: 'exec_03',
    name: 'Vikram Gurjar (विक्रम गुर्जर)',
    title: 'Head of Alwar Rapid Safety & SOS Dispatch',
    department: '24/7 Ground Emergency Response',
    phone: '+91 98295 12044',
    email: 'safety@nafisride.in',
    experience: 'Ex-Defence Liaison • Quick Reaction Force',
    alwarZone: 'Kati Ghati Pass & Industrial Corridors',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80',
    status: 'DISPATCH_READY',
  },
  {
    id: 'exec_04',
    name: 'Pooja Sharma (पूजा शर्मा)',
    title: 'Head of Captain KYC & Legal Compliance',
    department: 'Regulatory Compliance & DL Audits',
    phone: '+91 94140 88219',
    email: 'compliance@nafisride.in',
    experience: 'Rajasthan Transport Dept (RJ-02) Regulatory Specialist',
    alwarZone: 'Hope Circus & City Core Center',
    avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300&auto=format&fit=crop&q=80',
    status: 'ACTIVE',
  },
];

export const ExecutiveTeamManager: React.FC = () => {
  const [team] = useState<ExecutiveMember[]>(INITIAL_TEAM);

  return (
    <div className="space-y-4 text-xs">
      <div className="bg-slate-900 border border-amber-500/40 rounded-2xl p-4">
        <div className="flex items-center gap-2 mb-2">
          <Crown className="w-5 h-5 text-amber-400" />
          <h2 className="font-black text-sm text-amber-400">
            नफीस राइड कार्यकारी बोर्ड (Founder Executive Council)
          </h2>
        </div>
        <p className="text-slate-300 text-[11px] leading-relaxed">
          अलवर के समग्र 30 किलोमीटर परिक्षेत्र में सर्वोच्च विश्वसनीयता, 95% कैप्टन पारदर्शिता और 24/7 आपातकालीन सुरक्षा सुनिश्चित करने वाली केंद्रीय लीडरशिप टीम।
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {team.map((member) => (
          <div
            key={member.id}
            className={`p-4 rounded-2xl border transition-all ${
              member.isFounder
                ? 'bg-gradient-to-br from-amber-950/60 via-slate-900 to-amber-950/40 border-amber-400 shadow-xl'
                : 'bg-slate-900/90 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-start gap-3">
              <div className="relative">
                <img
                  src={member.avatar}
                  alt={member.name}
                  className={`w-14 h-14 rounded-2xl object-cover border-2 shadow-md ${
                    member.isFounder ? 'border-amber-400' : 'border-slate-700'
                  }`}
                />
                {member.isFounder && (
                  <div className="absolute -top-1.5 -right-1.5 bg-amber-500 text-slate-950 rounded-full p-0.5 shadow">
                    <Crown className="w-3 h-3" />
                  </div>
                )}
              </div>

              <div className="flex-1 space-y-1">
                <div className="flex items-center justify-between">
                  <h3 className="font-extrabold text-sm text-white flex items-center gap-1.5">
                    <span>{member.name}</span>
                    {member.isFounder && (
                      <span className="text-[9px] bg-amber-500 text-slate-950 px-1.5 py-0.2 rounded font-black">
                        FOUNDER
                      </span>
                    )}
                  </h3>
                  <span
                    className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                      member.status === 'ACTIVE'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                        : member.status === 'DISPATCH_READY'
                        ? 'bg-cyan-950 text-cyan-400 border border-cyan-500/30'
                        : 'bg-amber-950 text-amber-400 border border-amber-500/30'
                    }`}
                  >
                    {member.status}
                  </span>
                </div>

                <p className="text-[11px] font-semibold text-amber-300/90 leading-tight">
                  {member.title}
                </p>

                <p className="text-[10px] text-slate-400 flex items-center gap-1">
                  <Briefcase className="w-3 h-3 text-slate-500" />
                  <span>{member.department}</span>
                </p>

                <p className="text-[10px] text-slate-400 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-amber-400" />
                  <span>Zone: {member.alwarZone}</span>
                </p>
              </div>
            </div>

            <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
              <a
                href={`tel:${member.phone}`}
                className="flex items-center gap-1 text-slate-300 hover:text-amber-400 font-mono"
              >
                <Phone className="w-3 h-3 text-amber-400" />
                <span>{member.phone}</span>
              </a>

              <a
                href={`mailto:${member.email}`}
                className="flex items-center gap-1 text-slate-400 hover:text-amber-400"
              >
                <Mail className="w-3 h-3 text-slate-400" />
                <span>{member.email}</span>
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
