import React, { useState } from 'react';
import {
  Send,
  X,
  Radio,
  AlertTriangle,
  MapPin,
  ShieldCheck,
  CheckCircle2,
  PhoneCall,
  Loader2,
} from 'lucide-react';
import { rideStore } from '../../services/store';
import { audioService } from '../../services/audioService';
import { FOUNDER_NAME, FOUNDER_SOS_HOTLINE, OPERATIONAL_ZONES } from '../../data/constants';

interface UrgentDispatchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const UrgentDispatchModal: React.FC<UrgentDispatchModalProps> = ({ isOpen, onClose }) => {
  const [selectedZone, setSelectedZone] = useState(OPERATIONAL_ZONES[5].name); // Kati Ghati Pass
  const [dispatchType, setDispatchType] = useState<'safety_priority' | 'fleet_surge' | 'weather_alert'>('safety_priority');
  const [message, setMessage] = useState('संस्थापक नफीस ख़ान निर्देश: कटी घाटी व अलवर बाईपास पर सभी कैप्टन हाई अलर्ट पर रहें।');
  const [isTransmitting, setIsTransmitting] = useState(false);
  const [transmitted, setTransmitted] = useState(false);

  if (!isOpen) return null;

  const handleTransmit = () => {
    setIsTransmitting(true);
    setTimeout(() => {
      setIsTransmitting(false);
      setTransmitted(true);
      audioService.playChime('milestone');
      setTimeout(() => {
        setTransmitted(false);
        onClose();
      }, 1800);
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border-2 border-red-500/70 rounded-3xl max-w-md w-full p-5 text-white shadow-2xl relative space-y-4">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-red-600/20 border border-red-500 flex items-center justify-center text-red-400">
            <Radio className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h3 className="font-black text-sm text-red-400">
              URGENT FOUNDER FLEET DISPATCH
            </h3>
            <p className="text-[10px] text-slate-400">
              Direct Broadcast to all active Alwar Captains
            </p>
          </div>
        </div>

        {transmitted ? (
          <div className="p-6 bg-emerald-950/80 border border-emerald-500 rounded-2xl text-center space-y-2">
            <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
            <h4 className="font-extrabold text-emerald-300 text-sm">
              निर्देश सफलतापूर्वक प्रसारित किए गए!
            </h4>
            <p className="text-xs text-slate-300">
              अलवर के सभी ऑनलाइन कैप्टन्स के डिवाइस पर हाई-प्रायोरिटी अलर्ट भेज दिया गया है।
            </p>
          </div>
        ) : (
          <div className="space-y-3 text-xs">
            <div>
              <label className="text-slate-300 font-bold block mb-1">
                लक्षित परिचालन क्षेत्र (Target Operational Zone):
              </label>
              <select
                value={selectedZone}
                onChange={(e) => setSelectedZone(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-semibold focus:outline-none focus:border-amber-400"
              >
                <option value="ALL_ALWAR">समग्र अलवर (All Alwar 30KM Zones)</option>
                {OPERATIONAL_ZONES.map((z) => (
                  <option key={z.id} value={z.name}>
                    {z.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-slate-300 font-bold block mb-1">
                अलर्ट श्रेणी (Alert Category):
              </label>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { id: 'safety_priority', label: 'Safety SOS' },
                  { id: 'fleet_surge', label: 'Fleet Surge' },
                  { id: 'weather_alert', label: 'Monsoon/Fog' },
                ].map((item) => (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => setDispatchType(item.id as typeof dispatchType)}
                    className={`py-1.5 px-2 rounded-xl text-[10px] font-bold border transition-colors ${
                      dispatchType === item.id
                        ? 'bg-amber-500 text-slate-950 border-amber-400 font-black'
                        : 'bg-slate-950 text-slate-400 border-slate-800'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="text-slate-300 font-bold block mb-1">
                प्रसारण संदेश (Broadcast Message):
              </label>
              <textarea
                rows={3}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white text-xs focus:outline-none focus:border-amber-400 resize-none leading-relaxed"
              />
            </div>

            <button
              type="button"
              onClick={handleTransmit}
              disabled={isTransmitting}
              id="btn-broadcast-urgent-dispatch"
              className="w-full py-3 bg-red-600 hover:bg-red-500 active:scale-98 text-white font-black rounded-xl text-xs shadow-lg shadow-red-600/30 flex items-center justify-center gap-2 transition-all disabled:opacity-50"
            >
              {isTransmitting ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Send className="w-4 h-4" />
              )}
              <span>अलवर फ्लीट को तत्काल प्रसारित करें (Transmit Urgently)</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
