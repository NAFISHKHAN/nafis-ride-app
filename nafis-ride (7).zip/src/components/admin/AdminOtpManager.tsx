import React, { useState, useEffect } from 'react';
import {
  KeyRound,
  Send,
  CheckCircle2,
  RefreshCw,
  Clock,
  ShieldCheck,
  AlertTriangle,
  Search,
  Check,
  Copy,
} from 'lucide-react';
import { rideStore } from '../../services/store';
import { otpService, OtpRecord } from '../../services/otpService';
import { audioService } from '../../services/audioService';

export const AdminOtpManager: React.FC = () => {
  const [activeRide, setActiveRide] = useState(rideStore.getActiveRide());
  const [testPhone, setTestPhone] = useState('9829512044');
  const [otpLogs, setOtpLogs] = useState<OtpRecord[]>(otpService.getRecentLogs());
  const [dispatchStatus, setDispatchStatus] = useState<string | null>(null);
  const [isSending, setIsSending] = useState(false);
  const [copiedOtp, setCopiedOtp] = useState<string | null>(null);

  useEffect(() => {
    const unsub = rideStore.subscribe(() => {
      setActiveRide(rideStore.getActiveRide());
    });
    return unsub;
  }, []);

  const handleSendTestOtp = async () => {
    if (!testPhone || testPhone.length < 10) {
      alert('कृपया 10-अंकीय मान्य मोबाइल नंबर दर्ज करें।');
      return;
    }
    setIsSending(true);
    setDispatchStatus('Fast2SMS गेटवे से कनेक्ट हो रहा है...');

    try {
      const res = await otpService.sendRideOtp(testPhone, 'ride_start');
      setIsSending(false);
      setDispatchStatus(`सफलता! OTP ${res.otp} मोबाइल +91 ${testPhone} पर भेज दिया गया।`);
      setOtpLogs(otpService.getRecentLogs());
      audioService.playChime('milestone');
    } catch (err: unknown) {
      setIsSending(false);
      setDispatchStatus(`त्रुटि: ${err instanceof Error ? err.message : 'SMS भेजने में असमर्थ'}`);
      audioService.playChime('sos');
    }
  };

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedOtp(code);
    setTimeout(() => setCopiedOtp(null), 2000);
  };

  return (
    <div className="space-y-4 text-xs">
      {/* Overview Card */}
      <div className="bg-slate-900 border border-amber-500/40 rounded-2xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-amber-400 font-extrabold text-sm">
            <KeyRound className="w-4 h-4" />
            <span>फास्ट2एसएमएस (Fast2SMS) लाइव OTP डिस्पैच इंजन</span>
          </div>
          <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded font-mono font-bold">
            GATEWAY: ONLINE
          </span>
        </div>

        <p className="text-slate-300 text-[11px] leading-relaxed">
          नफीस राइड में हर सवारी की सुरक्षा के लिए 4-अंकीय क्रिप्टोग्राफिक OTP Fast2SMS DLT-अनुमोदित दूरसंचार रूट से तुरंत SMS किया जाता है।
        </p>

        {/* Live Active Ride OTP if present */}
        {activeRide && (
          <div className="bg-slate-950 p-3 rounded-xl border border-emerald-500/40 flex items-center justify-between">
            <div>
              <span className="text-[10px] text-slate-400 block">सक्रिय ट्रिप OTP (Active Trip):</span>
              <span className="font-bold text-slate-100 text-sm">
                यात्री: {activeRide.riderName} ({activeRide.riderPhone})
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xl font-mono font-black text-emerald-400 bg-emerald-950 px-3 py-1 rounded-lg border border-emerald-500/50 tracking-wider">
                {activeRide.otp}
              </span>
              <button
                type="button"
                onClick={() => handleCopy(activeRide.otp)}
                className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-300"
                title="Copy Active OTP"
              >
                {copiedOtp === activeRide.otp ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>
        )}

        {/* Test SMS Dispatcher */}
        <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
          <label className="text-[11px] text-slate-300 font-bold block">
            त्वरित परीक्षण SMS भेजें (Test Real Phone Dispatch):
          </label>
          <div className="flex gap-2">
            <div className="flex items-center bg-slate-900 border border-slate-700 rounded-xl px-3 text-slate-400 font-mono text-xs">
              +91
            </div>
            <input
              type="text"
              maxLength={10}
              value={testPhone}
              onChange={(e) => setTestPhone(e.target.value.replace(/\D/g, ''))}
              placeholder="10-digit mobile"
              className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-amber-400"
            />
            <button
              type="button"
              onClick={handleSendTestOtp}
              disabled={isSending}
              id="btn-send-test-otp"
              className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs flex items-center gap-1 shadow disabled:opacity-50"
            >
              {isSending ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
              <span>OTP भेजें (Dispatch)</span>
            </button>
          </div>

          {dispatchStatus && (
            <div className="p-2 bg-slate-900 rounded-lg border border-slate-800 text-[11px] text-amber-300">
              {dispatchStatus}
            </div>
          )}
        </div>
      </div>

      {/* Dispatch History Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-extrabold text-slate-200">हालिया OTP ट्रांसमिशन रिकॉर्ड्स (Recent Transmissions)</span>
          <button
            type="button"
            onClick={() => setOtpLogs(otpService.getRecentLogs())}
            className="text-slate-400 hover:text-amber-400 flex items-center gap-1"
          >
            <RefreshCw className="w-3 h-3" />
            <span>रिफ्रेश</span>
          </button>
        </div>

        <div className="space-y-2">
          {otpLogs.map((log, index) => (
            <div
              key={log.gatewayReceipt?.messageId || `${log.phone}-${log.createdAt}-${index}`}
              className="bg-slate-950 p-3 rounded-xl border border-slate-800 flex items-center justify-between"
            >
              <div className="space-y-0.5">
                <div className="flex items-center gap-2">
                  <span className="font-mono font-bold text-amber-300">
                    +91 {log.phone}
                  </span>
                  <span className="text-[9px] bg-slate-800 px-1.5 py-0.5 rounded text-slate-400 font-mono uppercase">
                    {log.role || log.channel}
                  </span>
                </div>
                <div className="text-[10px] text-slate-500">
                  {new Date(log.createdAt).toLocaleTimeString()} • Fast2SMS Quick Route
                </div>
              </div>

              <div className="flex items-center gap-2">
                <span className="font-mono text-sm font-black text-emerald-400 bg-slate-900 px-2.5 py-1 rounded border border-slate-700">
                  {log.otp}
                </span>
                <span className="text-[10px] text-emerald-400 flex items-center gap-0.5">
                  <CheckCircle2 className="w-3 h-3" />
                  <span>DELIVERED</span>
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
