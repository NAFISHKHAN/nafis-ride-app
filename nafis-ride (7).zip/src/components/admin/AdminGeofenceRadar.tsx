import React, { useState, useEffect } from 'react';
import {
  Radar,
  MapPin,
  Compass,
  AlertTriangle,
  ShieldCheck,
  Radio,
  RefreshCw,
  Navigation,
} from 'lucide-react';
import { rideStore, calculateDistanceKm } from '../../services/store';
import { ALWAR_CENTER_COORDS, MAX_RIDE_LIMIT_KM, OPERATIONAL_ZONES } from '../../data/constants';

export const AdminGeofenceRadar: React.FC = () => {
  const [captains, setCaptains] = useState(rideStore.getCaptains());
  const [sosAlerts, setSosAlerts] = useState(rideStore.getSosAlerts());
  const [radarSweep, setRadarSweep] = useState(0);

  useEffect(() => {
    const unsub = rideStore.subscribe(() => {
      setCaptains([...rideStore.getCaptains()]);
      setSosAlerts([...rideStore.getSosAlerts()]);
    });

    const interval = setInterval(() => {
      setRadarSweep((s) => (s + 15) % 360);
    }, 200);

    return () => {
      unsub();
      clearInterval(interval);
    };
  }, []);

  return (
    <div className="space-y-4 text-xs">
      <div className="bg-slate-900 border border-amber-500/40 rounded-2xl p-4 flex items-center justify-between">
        <div className="flex items-center gap-2 text-amber-400 font-extrabold text-sm">
          <Radar className="w-5 h-5 animate-spin" />
          <span>30 KM अलवर लाइव जियोफेंस रडार (Active Geofence Radar)</span>
        </div>
        <span className="text-[10px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2.5 py-0.5 rounded font-mono font-bold">
          PERIMETER: ENFORCED
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {/* Radar Graphic Simulation Box */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 flex flex-col items-center justify-center relative overflow-hidden min-h-[220px]">
          {/* Radar Circles */}
          <div className="relative w-44 h-44 rounded-full border border-emerald-500/30 flex items-center justify-center">
            <div className="w-32 h-32 rounded-full border border-emerald-500/40 flex items-center justify-center">
              <div className="w-20 h-20 rounded-full border border-emerald-500/50 flex items-center justify-center">
                <div className="w-2 h-2 rounded-full bg-amber-400" />
              </div>
            </div>

            {/* Sweep line */}
            <div
              className="absolute top-1/2 left-1/2 w-22 h-[1px] bg-gradient-to-r from-emerald-400 to-transparent origin-left pointer-events-none"
              style={{ transform: `rotate(${radarSweep}deg)` }}
            />

            {/* Simulated landmark blips */}
            <div className="absolute top-8 left-12 w-2 h-2 rounded-full bg-cyan-400 animate-ping" title="Kati Ghati" />
            <div className="absolute bottom-10 right-10 w-2 h-2 rounded-full bg-emerald-400" title="Alwar Core" />
            <div className="absolute top-16 right-8 w-2 h-2 rounded-full bg-amber-400" title="Shital Kat" />
          </div>

          <div className="mt-3 text-center">
            <span className="text-[10px] font-mono text-slate-400">
              Center: Hope Circus ({ALWAR_CENTER_COORDS.lat}, {ALWAR_CENTER_COORDS.lng})
            </span>
          </div>
        </div>

        {/* Live Boundary Zones */}
        <div className="md:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-extrabold text-slate-200">
              जियोफेंस परिधि स्थिति (Operational Perimeter Status)
            </span>
            <span className="text-[10px] text-amber-400 font-mono font-bold">
              Radius: {MAX_RIDE_LIMIT_KM} KM
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {OPERATIONAL_ZONES.map((zone) => {
              const dist = calculateDistanceKm(
                zone.lat,
                zone.lng,
                ALWAR_CENTER_COORDS.lat,
                ALWAR_CENTER_COORDS.lng
              );
              const isInside = dist <= MAX_RIDE_LIMIT_KM;

              return (
                <div
                  key={zone.id}
                  className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between"
                >
                  <div className="truncate mr-2">
                    <div className="font-bold text-slate-200 text-[11px] truncate">
                      {zone.name.split(' (')[0]}
                    </div>
                    <div className="text-[9px] text-slate-400 font-mono">
                      {dist} KM from Center
                    </div>
                  </div>
                  <span
                    className={`text-[9px] font-bold px-1.5 py-0.5 rounded flex-shrink-0 ${
                      isInside
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/30'
                        : 'bg-red-950 text-red-400 border border-red-500/30'
                    }`}
                  >
                    {isInside ? 'SAFE' : 'OUT'}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Active SOS Alerts on Radar */}
      {sosAlerts.length > 0 && (
        <div className="bg-red-950/40 border-2 border-red-500/60 rounded-2xl p-4 space-y-2">
          <div className="flex items-center gap-2 text-red-400 font-black">
            <AlertTriangle className="w-4 h-4 animate-bounce" />
            <span>सक्रिय आपातकालीन SOS अलर्ट्स (Active SOS Signals on Radar): {sosAlerts.length}</span>
          </div>

          <div className="space-y-2">
            {sosAlerts.map((alert) => (
              <div
                key={alert.id}
                className="bg-slate-900 p-3 rounded-xl border border-red-500/40 flex items-center justify-between"
              >
                <div>
                  <div className="font-bold text-white text-xs">
                    {alert.senderName || alert.userName || 'अलवर नागरिक'} ({alert.role.toUpperCase()})
                  </div>
                  <div className="text-[10px] text-slate-400 font-mono">
                    {alert.coordinates?.address || alert.locationAddress || 'Alwar Operational Perimeter'} • {alert.timestamp}
                  </div>
                </div>
                <a
                  href={`tel:${alert.senderPhone || alert.userPhone}`}
                  className="px-3 py-1.5 bg-red-600 hover:bg-red-500 text-white font-black rounded-lg text-xs"
                >
                  कॉल करें
                </a>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
