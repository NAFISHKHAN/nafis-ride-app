import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Users,
  DollarSign,
  MapPin,
  CheckCircle,
  XCircle,
  Clock,
  Sparkles,
  Award,
  Power,
  Settings,
  AlertTriangle,
  RotateCcw,
  Plus,
  Trash2,
  Phone,
  FileText,
  BadgeCheck,
  Send,
  Eye,
  KeyRound,
  Crown,
  Radar,
  TrendingUp,
} from 'lucide-react';
import { rideStore } from '../../services/store';
import { audioService } from '../../services/audioService';
import { Captain, VehicleType, FareSettings } from '../../types';
import {
  FOUNDER_NAME,
  FOUNDER_TAGLINE,
  FOUNDER_SOS_HOTLINE,
  SUPPORT_EMAIL,
  OPERATIONAL_ZONES,
} from '../../data/constants';
import { AdminGeofenceRadar } from './AdminGeofenceRadar';
import { AdminOtpManager } from './AdminOtpManager';
import { ExecutiveTeamManager } from './ExecutiveTeamManager';
import { CeoPerformanceGrid } from './CeoPerformanceGrid';
import { UrgentDispatchModal } from './UrgentDispatchModal';

interface AdminDashboardProps {
  onLockGate: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onLockGate }) => {
  const [captains, setCaptains] = useState<Captain[]>(rideStore.getCaptains());
  const [settings, setSettings] = useState<FareSettings>(rideStore.getSettings());
  const [activeRide, setActiveRide] = useState(rideStore.getActiveRide());
  const [sosAlerts, setSosAlerts] = useState(rideStore.getSosAlerts());

  const [activeTab, setActiveTab] = useState<
    'overview' | 'captains_kyc' | 'radar' | 'otp_manager' | 'executive' | 'kpi_grid' | 'fare_settings'
  >('overview');

  const [isUrgentModalOpen, setIsUrgentModalOpen] = useState(false);
  const [selectedCaptainDoc, setSelectedCaptainDoc] = useState<Captain | null>(null);

  useEffect(() => {
    const unsub = rideStore.subscribe(() => {
      setCaptains([...rideStore.getCaptains()]);
      setSettings(rideStore.getSettings());
      setActiveRide(rideStore.getActiveRide());
      setSosAlerts([...rideStore.getSosAlerts()]);
    });
    return unsub;
  }, []);

  const handleApproveKyc = (captainId: string) => {
    rideStore.updateCaptainKycStatus(captainId, 'approved');
    audioService.playChime('milestone');
  };

  const handleRejectKyc = (captainId: string) => {
    rideStore.updateCaptainKycStatus(captainId, 'rejected');
    audioService.playChime('sos');
  };

  const handleSaveFares = (e: React.FormEvent) => {
    e.preventDefault();
    rideStore.updateFareSettings(settings);
    audioService.playChime('cash');
    alert('किराया सेटिंग्स सफलतापूर्वक अपडेट कर दी गई हैं! (Tariffs Updated)');
  };

  const handleResolveSos = (alertId: string) => {
    rideStore.resolveSosAlert(alertId);
    audioService.playChime('milestone');
  };

  return (
    <div className="relative w-full h-full flex flex-col bg-slate-950 text-slate-100 overflow-hidden select-none">
      {/* Admin Top Header */}
      <header className="flex-shrink-0 z-20 bg-slate-900 border-b border-amber-500/40 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center font-black text-slate-950 shadow-md">
            <Crown className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="font-black text-sm text-amber-400">
                NAFIS RIDE SUPREME COMMAND
              </h1>
              <span className="text-[9px] bg-red-600 text-white font-black px-1.5 rounded">
                FOUNDER HQ
              </span>
            </div>
            <p className="text-[10px] text-slate-400">
              Chief Executive Board • <span className="text-white font-bold">{FOUNDER_NAME}</span>
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsUrgentModalOpen(true)}
            id="btn-open-urgent-dispatch"
            className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white font-black text-xs flex items-center gap-1.5 shadow active:scale-95 transition-all"
          >
            <Send className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">फ्लीट ब्रॉडकास्ट</span>
          </button>

          <button
            onClick={onLockGate}
            id="btn-lock-admin-gate"
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs border border-slate-700"
          >
            लॉगआउट
          </button>
        </div>
      </header>

      {/* Admin Navigation Pills */}
      <nav className="flex-shrink-0 bg-slate-900/80 border-b border-slate-800 px-3 py-2 flex items-center gap-1.5 overflow-x-auto text-xs scrollbar-none">
        {[
          { id: 'overview', label: 'अवलोकन (Overview)' },
          { id: 'captains_kyc', label: `कैप्टन KYC (${captains.length})` },
          { id: 'radar', label: 'जियोफेंस रडार (30KM Radar)' },
          { id: 'otp_manager', label: 'Fast2SMS OTP' },
          { id: 'kpi_grid', label: 'CEO मैट्रिक्स (KPIs)' },
          { id: 'executive', label: 'कार्यकारी बोर्ड (Board)' },
          { id: 'fare_settings', label: 'किराया सेटिंग्स (Tariffs)' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as typeof activeTab)}
            className={`px-3 py-1.5 rounded-xl font-bold whitespace-nowrap transition-all flex-shrink-0 ${
              activeTab === tab.id
                ? 'bg-amber-500 text-slate-950 shadow-md font-black'
                : 'text-slate-400 hover:text-white bg-slate-950/60 border border-slate-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </nav>

      {/* Main Tab Content */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {activeTab === 'overview' && (
          <div className="space-y-4">
            {/* Quick Metrics Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5">
                <div className="text-slate-400 text-[10px]">कुल पंजीकृत कैप्टन</div>
                <div className="text-xl font-black text-amber-400 mt-1">{captains.length}</div>
                <div className="text-[10px] text-emerald-400 mt-0.5">
                  {captains.filter((c) => c.isOnline).length} ड्यूटी पर ऑनलाइन
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5">
                <div className="text-slate-400 text-[10px]">सक्रिय सवारी (Active Trip)</div>
                <div className="text-xl font-black text-cyan-400 mt-1">
                  {activeRide && activeRide.status !== 'idle' ? 1 : 0}
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  {activeRide ? activeRide.status : 'कोई सक्रिय नहीं'}
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5">
                <div className="text-slate-400 text-[10px]">KYC समीक्षा बाकी</div>
                <div className="text-xl font-black text-yellow-400 mt-1">
                  {captains.filter((c) => c.kycStatus === 'pending').length}
                </div>
                <div className="text-[10px] text-slate-400 mt-0.5">सत्यापन हेतु लंबित</div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5">
                <div className="text-slate-400 text-[10px]">आपातकालीन SOS अलर्ट्स</div>
                <div className="text-xl font-black text-red-400 mt-1">{sosAlerts.length}</div>
                <div className="text-[10px] text-slate-400 mt-0.5">संस्थापक हेल्पलाइन</div>
              </div>
            </div>

            {/* Live SOS Alerts Feed */}
            {sosAlerts.length > 0 && (
              <div className="bg-red-950/60 border-2 border-red-500 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-red-400 font-extrabold text-sm">
                    <ShieldAlert className="w-5 h-5 animate-pulse" />
                    <span>फाउंडर लाइव SOS अलर्ट्स ({sosAlerts.length})</span>
                  </div>
                  <span className="text-[10px] bg-red-900 text-white px-2 py-0.5 rounded font-bold">
                    PRIORITY 1 DISPATCH
                  </span>
                </div>

                <div className="space-y-2">
                  {sosAlerts.map((alert) => (
                    <div
                      key={alert.id}
                      className="bg-slate-900 p-3 rounded-xl border border-red-500/40 flex items-center justify-between text-xs"
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2 font-bold text-white">
                          <span>{alert.senderName || alert.userName || 'अलवर नागरिक (Citizen)'}</span>
                          <span className="text-[10px] bg-red-950 text-red-300 px-1.5 rounded">
                            {alert.role.toUpperCase()}
                          </span>
                        </div>
                        <div className="text-slate-300 text-[11px]">
                          {alert.coordinates?.address || alert.locationAddress || 'Alwar Operational Perimeter'}
                        </div>
                        <div className="text-[10px] text-slate-500 font-mono">
                          Time: {alert.timestamp} • Contact: {alert.senderPhone || alert.userPhone}
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <a
                          href={`tel:${alert.senderPhone || alert.userPhone}`}
                          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-[11px] flex items-center gap-1"
                        >
                          <Phone className="w-3 h-3" />
                          <span>Call</span>
                        </a>
                        <button
                          onClick={() => handleResolveSos(alert.id)}
                          className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-lg text-[11px]"
                        >
                          Resolve
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Quick Fleet Map Snapshot */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-slate-200 text-xs">
                  अलवर फ्लीट लाइव स्थिति (Fleet Real-Time Status)
                </span>
                <button
                  onClick={() => setActiveTab('radar')}
                  className="text-amber-400 font-bold hover:underline text-xs"
                >
                  फुल रडार व्यू देखें →
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                {captains.map((cpt) => (
                  <div
                    key={cpt.id}
                    className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between"
                  >
                    <div>
                      <div className="font-bold text-white">{cpt.name}</div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        {cpt.vehiclePlate} ({cpt.vehicleType.toUpperCase()})
                      </div>
                    </div>
                    <span
                      className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                        cpt.isOnline
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40'
                          : 'bg-slate-800 text-slate-400'
                      }`}
                    >
                      {cpt.isOnline ? 'ONLINE' : 'OFFLINE'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'captains_kyc' && (
          <div className="space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-black text-sm text-amber-400">
                  अलवर कैप्टन सत्यापन एवं केवाईसी (Driver Documents & ID Approvals)
                </h3>
                <span className="text-xs text-slate-400 font-mono">
                  Total: {captains.length}
                </span>
              </div>

              <div className="space-y-3">
                {captains.map((cpt) => (
                  <div
                    key={cpt.id}
                    className="p-4 bg-slate-950 rounded-2xl border border-slate-800 space-y-3 text-xs"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <img
                          src={cpt.photoUrl}
                          alt={cpt.name}
                          className="w-12 h-12 rounded-xl object-cover border border-amber-400"
                        />
                        <div>
                          <div className="flex items-center gap-1.5">
                            <h4 className="font-bold text-sm text-white">{cpt.name}</h4>
                            <span className="text-[10px] text-amber-400 font-mono font-bold">
                              ★ {cpt.rating}
                            </span>
                          </div>
                          <p className="text-[11px] text-slate-400 font-mono">
                            ID: NR-ALW-{cpt.id.slice(-4).toUpperCase()} • {cpt.phone}
                          </p>
                          <div className="text-[10px] text-slate-500">
                            Vehicle: {cpt.vehicleModel} ({cpt.vehiclePlate})
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col items-end gap-1">
                        <span
                          className={`text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase ${
                            cpt.kycStatus === 'approved'
                              ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40'
                              : cpt.kycStatus === 'rejected'
                              ? 'bg-red-950 text-red-400 border border-red-500/40'
                              : 'bg-amber-950 text-amber-400 border border-amber-500/40'
                          }`}
                        >
                          {cpt.kycStatus}
                        </span>

                        <span className="text-[9px] text-slate-400">
                          Total Rides: {cpt.totalTrips}
                        </span>
                      </div>
                    </div>

                    {/* KYC Document Checklist */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-900 text-[11px]">
                      <div className="p-2 bg-slate-900 rounded-lg">
                        <span className="text-slate-400 block text-[9px]">आधार नंबर:</span>
                        <span className="font-mono text-slate-200">
                          {cpt.kycDocs?.aadhaarNumber || '5821-9482-8921'}
                        </span>
                      </div>
                      <div className="p-2 bg-slate-900 rounded-lg">
                        <span className="text-slate-400 block text-[9px]">ड्राइविंग लाइसेंस (DL):</span>
                        <span className="font-mono text-emerald-400 font-bold">
                          {cpt.kycDocs?.drivingLicenseNumber || 'RJ-02-2021008892'}
                        </span>
                      </div>
                      <div className="p-2 bg-slate-900 rounded-lg">
                        <span className="text-slate-400 block text-[9px]">DL वैधता (Expiry):</span>
                        <span className="font-mono text-slate-200">
                          {cpt.kycDocs?.dlExpiryDate || '2031-09-20'}
                        </span>
                      </div>
                      <div className="p-2 bg-slate-900 rounded-lg">
                        <span className="text-slate-400 block text-[9px]">रजिस्टर्ड UPI ID:</span>
                        <span className="font-mono text-amber-400 truncate block">
                          {cpt.upiId}
                        </span>
                      </div>
                    </div>

                    {/* KYC Action buttons */}
                    <div className="flex items-center justify-between pt-2 border-t border-slate-900">
                      <button
                        onClick={() => setSelectedCaptainDoc(cpt)}
                        className="text-amber-400 hover:underline font-bold flex items-center gap-1 text-[11px]"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>दस्तावेज़ फोटो देखें (Inspect Docs)</span>
                      </button>

                      <div className="flex gap-2">
                        {cpt.kycStatus !== 'approved' && (
                          <button
                            onClick={() => handleApproveKyc(cpt.id)}
                            className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-lg text-xs"
                          >
                            स्वीकृत करें (Approve)
                          </button>
                        )}
                        {cpt.kycStatus !== 'rejected' && (
                          <button
                            onClick={() => handleRejectKyc(cpt.id)}
                            className="px-3 py-1.5 bg-red-900/60 hover:bg-red-800 text-red-300 font-bold rounded-lg text-xs border border-red-700/50"
                          >
                            अस्वीकार (Reject)
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'radar' && <AdminGeofenceRadar />}

        {activeTab === 'otp_manager' && <AdminOtpManager />}

        {activeTab === 'executive' && <ExecutiveTeamManager />}

        {activeTab === 'kpi_grid' && <CeoPerformanceGrid />}

        {activeTab === 'fare_settings' && (
          <div className="space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h3 className="font-black text-sm text-amber-400">
                    अलवर किराया व टैरिफ मैट्रिक्स (Alwar Fare Configuration)
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    रैपिडो से किफायती एवं चालकों के लिए लाभकारी न्यूनतम आधार दरें।
                  </p>
                </div>
              </div>

              <form onSubmit={handleSaveFares} className="space-y-4 text-xs">
                {(['bike', 'auto', 'eriksha'] as VehicleType[]).map((type) => (
                  <div
                    key={type}
                    className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2"
                  >
                    <div className="flex items-center justify-between border-b border-slate-900 pb-1.5">
                      <span className="font-bold text-sm text-white uppercase">
                        {type === 'bike' ? '🛵 BIKE (बाइक)' : type === 'auto' ? '🛺 AUTO (ऑटो)' : '⚡ E-RIKSHA (ई-रिक्शा)'}
                      </span>
                      <span className="text-[10px] text-emerald-400 font-mono font-bold">
                        {100 - (settings.commissionPercentage || 12)}% Captain / {settings.commissionPercentage || 12}% Platform
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-slate-400 text-[10px] block mb-1">
                          बेस किराया (Base Fare ₹)
                        </label>
                        <input
                          type="number"
                          value={settings[type].baseFare}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              [type]: {
                                ...settings[type],
                                baseFare: Number(e.target.value),
                              },
                            })
                          }
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono font-bold focus:outline-none focus:border-amber-400"
                        />
                      </div>

                      <div>
                        <label className="text-slate-400 text-[10px] block mb-1">
                          प्रति किलोमीटर दर (Rate Per KM ₹)
                        </label>
                        <input
                          type="number"
                          value={settings[type].perKm}
                          onChange={(e) =>
                            setSettings({
                              ...settings,
                              [type]: {
                                ...settings[type],
                                perKm: Number(e.target.value),
                              },
                            })
                          }
                          className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono font-bold focus:outline-none focus:border-amber-400"
                        />
                      </div>
                    </div>
                  </div>
                ))}

                {/* Platform Commission Rate Control */}
                <div className="p-3 bg-slate-950 rounded-xl border border-amber-500/30 space-y-2">
                  <div className="flex items-center justify-between border-b border-slate-900 pb-1.5">
                    <span className="font-bold text-sm text-amber-400">
                      प्लेटफ़ॉर्म कमीशन दर (Platform Commission Rate %)
                    </span>
                    <span className="text-xs font-mono font-bold text-emerald-400">
                      {100 - (settings.commissionPercentage || 12)}% Captain Share
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-3 items-center">
                    <div>
                      <label className="text-slate-400 text-[10px] block mb-1">
                        प्लेटफ़ॉर्म कमीशन प्रतिशत (%)
                      </label>
                      <input
                        type="number"
                        min="0"
                        max="50"
                        value={settings.commissionPercentage ?? 12}
                        onChange={(e) =>
                          setSettings({
                            ...settings,
                            commissionPercentage: Number(e.target.value),
                          })
                        }
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white font-mono font-bold focus:outline-none focus:border-amber-400"
                      />
                    </div>
                    <div className="text-[11px] text-slate-400 leading-tight">
                      वर्तमान में <strong className="text-white">{settings.commissionPercentage || 12}%</strong> प्लेटफ़ॉर्म कमीशन और <strong className="text-emerald-400">{100 - (settings.commissionPercentage || 12)}%</strong> कैप्टन को प्रत्यक्ष वॉलेट में जा रहा है।
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  id="btn-save-fare-settings"
                  className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 font-black rounded-xl text-xs shadow-lg shadow-amber-500/20 active:scale-98"
                >
                  अलवर किराया दरें सहेजें (Save Tariff Matrix)
                </button>
              </form>
            </div>
          </div>
        )}
      </div>

      <UrgentDispatchModal
        isOpen={isUrgentModalOpen}
        onClose={() => setIsUrgentModalOpen(false)}
      />

      {/* Inspect Document Lightbox */}
      {selectedCaptainDoc && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-amber-500 rounded-2xl max-w-lg w-full p-5 text-white space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h3 className="font-bold text-sm text-amber-400">
                दस्तावेज़ पूर्वावलोकन • {selectedCaptainDoc.name}
              </h3>
              <button
                onClick={() => setSelectedCaptainDoc(null)}
                className="p-1 text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <span className="text-xs text-slate-400 block mb-1">आधार कार्ड फोटो:</span>
                <img
                  src={selectedCaptainDoc.kycDocs?.aadhaarPhotoUrl || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600'}
                  alt="Aadhaar"
                  className="w-full h-36 object-cover rounded-xl border border-slate-700"
                />
              </div>

              <div>
                <span className="text-xs text-slate-400 block mb-1">ड्राइविंग लाइसेंस (DL):</span>
                <img
                  src={selectedCaptainDoc.kycDocs?.dlPhotoUrl || 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600'}
                  alt="DL"
                  className="w-full h-36 object-cover rounded-xl border border-slate-700"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => {
                  handleApproveKyc(selectedCaptainDoc.id);
                  setSelectedCaptainDoc(null);
                }}
                className="px-4 py-2 bg-emerald-500 text-slate-950 font-bold rounded-xl text-xs"
              >
                स्वीकृत करें (Approve KYC)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
