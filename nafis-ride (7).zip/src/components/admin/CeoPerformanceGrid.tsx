import React from 'react';
import {
  TrendingUp,
  Award,
  ShieldCheck,
  Zap,
  Users,
  Percent,
  Clock,
  MapPin,
  Sparkles,
} from 'lucide-react';
import { FOUNDER_NAME } from '../../data/constants';

export const CeoPerformanceGrid: React.FC = () => {
  const metrics = [
    {
      title: 'सक्रिय कैप्टन फ्लीट (Active Fleet)',
      value: '248',
      unit: 'अलवर कैप्टन',
      growth: '+18.4% this week',
      icon: Users,
      color: 'text-amber-400',
      bgColor: 'bg-amber-500/10',
      borderColor: 'border-amber-500/30',
    },
    {
      title: 'कैप्टन कमाई हिस्सा (Captain Revenue)',
      value: '88%',
      unit: '12% प्लेटफ़ॉर्म कमीशन / 88% कैप्टन',
      growth: 'अलवर बाज़ार में सबसे पारदर्शी',
      icon: Percent,
      color: 'text-emerald-400',
      bgColor: 'bg-emerald-500/10',
      borderColor: 'border-emerald-500/30',
    },
    {
      title: 'सुरक्षा रिकॉर्ड (Safety Metric)',
      value: '100%',
      unit: '0% सुरक्षा घटना (Zero Incidents)',
      growth: 'कटी घाटी व अलवर हाईवे सुरक्षित',
      icon: ShieldCheck,
      color: 'text-cyan-400',
      bgColor: 'bg-cyan-500/10',
      borderColor: 'border-cyan-500/30',
    },
    {
      title: 'औसत पिकअप समय (Avg Pickup ETA)',
      value: '3.8',
      unit: 'मिनट (Rapid Arrival)',
      growth: 'रैपिडो से 25% तेज आगमन',
      icon: Clock,
      color: 'text-yellow-400',
      bgColor: 'bg-yellow-500/10',
      borderColor: 'border-yellow-500/30',
    },
  ];

  const zonalBreakdown = [
    { zone: 'अलवर सिटी कोर (Alwar Core)', rides: 1420, rating: 4.95, activeCaptains: 94 },
    { zone: 'किशनगढ़ बास (Kishangarh)', rides: 680, rating: 4.88, activeCaptains: 42 },
    { zone: 'कटी घाटी (Kati Ghati Pass)', rides: 512, rating: 4.92, activeCaptains: 36 },
    { zone: 'मेव बड़ौदा (Mew Baroda)', rides: 420, rating: 4.89, activeCaptains: 31 },
    { zone: 'शीतल कट (Shital Kat)', rides: 390, rating: 4.91, activeCaptains: 25 },
    { zone: 'जत्याना (Jatyana)', rides: 280, rating: 4.87, activeCaptains: 20 },
  ];

  return (
    <div className="space-y-4 text-xs">
      <div className="bg-slate-900 border border-amber-500/40 rounded-2xl p-4 flex items-center justify-between">
        <div>
          <span className="text-[10px] text-amber-400 font-bold uppercase tracking-wider">
            EXECUTIVE DASHBOARD • CEO COMMAND
          </span>
          <h2 className="text-base font-black text-white mt-0.5">
            नफीस ख़ान परफॉर्मेंस ग्रिड (Alwar Mobility KPIs)
          </h2>
        </div>
        <div className="text-right">
          <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-mono font-bold">
            MARKET: DOMINANT
          </span>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {metrics.map((m, idx) => {
          const Icon = m.icon;
          return (
            <div
              key={idx}
              className={`p-3.5 rounded-2xl border ${m.bgColor} ${m.borderColor} flex flex-col justify-between`}
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] text-slate-300 font-semibold">{m.title}</span>
                <Icon className={`w-4 h-4 ${m.color}`} />
              </div>
              <div className="my-2">
                <div className={`text-2xl font-black font-mono ${m.color}`}>{m.value}</div>
                <div className="text-[10px] text-slate-400 mt-0.5">{m.unit}</div>
              </div>
              <div className="text-[10px] font-bold text-slate-300 border-t border-slate-800/80 pt-1.5 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-400" />
                <span>{m.growth}</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Alwar Regional Breakdown */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <span className="font-extrabold text-slate-200">
            क्षेत्रीय परिचालन एवं मांग घनत्व (Alwar Tehsil Breakdown)
          </span>
          <span className="text-[10px] text-slate-400">30 KM Radius Coverage</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
          {zonalBreakdown.map((item, i) => (
            <div
              key={i}
              className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5"
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-amber-300 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-amber-400" />
                  <span>{item.zone}</span>
                </span>
                <span className="font-mono text-emerald-400 font-bold text-[11px]">
                  ★ {item.rating}
                </span>
              </div>
              <div className="flex justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-900">
                <span>Rides: <strong className="text-white">{item.rides}</strong></span>
                <span>Captains: <strong className="text-amber-400">{item.activeCaptains}</strong></span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
