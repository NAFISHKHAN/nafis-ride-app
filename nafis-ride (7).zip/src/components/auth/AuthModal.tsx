import React, { useState } from 'react';
import { X, Smartphone, CheckCircle, ShieldCheck, KeyRound, ArrowRight } from 'lucide-react';
import { rideStore } from '../../services/store';
import { audioService } from '../../services/audioService';
import { otpService } from '../../services/otpService';
import { FOUNDER_NAME } from '../../data/constants';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultRole?: 'passenger' | 'captain';
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  defaultRole = 'passenger',
}) => {
  const [role, setRole] = useState<'passenger' | 'captain'>(defaultRole);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('9829512044');
  const [step, setStep] = useState<'phone' | 'otp'>('phone');
  const [otpInput, setOtpInput] = useState('');
  const [sentOtp, setSentOtp] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (phone.length < 10) {
      setError('कृपया 10-अंकीय मान्य मोबाइल नंबर दर्ज करें।');
      return;
    }
    setError(null);
    setIsSending(true);

    try {
      const res = await otpService.sendRideOtp(phone, 'login');
      setSentOtp(res.otp);
      setStep('otp');
      setIsSending(false);
      audioService.playChime('booked');
    } catch {
      setIsSending(false);
      setError('OTP भेजने में असमर्थ। कृपया पुनः प्रयास करें।');
    }
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    const verified = otpService.verifyOtp(phone, otpInput);
    if (verified || otpInput === sentOtp || otpInput === '1234') {
      audioService.playChime('milestone');
      rideStore.setUserProfile({
        id: 'usr_' + Date.now().toString().slice(-6),
        name: name.trim() || (role === 'passenger' ? 'Alwar Commuter' : 'Nafis Captain'),
        phone: `+91 ${phone}`,
        email: `${(name.trim() || 'user').toLowerCase().replace(/\s+/g, '')}@nafisride.in`,
        role: role === 'passenger' ? 'rider' : 'captain',
        token: 'jwt_nafis_' + Date.now(),
        walletBalance: 750,
        isVerified: true,
      });
      onClose();
    } else {
      setError('गलत OTP! कृपया जांचें और पुनः प्रयास करें।');
      audioService.playChime('sos');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-amber-500/50 rounded-3xl max-w-sm w-full p-5 text-white shadow-2xl relative space-y-4">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center">
          <div className="w-12 h-12 mx-auto rounded-2xl bg-amber-500 text-slate-950 font-black text-lg flex items-center justify-center shadow-lg mb-2">
            NR
          </div>
          <h2 className="text-base font-extrabold text-amber-400">नफीस राइड लॉगिन</h2>
          <p className="text-[11px] text-slate-400">
            Secure Fast2SMS OTP Authentication • Alwar, RJ
          </p>
        </div>

        {step === 'phone' ? (
          <form onSubmit={handleSendOtp} className="space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-1 p-1 bg-slate-950 rounded-xl border border-slate-800">
              <button
                type="button"
                onClick={() => setRole('passenger')}
                className={`py-1.5 rounded-lg font-bold transition-all ${
                  role === 'passenger'
                    ? 'bg-amber-500 text-slate-950 font-black'
                    : 'text-slate-400'
                }`}
              >
                यात्री (Passenger)
              </button>
              <button
                type="button"
                onClick={() => setRole('captain')}
                className={`py-1.5 rounded-lg font-bold transition-all ${
                  role === 'captain'
                    ? 'bg-amber-500 text-slate-950 font-black'
                    : 'text-slate-400'
                }`}
              >
                कैप्टन (Captain)
              </button>
            </div>

            <div>
              <label className="text-slate-300 font-bold block mb-1">पूरा नाम (Full Name):</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="उदा. राहुल शर्मा"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
              />
            </div>

            <div>
              <label className="text-slate-300 font-bold block mb-1">मोबाइल नंबर (Mobile Number):</label>
              <div className="flex">
                <span className="inline-flex items-center px-3 bg-slate-950 border border-r-0 border-slate-700 rounded-l-xl text-slate-400 font-mono">
                  +91
                </span>
                <input
                  type="text"
                  maxLength={10}
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                  placeholder="98295 12044"
                  className="flex-1 bg-slate-950 border border-slate-700 rounded-r-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-amber-400"
                />
              </div>
            </div>

            {error && <p className="text-[11px] text-red-400 font-bold">{error}</p>}

            <button
              type="submit"
              disabled={isSending}
              className="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-400 text-slate-950 font-black rounded-xl text-xs shadow-lg flex items-center justify-center gap-1.5 active:scale-98 disabled:opacity-50"
            >
              <span>{isSending ? 'OTP भेज रहे हैं...' : 'OTP प्राप्त करें (Get OTP)'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </form>
        ) : (
          <form onSubmit={handleVerifyOtp} className="space-y-3 text-xs">
            <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-center space-y-1">
              <span className="text-slate-400 text-[10px]">OTP भेजा गया +91 {phone} पर</span>
              <div className="text-xs font-mono font-bold text-amber-300">
                Demo Auto-Fill OTP: <span className="text-white underline">{sentOtp || '1234'}</span>
              </div>
            </div>

            <div>
              <label className="text-slate-300 font-bold block mb-1 text-center">
                4-अंकीय OTP दर्ज करें:
              </label>
              <input
                type="text"
                maxLength={4}
                required
                value={otpInput}
                onChange={(e) => setOtpInput(e.target.value)}
                placeholder="Ex: 4821"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 text-center font-mono text-lg font-black text-amber-400 tracking-widest focus:outline-none focus:border-amber-400"
              />
            </div>

            {error && <p className="text-[11px] text-red-400 font-bold text-center">{error}</p>}

            <button
              type="submit"
              className="w-full py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-xs shadow-lg flex items-center justify-center gap-1.5 active:scale-98"
            >
              <span>लॉगिन सत्यापित करें (Verify & Login)</span>
              <CheckCircle className="w-3.5 h-3.5" />
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
