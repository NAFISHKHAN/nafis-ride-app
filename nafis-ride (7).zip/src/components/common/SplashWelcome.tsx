import React, { useState } from 'react';
import { ShieldCheck, ArrowRight, Zap, CheckCircle2, Phone, Lock, Sparkles, Navigation } from 'lucide-react';
import { audioService } from '../../services/audioService';
import { FOUNDER_NAME, FOUNDER_TAGLINE, SUPPORT_EMAIL, FOUNDER_SOS_HOTLINE } from '../../data/constants';
import { rideStore } from '../../services/store';

interface SplashWelcomeProps {
  isOpen?: boolean;
  onDismiss?: () => void;
  onStart?: () => void;
}

export const SplashWelcome: React.FC<SplashWelcomeProps> = ({ isOpen = true, onDismiss, onStart }) => {
  const [phoneNumber, setPhoneNumber] = useState('9829512044');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleClose = () => {
    if (onStart) onStart();
    else if (onDismiss) onDismiss();
  };

  const handleQuickLoginAndStart = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setIsSubmitting(true);
    audioService.playChime('welcome');

    try {
      const cleaned = phoneNumber.replace(/\D/g, '').slice(-10);
      if (cleaned.length === 10) {
        rideStore.setUserProfile({
          id: 'usr_' + Date.now().toString().slice(-6),
          name: 'अलवर यात्री (Verified)',
          phone: `+91 ${cleaned}`,
          email: `rider.${cleaned}@nafisride.in`,
          role: 'rider',
          token: `jwt_session_${Date.now()}`,
          walletBalance: 750,
          isVerified: true,
        });
      }
    } catch (err) {
      console.warn('[Splash Auth]', err);
    } finally {
      setIsSubmitting(false);
      handleClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 flex flex-col justify-between items-center p-6 text-white select-none overflow-y-auto">
      {/* Top Corporate Brand Header */}
      <div className="w-full max-w-md pt-3 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-amber-500 flex items-center justify-center font-black text-slate-950 text-xl shadow-lg shadow-amber-500/20">
            NR
          </div>
          <div>
            <h1 className="font-black tracking-tight text-lg text-amber-400">
              NAFIS RIDE <span className="text-sm text-slate-300 font-semibold">• नफीस राइड</span>
            </h1>
            <p className="text-[11px] text-slate-400 font-medium">
              Alwar District Mobility Network • Founder: {FOUNDER_NAME}
            </p>
          </div>
        </div>

        <div className="bg-emerald-500/10 border border-emerald-500/30 px-2.5 py-1 rounded-full text-[10px] font-bold text-emerald-400 flex items-center gap-1 shadow-sm">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          <span>Production Ready</span>
        </div>
      </div>

      {/* Center Corporate Presentation & Instant Auth Card */}
      <div className="w-full max-w-md my-auto py-5 space-y-4">
        {/* Sleek Minimalist Brand Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
          <div className="flex items-center gap-2 text-amber-400 font-bold text-xs uppercase tracking-wider mb-2">
            <Zap className="w-4 h-4 text-amber-400" />
            <span>Smart Urban Mobility System</span>
          </div>

          <h2 className="text-2xl font-black text-white tracking-tight leading-snug">
            अलवर में सबसे तेज़ और सुरक्षित राइड पार्टनर
          </h2>

          <p className="text-xs text-slate-400 mt-2 leading-relaxed">
            रैपिडो से 25% कम किराया, 100% सत्यापित स्थानीय चालक और 30 किमी परिधि में हर गली-मोहल्ले तक त्वरित पहुंच।
          </p>

          {/* Feature Bullets */}
          <div className="space-y-2.5 mt-5 pt-4 border-t border-slate-800/80 text-xs">
            <div className="flex items-start gap-2.5 text-slate-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              <span><strong>3-Minute Arrival:</strong> अलवर सिटी, कटी घाटी व किशनगढ़ बास में त्वरित पिकअप</span>
            </div>
            <div className="flex items-start gap-2.5 text-slate-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              <span><strong>12% Transparent Fee:</strong> 88% सीधा कैप्टन के खाते में, बिना किसी छिपे शुल्क के</span>
            </div>
            <div className="flex items-start gap-2.5 text-slate-300">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              <span><strong>24/7 SOS Emergency:</strong> संस्थापक नफीस ख़ान कंट्रोल रूम से सीधा संपर्क</span>
            </div>
          </div>
        </div>

        {/* Instant Phone Number Auth Card */}
        <form
          onSubmit={handleQuickLoginAndStart}
          className="bg-slate-900 border border-amber-500/30 rounded-3xl p-5 shadow-xl space-y-3"
        >
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-slate-200 flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-amber-400" />
              <span>त्वरित मोबाइल लॉगिन (Quick Auth)</span>
            </span>
            <span className="text-[10px] text-amber-400 font-mono font-bold">Fast2SMS OTP DLT</span>
          </div>

          <div className="relative">
            <div className="absolute left-3.5 top-1/2 -translate-y-1/2 flex items-center gap-1.5 text-xs font-bold text-slate-400 border-r border-slate-700 pr-2 pointer-events-none">
              <span>🇮🇳</span>
              <span>+91</span>
            </div>
            <input
              type="tel"
              maxLength={10}
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, ''))}
              placeholder="10-Digit Mobile Number"
              className="w-full bg-slate-950 border border-slate-700 rounded-2xl pl-20 pr-4 py-3.5 text-white font-mono font-bold text-sm tracking-wider focus:outline-none focus:border-amber-400 transition-colors"
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            id="btn-get-started-ride"
            className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black text-sm rounded-2xl shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 active:scale-[0.99] transition-all"
          >
            <span>{isSubmitting ? 'लॉगिन हो रहा है...' : 'सफ़र शुरू करें (Enter Nafis Ride)'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Live Metrics Strip */}
        <div className="grid grid-cols-3 gap-2 text-center text-xs">
          <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-2.5">
            <div className="font-mono font-black text-amber-400 text-base">₹20</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Base Fare</div>
          </div>
          <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-2.5">
            <div className="font-mono font-black text-emerald-400 text-base">30 KM</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Alwar Radius</div>
          </div>
          <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-2.5">
            <div className="font-mono font-black text-cyan-400 text-base">3.8 Min</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Avg Pickup</div>
          </div>
        </div>
      </div>

      {/* Bottom Compliance & Founder Tagline */}
      <div className="w-full max-w-md pb-4 text-center space-y-1">
        <p className="text-xs font-bold text-amber-400/90 tracking-wide">
          {FOUNDER_TAGLINE}
        </p>
        <p className="text-[10px] text-slate-500">
          Helpline: <span className="text-slate-400 font-mono">{FOUNDER_SOS_HOTLINE}</span> • Email: <a href={`mailto:${SUPPORT_EMAIL}`} className="text-amber-400/80 underline">{SUPPORT_EMAIL}</a>
        </p>
      </div>
    </div>
  );
};
