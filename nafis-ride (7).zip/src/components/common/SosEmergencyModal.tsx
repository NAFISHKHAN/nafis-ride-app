import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  ShieldAlert,
  PhoneCall,
  Radio,
  AlertTriangle,
  X,
  Siren,
  CheckCircle2,
  Send,
  MessageSquare,
  ExternalLink,
  Copy,
  Check,
  RefreshCw,
  MapPin,
  Loader2,
  Navigation,
  Compass,
  Crosshair,
  ToggleLeft,
  ToggleRight,
  Radar,
  BellRing,
} from 'lucide-react';
import { rideStore, calculateDistanceKm } from '../../services/store';
import { audioService } from '../../services/audioService';
import {
  FOUNDER_NAME,
  FOUNDER_SOS_HOTLINE,
  SUPPORT_EMAIL,
  ADMIN_EMERGENCY_NUMBER,
  ALWAR_CENTER_COORDS,
  MAX_RIDE_LIMIT_KM,
  OPERATIONAL_ZONES,
} from '../../data/constants';
import { mockSmsService, SmsReceipt } from '../../services/smsService';

interface SosEmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  role: 'passenger' | 'captain';
  userName: string;
  userPhone: string;
  currentLocation?: {
    lat: number;
    lng: number;
    address: string;
  };
}

interface GpsPoint {
  lat: number;
  lng: number;
  accuracy?: number;
  address: string;
  landmarkName: string;
  source: 'live_device' | 'kati_ghati' | 'alwar_core' | 'shital_kat' | 'outside_geofence';
}

const GEOFENCE_PRESETS: { id: GpsPoint['source']; label: string; lat: number; lng: number; address: string }[] = [
  {
    id: 'kati_ghati',
    label: 'Kati Ghati Pass (अलवर घाटी)',
    lat: 27.5685,
    lng: 76.5912,
    address: 'Kati Ghati Mountain Pass, Alwar Hills, Rajasthan',
  },
  {
    id: 'alwar_core',
    label: 'Alwar Core (होप सर्कस)',
    lat: 27.553,
    lng: 76.6346,
    address: 'Hope Circus, Company Bagh, Alwar Junction',
  },
  {
    id: 'shital_kat',
    label: 'Shital Kat (शीतल कट)',
    lat: 27.521,
    lng: 76.671,
    address: 'Shital Kat Industrial Junction, Alwar',
  },
  {
    id: 'outside_geofence',
    label: 'Outside Geofence (जयपुर मार्ग 45KM)',
    lat: 27.12,
    lng: 76.12,
    address: 'NH-21 Highway (Outside 30KM Alwar Geofence)',
  },
];

export const SosEmergencyModal: React.FC<SosEmergencyModalProps> = ({
  isOpen,
  onClose,
  role,
  userName,
  userPhone,
  currentLocation,
}) => {
  const [sirenActive, setSirenActive] = useState(false);
  const [sirenIntervalId, setSirenIntervalId] = useState<number | null>(null);
  const [broadcastSent, setBroadcastSent] = useState(false);
  const [alertId, setAlertId] = useState<string | null>(null);

  const [isSendingSms, setIsSendingSms] = useState(false);
  const [smsReceipt, setSmsReceipt] = useState<SmsReceipt | null>(null);
  const [smsError, setSmsError] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  const activeRide = rideStore.getActiveRide();

  const [currentGps, setCurrentGps] = useState<GpsPoint>(() => {
    if (currentLocation) {
      return {
        lat: currentLocation.lat,
        lng: currentLocation.lng,
        address: currentLocation.address,
        landmarkName: currentLocation.address,
        source: 'live_device',
      };
    }
    if (activeRide?.pickupLocation) {
      return {
        lat: activeRide.pickupLocation.lat,
        lng: activeRide.pickupLocation.lng,
        address: activeRide.pickupLocation.name,
        landmarkName: activeRide.pickupLocation.name,
        source: 'live_device',
      };
    }
    return {
      lat: 27.5685,
      lng: 76.5912,
      address: 'Kati Ghati Mountain Pass, Alwar Hills, Rajasthan',
      landmarkName: 'Kati Ghati Pass (अलवर घाटी)',
      source: 'kati_ghati',
    };
  });

  const [isGpsWatching] = useState(true);
  const [gpsWatchCount, setGpsWatchCount] = useState(1);

  const [emergencyStatusToggled, setEmergencyStatusToggled] = useState(false);
  const [autoSosTriggered, setAutoSosTriggered] = useState(false);
  const autoTriggerLockRef = useRef(false);

  const distanceFromCenter = calculateDistanceKm(
    currentGps.lat,
    currentGps.lng,
    ALWAR_CENTER_COORDS.lat,
    ALWAR_CENTER_COORDS.lng
  );
  const isInsideGeofence = distanceFromCenter <= MAX_RIDE_LIMIT_KM;

  const distanceToKatiGhati = calculateDistanceKm(currentGps.lat, currentGps.lng, 27.5685, 76.5912);
  const isNearKatiGhati = distanceToKatiGhati <= 2.5;

  let nearestZone = OPERATIONAL_ZONES[0];
  let minZoneDist = 9999;
  OPERATIONAL_ZONES.forEach((zone) => {
    const d = calculateDistanceKm(currentGps.lat, currentGps.lng, zone.lat, zone.lng);
    if (d < minZoneDist) {
      minZoneDist = d;
      nearestZone = zone;
    }
  });

  const automatedLocationLink = `https://maps.google.com/?q=${currentGps.lat.toFixed(5)},${currentGps.lng.toFixed(5)}`;

  const sendEmergencySmsAlert = useCallback(
    async (customAlertLabel?: string): Promise<SmsReceipt | null> => {
      setIsSendingSms(true);
      setSmsError(null);

      try {
        const receipt = await mockSmsService.sendEmergencySms({
          to: ADMIN_EMERGENCY_NUMBER,
          senderName: userName || 'Alwar Resident',
          senderPhone: userPhone || '+91 98295 12044',
          role,
          alertType: customAlertLabel || 'Urgent Help Needed',
          locationLink: automatedLocationLink,
          coordinates: {
            lat: currentGps.lat,
            lng: currentGps.lng,
            address: currentGps.address,
          },
          notes: `Emergency alert triggered within Alwar geofence (${currentGps.landmarkName || nearestZone.name}, ${distanceFromCenter}km from Hope Circus).`,
        });

        setSmsReceipt(receipt);
        audioService.playChime('milestone');

        if (alertId) {
          rideStore.updateSosAlertSmsReceipt(alertId, {
            messageId: receipt.messageId,
            recipient: receipt.to,
            status: receipt.status,
            deliveredAt: receipt.deliveredAt,
            alertType: receipt.alertType,
            locationLink: receipt.locationLink,
          });
        }

        return receipt;
      } catch (err: unknown) {
        const errorMsg =
          err instanceof Error ? err.message : 'Failed to dispatch emergency SMS via Fast2SMS gateway.';
        setSmsError(errorMsg);
        audioService.playChime('sos');
        return null;
      } finally {
        setIsSendingSms(false);
      }
    },
    [alertId, automatedLocationLink, currentGps, distanceFromCenter, nearestZone.name, role, userName, userPhone]
  );

  const triggerAutoSosDispatch = useCallback(async () => {
    if (autoTriggerLockRef.current) return;
    autoTriggerLockRef.current = true;
    setAutoSosTriggered(true);
    setBroadcastSent(true);

    const landmarkText = isNearKatiGhati
      ? `Kati Ghati Pass (Near Alwar Hills)`
      : `${currentGps.landmarkName || nearestZone.name}`;

    const triggerNotes = `[AUTO GPS GEOFENCE TRIGGER] User verified inside Alwar 30KM radius (${landmarkText} - ${distanceFromCenter} KM from Center) with Emergency Status ACTIVE.`;

    const alert = rideStore.triggerSosEmergency(
      role,
      userName,
      userPhone,
      triggerNotes,
      { lat: currentGps.lat, lng: currentGps.lng }
    );
    setAlertId(alert.id);
    audioService.playChime('sos');

    const receipt = await sendEmergencySmsAlert(
      isNearKatiGhati ? 'Urgent Help Needed (Kati Ghati Auto-SOS)' : 'Urgent Help Needed (Auto-SOS)'
    );

    if (receipt) {
      rideStore.updateSosAlertSmsReceipt(alert.id, {
        messageId: receipt.messageId,
        recipient: receipt.to,
        status: receipt.status,
        deliveredAt: receipt.deliveredAt,
        alertType: receipt.alertType,
        locationLink: receipt.locationLink,
      });
    }
  }, [currentGps, distanceFromCenter, isNearKatiGhati, nearestZone.name, role, sendEmergencySmsAlert, userName, userPhone]);

  useEffect(() => {
    if (!isOpen || !isGpsWatching) return;

    let watchId: number | null = null;
    if ('geolocation' in navigator) {
      try {
        watchId = navigator.geolocation.watchPosition(
          (pos) => {
            setGpsWatchCount((c) => c + 1);
            setCurrentGps((prev) => {
              if (prev.source !== 'live_device') return prev;
              return {
                lat: pos.coords.latitude,
                lng: pos.coords.longitude,
                accuracy: Math.round(pos.coords.accuracy),
                address: `Live Device GPS (${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)})`,
                landmarkName: 'Live Device GPS Fix',
                source: 'live_device',
              };
            });
          },
          () => {},
          { enableHighAccuracy: true, timeout: 8000, maximumAge: 4000 }
        );
      } catch (e: unknown) {
        console.warn('Geolocation watch notice:', e);
      }
    }

    return () => {
      if (watchId !== null && 'geolocation' in navigator) {
        navigator.geolocation.clearWatch(watchId);
      }
    };
  }, [isOpen, isGpsWatching]);

  useEffect(() => {
    if (isOpen && emergencyStatusToggled && isInsideGeofence && !autoSosTriggered && !autoTriggerLockRef.current) {
      triggerAutoSosDispatch();
    }
  }, [isOpen, emergencyStatusToggled, isInsideGeofence, autoSosTriggered, triggerAutoSosDispatch]);

  useEffect(() => {
    if (!isOpen) {
      if (sirenIntervalId) clearInterval(sirenIntervalId);
      setSirenIntervalId(null);
      setSirenActive(false);
      setCopiedLink(false);
      setEmergencyStatusToggled(false);
      setAutoSosTriggered(false);
      autoTriggerLockRef.current = false;
    }
  }, [isOpen, sirenIntervalId]);

  if (!isOpen) return null;

  const handleToggleSiren = () => {
    if (sirenActive) {
      if (sirenIntervalId) clearInterval(sirenIntervalId);
      setSirenIntervalId(null);
      setSirenActive(false);
    } else {
      setSirenActive(true);
      audioService.playChime('sos');
      const id = window.setInterval(() => {
        audioService.playChime('sos');
      }, 1400);
      setSirenIntervalId(id);
    }
  };

  const handleToggleEmergencyStatus = () => {
    const nextState = !emergencyStatusToggled;
    setEmergencyStatusToggled(nextState);

    if (nextState) {
      audioService.playChime('sos');
      if (isInsideGeofence && !autoSosTriggered && !autoTriggerLockRef.current) {
        triggerAutoSosDispatch();
      }
    } else {
      setAutoSosTriggered(false);
      autoTriggerLockRef.current = false;
    }
  };

  const handleSelectPresetGps = (preset: (typeof GEOFENCE_PRESETS)[0]) => {
    setCurrentGps({
      lat: preset.lat,
      lng: preset.lng,
      address: preset.address,
      landmarkName: preset.label,
      source: preset.id,
    });
    setGpsWatchCount((c) => c + 1);
  };

  const handleBroadcastAlert = async () => {
    const alert = rideStore.triggerSosEmergency(
      role,
      userName,
      userPhone,
      currentGps.address,
      { lat: currentGps.lat, lng: currentGps.lng }
    );
    setAlertId(alert.id);
    setBroadcastSent(true);
    audioService.playChime('sos');

    const receipt = await sendEmergencySmsAlert('Urgent Help Needed');
    if (receipt) {
      rideStore.updateSosAlertSmsReceipt(alert.id, {
        messageId: receipt.messageId,
        recipient: receipt.to,
        status: receipt.status,
        deliveredAt: receipt.deliveredAt,
        alertType: receipt.alertType,
        locationLink: receipt.locationLink,
      });
    }
  };

  const handleCopyLocationLink = () => {
    if (navigator?.clipboard) {
      navigator.clipboard.writeText(automatedLocationLink);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleClose = () => {
    if (sirenIntervalId) clearInterval(sirenIntervalId);
    setSirenIntervalId(null);
    setSirenActive(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border-2 border-red-600 rounded-3xl max-w-lg w-full p-5 sm:p-6 shadow-2xl text-white relative animate-in fade-in zoom-in duration-200 my-auto max-h-[94vh] overflow-y-auto">
        <button
          onClick={handleClose}
          id="btn-close-sos"
          className="absolute top-4 right-4 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors z-10"
          title="Close Emergency Modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-3 pr-10">
          <div className="w-12 h-12 rounded-2xl bg-red-600/20 border-2 border-red-500 flex items-center justify-center flex-shrink-0 animate-pulse">
            <ShieldAlert className="w-7 h-7 text-red-500" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-extrabold text-red-500 tracking-wide">FOUNDER SOS 🆘</h2>
              <span className="text-[10px] bg-red-950 text-red-300 border border-red-800 px-2 py-0.5 rounded-md font-bold">
                PRIORITY 1
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Personal Safety Dispatch by <span className="text-amber-400 font-bold">{FOUNDER_NAME}</span>
            </p>
          </div>
        </div>

        {/* EMERGENCY STATUS TOGGLE SWITCH */}
        <div
          id="emergency-status-toggle-card"
          className={`p-4 rounded-2xl border-2 transition-all mb-4 ${
            emergencyStatusToggled
              ? 'bg-red-950/70 border-red-500 shadow-xl shadow-red-900/30 ring-2 ring-red-500/50'
              : 'bg-slate-950 border-slate-800'
          }`}
        >
          <div className="flex items-center justify-between gap-3">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <BellRing
                  className={`w-4 h-4 ${emergencyStatusToggled ? 'text-red-400 animate-bounce' : 'text-slate-400'}`}
                />
                <span className="text-xs font-black uppercase tracking-wider text-slate-200">
                  आपातकालीन स्थिति स्विच (Emergency Status Toggle)
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-snug">
                {emergencyStatusToggled
                  ? 'सक्रिय (ACTIVE): जीपीएस वॉचर द्वारा अलवर जियोफेंस (उदा. कटी घाटी) में आते ही स्वतः SOS ट्रिगर होगा।'
                  : 'टॉगल करें: जैसे ही यह स्थिति सक्रिय होगी, अलवर रेडियस में स्वतः SOS व SMS भेजा जाएगा।'}
              </p>
            </div>

            <button
              type="button"
              id="btn-toggle-emergency-status"
              onClick={handleToggleEmergencyStatus}
              className={`flex-shrink-0 px-3 py-1.5 rounded-xl font-black text-xs flex items-center gap-1.5 transition-all shadow-md active:scale-95 ${
                emergencyStatusToggled
                  ? 'bg-red-600 hover:bg-red-500 text-white ring-2 ring-red-400 animate-pulse'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700'
              }`}
            >
              {emergencyStatusToggled ? (
                <>
                  <ToggleRight className="w-5 h-5 text-white" />
                  <span>ACTIVE</span>
                </>
              ) : (
                <>
                  <ToggleLeft className="w-5 h-5 text-slate-400" />
                  <span>ARM SOS</span>
                </>
              )}
            </button>
          </div>

          {emergencyStatusToggled && (
            <div className="mt-3 pt-2.5 border-t border-red-800/60 text-xs">
              {isInsideGeofence ? (
                <div className="flex items-center gap-2 text-red-300 font-semibold bg-red-900/40 p-2.5 rounded-xl border border-red-700/60">
                  <Radar className="w-4 h-4 text-red-400 animate-spin" />
                  <span>
                    {autoSosTriggered
                      ? `🚨 स्वतः SOS ट्रिगर हुआ: यूजर अलवर जियोफेंस (${currentGps.landmarkName || 'कटी घाटी'}) में डिटेक्ट हुआ!`
                      : `📡 जियोफेंस डिटेक्टेड: ऑटो-SOS डिस्पैच तैयार है...`}
                  </span>
                </div>
              ) : (
                <div className="flex items-center gap-2 text-amber-300 text-[11px] bg-amber-950/40 p-2.5 rounded-xl border border-amber-700/60">
                  <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0" />
                  <span>
                    अलवर सीमा से बाहर ({distanceFromCenter} KM). जैसे ही आप 30 KM रेडियस (उदा. कटी घाटी) में प्रवेश करेंगे, SOS स्वतः ट्रिगर होगा।
                  </span>
                </div>
              )}
            </div>
          )}
        </div>

        {/* GPS WATCHER & GEOFENCE RADAR PANEL */}
        <div className="bg-slate-950 border border-slate-800 rounded-2xl p-3.5 mb-4 text-xs space-y-2.5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-amber-400 animate-pulse" />
              <span className="font-extrabold text-slate-200">GPS WATCHER • LIVE RADAR</span>
              <span className="text-[10px] bg-slate-900 text-amber-400 border border-amber-500/30 px-1.5 py-0.5 rounded font-mono">
                Ping #{gpsWatchCount}
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <span
                className={`w-2 h-2 rounded-full ${isInsideGeofence ? 'bg-emerald-400 animate-ping' : 'bg-red-500'}`}
              />
              <span
                className={`text-[10px] font-bold uppercase ${
                  isInsideGeofence ? 'text-emerald-400' : 'text-red-400'
                }`}
              >
                {isInsideGeofence ? 'अलवर सीमा में (INSIDE GEOFENCE)' : 'जियोफेंस से बाहर (>30KM)'}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 bg-slate-900/90 p-2.5 rounded-xl border border-slate-800">
            <div>
              <span className="text-slate-400 text-[10px] block">Live Lat/Lng:</span>
              <span className="font-mono text-slate-200 font-semibold text-[11px]">
                {currentGps.lat.toFixed(5)}, {currentGps.lng.toFixed(5)}
              </span>
            </div>
            <div>
              <span className="text-slate-400 text-[10px] block">Dist from Alwar Center:</span>
              <span
                className={`font-mono font-bold text-[11px] ${
                  isInsideGeofence ? 'text-emerald-400' : 'text-amber-400'
                }`}
              >
                {distanceFromCenter} KM <span className="text-[10px] text-slate-400 font-normal">/ Max 30KM</span>
              </span>
            </div>
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-300">
            <div className="flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
              <span className="font-semibold">{currentGps.landmarkName || currentGps.address}</span>
            </div>
            {isNearKatiGhati && (
              <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded-md font-bold text-[10px]">
                ⛰️ कटी घाटी (Kati Ghati Detected)
              </span>
            )}
          </div>

          <div className="pt-1.5 border-t border-slate-900">
            <span className="text-[10px] text-slate-400 block mb-1.5 font-medium">
              Geofence Watcher Test Presets:
            </span>
            <div className="grid grid-cols-2 gap-1.5">
              {GEOFENCE_PRESETS.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => handleSelectPresetGps(preset)}
                  className={`px-2 py-1.5 rounded-lg text-[10px] font-semibold text-left truncate transition-colors flex items-center gap-1.5 ${
                    currentGps.source === preset.id
                      ? 'bg-amber-500 text-slate-950 font-bold shadow'
                      : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800'
                  }`}
                  title={preset.address}
                >
                  <Crosshair className="w-3 h-3 flex-shrink-0" />
                  <span className="truncate">{preset.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Automated Location Link */}
        <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-3 mb-4 text-xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="flex items-center gap-1 font-semibold text-slate-300">
              <Navigation className="w-3.5 h-3.5 text-amber-400" />
              आपातकालीन लाइव लोकेशन लिंक (GPS Link)
            </span>
            <button
              onClick={handleCopyLocationLink}
              className="text-[10px] text-amber-400 hover:text-amber-300 flex items-center gap-1 font-mono font-bold"
              title="Copy GPS link"
            >
              {copiedLink ? (
                <>
                  <Check className="w-3 h-3 text-emerald-400" />
                  <span className="text-emerald-400">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span>Copy Link</span>
                </>
              )}
            </button>
          </div>
          <p className="text-slate-200 font-medium">{currentGps.address}</p>
          <div className="mt-1 flex items-center gap-2 font-mono text-[11px] text-amber-400/90 break-all">
            <a
              href={automatedLocationLink}
              target="_blank"
              rel="noreferrer"
              className="underline flex items-center gap-1 hover:text-amber-300"
            >
              <span>{automatedLocationLink}</span>
              <ExternalLink className="w-3 h-3 inline flex-shrink-0" />
            </a>
          </div>
        </div>

        {/* BROADCAST & SMS SECTION */}
        <div className="space-y-3 mb-4">
          {broadcastSent ? (
            <div className="bg-emerald-950/70 border border-emerald-500/70 rounded-xl p-3.5 flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
              <div className="w-full">
                <div className="text-xs font-bold text-emerald-300 flex items-center justify-between">
                  <span>
                    {autoSosTriggered
                      ? '⚡ AUTO-SOS GEOFENCE DISPATCH TRANSMITTED!'
                      : 'EMERGENCY DISPATCH TRANSMITTED!'}
                  </span>
                  <span className="font-mono text-white text-[11px] bg-emerald-900/80 px-2 py-0.5 rounded">
                    Ticket: {alertId}
                  </span>
                </div>
                <p className="text-[11px] text-emerald-200/80 mt-1">
                  Alert broadcasted to Founder Nafis Khan command board and rapid response team.
                  {isNearKatiGhati && ' (Location: Kati Ghati Pass, Alwar Hills).'}
                </p>
              </div>
            </div>
          ) : (
            <button
              onClick={handleBroadcastAlert}
              disabled={isSendingSms}
              id="btn-broadcast-emergency"
              className="w-full py-3.5 bg-red-600 hover:bg-red-500 active:scale-[0.98] text-white font-extrabold text-sm rounded-xl shadow-lg shadow-red-600/30 flex items-center justify-center gap-2 transition-transform disabled:opacity-75"
            >
              <Radio className="w-4 h-4 animate-ping" />
              <span>कंट्रोल रूम को तुरंत लाइव अलर्ट भेजें (Send Live Alert)</span>
            </button>
          )}

          {/* SMS DISPATCH MODULE */}
          <div className="bg-slate-950 border border-amber-500/40 rounded-2xl p-3.5 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-amber-400" />
                <span className="text-xs font-extrabold text-amber-300">
                  AUTOMATED EMERGENCY SMS GATEWAY
                </span>
              </div>
              <span className="text-[10px] bg-slate-900 border border-slate-700 text-slate-300 px-2 py-0.5 rounded font-mono">
                Admin: {ADMIN_EMERGENCY_NUMBER}
              </span>
            </div>

            {!smsReceipt && !isSendingSms && (
              <button
                type="button"
                onClick={() => sendEmergencySmsAlert('Urgent Help Needed')}
                id="btn-send-sms-emergency"
                className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs rounded-xl flex items-center justify-center gap-2 shadow-md transition-all active:scale-[0.99]"
              >
                <Send className="w-3.5 h-3.5 text-slate-950" />
                <span>एडमिन को SMS और लोकेशन लिंक भेजें (Send Urgent Help SMS)</span>
              </button>
            )}

            {isSendingSms && (
              <div className="p-3 bg-slate-900/90 rounded-xl border border-amber-500/40 flex items-center justify-center gap-2 text-xs text-amber-300">
                <Loader2 className="w-4 h-4 animate-spin text-amber-400" />
                <span>Transmitting &apos;Urgent Help Needed&apos; SMS + GPS link via Fast2SMS DLT...</span>
              </div>
            )}

            {smsError && (
              <div className="p-2.5 bg-red-950/70 border border-red-500 rounded-xl text-[11px] text-red-200">
                {smsError}
              </div>
            )}

            {smsReceipt && (
              <div className="bg-slate-900/90 border border-emerald-500/60 rounded-xl p-3 text-xs space-y-2">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>TELECOM GATEWAY • {smsReceipt.status}</span>
                  </div>
                  <span className="font-mono text-[10px] text-slate-400 font-bold">
                    {smsReceipt.messageId}
                  </span>
                </div>

                <div className="space-y-1 text-[11px] text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Recipient:</span>
                    <span className="font-mono font-bold text-amber-300">{smsReceipt.to}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Alert Type:</span>
                    <span className="font-bold text-red-400">
                      🚨 &apos;{smsReceipt.alertType}&apos;
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Delivered At:</span>
                    <span className="font-mono text-slate-200">{smsReceipt.deliveredAt}</span>
                  </div>
                  <div className="flex justify-between items-center pt-1 border-t border-slate-800/80">
                    <span className="text-slate-400">Automated Link:</span>
                    <a
                      href={smsReceipt.locationLink}
                      target="_blank"
                      rel="noreferrer"
                      className="text-amber-400 underline font-mono text-[10px] flex items-center gap-1 hover:text-amber-300"
                    >
                      <span>Open Live Map</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>

                <div className="mt-2 p-2 bg-slate-950 rounded-lg border border-slate-800 font-mono text-[10px] text-slate-300 whitespace-pre-line leading-relaxed">
                  {smsReceipt.messageBody}
                </div>

                <div className="flex justify-end pt-1">
                  <button
                    type="button"
                    onClick={() => sendEmergencySmsAlert('Urgent Help Needed')}
                    disabled={isSendingSms}
                    id="btn-resend-sms"
                    className="text-[10px] text-slate-400 hover:text-amber-300 flex items-center gap-1 font-semibold transition-colors"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>Resend SMS Alert</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* URGENT CALL & SIREN */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <a
            href={`tel:${FOUNDER_SOS_HOTLINE}`}
            className="flex flex-col items-center justify-center gap-1.5 p-3.5 bg-slate-800 hover:bg-slate-700/80 border border-amber-500/40 rounded-xl text-center transition-colors"
          >
            <PhoneCall className="w-5 h-5 text-amber-400" />
            <span className="text-xs font-bold text-slate-100">नफीस ख़ान हेल्पलाइन</span>
            <span className="text-[10px] text-amber-300 font-mono">{FOUNDER_SOS_HOTLINE}</span>
          </a>

          <button
            onClick={handleToggleSiren}
            id="btn-sound-siren"
            className={`flex flex-col items-center justify-center gap-1.5 p-3.5 border rounded-xl text-center transition-all ${
              sirenActive
                ? 'bg-red-600 text-white border-red-400 animate-pulse'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
            }`}
          >
            <Siren className="w-5 h-5 text-red-400" />
            <span className="text-xs font-bold">
              {sirenActive ? 'साइरन रोकें (Stop)' : 'साइरन बजाएं (Alarm)'}
            </span>
            <span className="text-[10px] text-slate-400">Loud Panic Sound</span>
          </button>
        </div>

        {/* PUBLIC HELPLINES */}
        <div className="flex items-center justify-between gap-2 p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span className="text-slate-300 font-medium">Police (अलवर पुलिस):</span>
          </div>
          <a
            href="tel:112"
            className="bg-slate-800 hover:bg-slate-700 px-3 py-1 rounded-md text-emerald-400 font-bold font-mono"
          >
            Dial 112
          </a>
          <a
            href="tel:108"
            className="bg-slate-800 hover:bg-slate-700 px-3 py-1 rounded-md text-cyan-400 font-bold font-mono"
          >
            Ambulance 108
          </a>
        </div>

        <div className="text-center mt-3 pt-2.5 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
          <span>
            Emergency Email:{' '}
            <a href={`mailto:${SUPPORT_EMAIL}`} className="text-amber-400 underline">
              {SUPPORT_EMAIL}
            </a>
          </span>
          <span className="text-slate-500 font-mono">GEOFENCE-RADAR-ALWAR</span>
        </div>
      </div>
    </div>
  );
};
