import React, { useState, useEffect } from 'react';
import {
  Power,
  ShieldCheck,
  Wallet,
  QrCode,
  MapPin,
  Clock,
  CheckCircle2,
  FileText,
  CreditCard,
  Phone,
  AlertCircle,
  Sparkles,
  ShieldAlert,
  ArrowUpRight,
  UserCheck,
  RotateCw,
  Printer,
  Download,
  Eye,
  BadgeCheck,
  UploadCloud,
} from 'lucide-react';
import { Captain, VehicleType } from '../../types';
import { rideStore } from '../../services/store';
import { audioService } from '../../services/audioService';
import {
  FOUNDER_NAME,
  FOUNDER_TAGLINE,
  SUPPORT_EMAIL,
  FOUNDER_SOS_HOTLINE,
} from '../../data/constants';

interface CaptainHomeProps {
  onOpenSos: () => void;
}

export const CaptainHome: React.FC<CaptainHomeProps> = ({ onOpenSos }) => {
  const [captain, setCaptain] = useState<Captain | null>(rideStore.getCaptainProfile());
  const [activeRide, setActiveRide] = useState(rideStore.getActiveRide());

  const [activeTab, setActiveTab] = useState<'duty' | 'kyc' | 'wallet' | 'id_card'>('duty');
  const [idCardSide, setIdCardSide] = useState<'front' | 'back'>('front');

  const [inputOtp, setInputOtp] = useState('');
  const [otpError, setOtpError] = useState<string | null>(null);

  const [kycForm, setKycForm] = useState({
    aadhaarNumber: '5821-9482-8921',
    aadhaarPhotoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80',
    aadhaarBackPhotoUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&auto=format&fit=crop&q=80',
    drivingLicenseNumber: 'RJ-02-2021008892',
    dlPhotoUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&auto=format&fit=crop&q=80',
    dlExpiryDate: '2031-09-20',
    dlClass: 'MCWG / LMV',
    vehiclePlate: 'RJ-02-SB-4819',
    vehicleType: 'bike' as VehicleType,
    vehicleModel: 'Hero Splendor Plus (BS6)',
    rcNumber: 'RJ02SB4819',
    rcPhotoUrl: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=600&auto=format&fit=crop&q=80',
    insuranceNumber: 'NIC-ALW-2026-9812',
    insurancePhotoUrl: 'https://images.unsplash.com/photo-1450133064473-71024230f91b?w=600&auto=format&fit=crop&q=80',
    pucCertificateNumber: 'PUC-ALW-2026-OK',
    bloodGroup: 'B+',
    emergencyContact: '+91 70236 08919',
  });
  const [kycSubmittedNotice, setKycSubmittedNotice] = useState(false);

  useEffect(() => {
    const unsubscribe = rideStore.subscribe(() => {
      setCaptain(rideStore.getCaptainProfile());
      setActiveRide(rideStore.getActiveRide());
    });
    return unsubscribe;
  }, []);

  if (!captain) return null;

  const handleToggleDuty = () => {
    const isNowOnline = rideStore.toggleCaptainDuty(captain.id);
    if (isNowOnline) {
      audioService.playChime('booked');
    } else {
      audioService.playChime('milestone');
    }
  };

  const handleAcceptRide = () => {
    if (activeRide && activeRide.status === 'searching') {
      activeRide.status = 'captain_assigned';
      activeRide.captainId = captain.id;
      activeRide.captainName = captain.name;
      activeRide.captainPhone = captain.phone;
      activeRide.captainPhoto = captain.photoUrl;
      activeRide.vehiclePlate = captain.vehiclePlate;
      activeRide.vehicleModel = captain.vehicleModel;
      rideStore.saveUser();
      audioService.playChime('booked');
    }
  };

  const handleCaptainArrived = () => {
    if (activeRide) {
      activeRide.status = 'arrived';
      activeRide.arrivedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      rideStore.saveUser();
      audioService.playChime('milestone');
    }
  };

  const handleStartTripWithOtp = () => {
    setOtpError(null);
    const result = rideStore.startTrip(inputOtp);
    if (!result.success) {
      setOtpError(result.error || 'Invalid OTP');
      audioService.playChime('sos');
    } else {
      audioService.playChime('milestone');
    }
  };

  const handleCompleteTrip = () => {
    rideStore.completeTrip();
    audioService.playChime('completed');
  };

  const handleLoadSampleAlwarDocs = () => {
    setKycForm({
      aadhaarNumber: '5821-9482-8921',
      aadhaarPhotoUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80',
      aadhaarBackPhotoUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&auto=format&fit=crop&q=80',
      drivingLicenseNumber: 'RJ-02-2021008892',
      dlPhotoUrl: 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&auto=format&fit=crop&q=80',
      dlExpiryDate: '2031-09-20',
      dlClass: 'MCWG / LMV',
      vehiclePlate: 'RJ-02-SB-4819',
      vehicleType: 'bike',
      vehicleModel: 'Hero Splendor Plus (BS6)',
      rcNumber: 'RJ02SB4819',
      rcPhotoUrl: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=600&auto=format&fit=crop&q=80',
      insuranceNumber: 'NIC-ALW-2026-9812',
      insurancePhotoUrl: 'https://images.unsplash.com/photo-1450133064473-71024230f91b?w=600&auto=format&fit=crop&q=80',
      pucCertificateNumber: 'PUC-ALW-2026-OK',
      bloodGroup: 'B+',
      emergencyContact: '+91 70236 08919',
    });
    audioService.playChime('milestone');
  };

  const handleSubmitKyc = (e: React.FormEvent) => {
    e.preventDefault();
    rideStore.submitCaptainKyc(captain, kycForm);
    setKycSubmittedNotice(true);
    audioService.playChime('milestone');
    setTimeout(() => setKycSubmittedNotice(false), 4000);
  };

  return (
    <div className="relative w-full h-full flex flex-col bg-slate-950 text-slate-100 overflow-hidden select-none">
      <header className="flex-shrink-0 z-20 bg-slate-900 border-b border-slate-800 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <img
            src={captain.photoUrl}
            alt={captain.name}
            className="w-9 h-9 rounded-xl object-cover border border-amber-400 shadow"
          />
          <div>
            <div className="flex items-center gap-1.5">
              <h2 className="font-extrabold text-sm text-slate-100 leading-none">
                {captain.name}
              </h2>
              <span className="text-[9px] bg-amber-500 text-slate-950 font-black px-1.5 py-0.2 rounded">
                CAPTAIN
              </span>
            </div>
            <p className="text-[10px] text-slate-400 mt-0.5 font-mono">
              ID: NR-ALW-{captain.id.slice(-4).toUpperCase()} • ⭐ {captain.rating}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleToggleDuty}
            id="btn-toggle-captain-duty"
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-extrabold text-xs transition-all shadow-md active:scale-95 ${
              captain.isOnline
                ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/30'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-400 border border-slate-700'
            }`}
          >
            <Power className="w-3.5 h-3.5" />
            <span>{captain.isOnline ? 'ONLINE' : 'OFFLINE'}</span>
          </button>

          <button
            onClick={onOpenSos}
            id="btn-captain-sos"
            className="p-1.5 rounded-xl bg-red-600 hover:bg-red-500 text-white shadow animate-pulse"
          >
            <ShieldAlert className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Tab Navigators */}
      <nav className="flex-shrink-0 bg-slate-900/70 border-b border-slate-800 px-3 py-1.5 flex items-center justify-around text-xs">
        <button
          onClick={() => setActiveTab('duty')}
          className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
            activeTab === 'duty'
              ? 'bg-amber-500 text-slate-950 shadow'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          राइड ड्यूटी (Duty)
        </button>
        <button
          onClick={() => setActiveTab('wallet')}
          className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
            activeTab === 'wallet'
              ? 'bg-amber-500 text-slate-950 shadow'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          वॉलेट & QR
        </button>
        <button
          onClick={() => setActiveTab('id_card')}
          className={`px-3 py-1.5 rounded-lg font-bold transition-colors ${
            activeTab === 'id_card'
              ? 'bg-amber-500 text-slate-950 shadow'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          आईडी कार्ड (ID)
        </button>
        <button
          onClick={() => setActiveTab('kyc')}
          className={`px-3 py-1.5 rounded-lg font-bold flex items-center gap-1 transition-colors ${
            activeTab === 'kyc'
              ? 'bg-amber-500 text-slate-950 shadow'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>KYC</span>
          {captain.kycStatus === 'approved' ? (
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
          ) : (
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
          )}
        </button>
      </nav>

      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {activeTab === 'duty' && (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-2">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 text-center">
                <div className="text-xs text-slate-400">आज की कमाई</div>
                <div className="text-lg font-black text-amber-400 mt-0.5">
                  ₹{captain.todayEarnings}
                </div>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 text-center">
                <div className="text-xs text-slate-400">कुल राइड्स</div>
                <div className="text-lg font-black text-emerald-400 mt-0.5">
                  {captain.totalTrips}
                </div>
              </div>
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 text-center">
                <div className="text-xs text-slate-400">वॉलेट बैलेंस</div>
                <div className="text-lg font-black text-slate-100 mt-0.5">
                  ₹{captain.walletBalance}
                </div>
              </div>
            </div>

            {!captain.isOnline && (
              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 text-center space-y-2">
                <div className="w-10 h-10 mx-auto rounded-full bg-slate-800 flex items-center justify-center text-slate-400">
                  <Power className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-sm text-slate-200">आप अभी ऑफलाइन हैं (Duty is Offline)</h3>
                <p className="text-xs text-slate-400 max-w-xs mx-auto">
                  अलवर में नई सवारियों की बुकिंग स्वीकार करने के लिए ऊपर दिए गए बटन से ऑनलाइन आएं।
                </p>
                <button
                  onClick={handleToggleDuty}
                  className="px-5 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold text-xs rounded-xl shadow-lg"
                >
                  गो ऑनलाइन (Go Online Now)
                </button>
              </div>
            )}

            {captain.isOnline && activeRide && activeRide.status === 'searching' && (
              <div className="bg-gradient-to-br from-amber-950/80 via-slate-900 to-amber-950/80 border-2 border-amber-400 rounded-2xl p-4 shadow-2xl animate-pulse">
                <div className="flex items-center justify-between mb-2">
                  <span className="bg-amber-500 text-slate-950 font-black text-[10px] px-2 py-0.5 rounded-full uppercase">
                    नई सवारी अनुरोध (Incoming Ride Request)
                  </span>
                  <span className="text-xs font-mono font-bold text-amber-300">
                    ⏱️ 15s Timer
                  </span>
                </div>

                <div className="flex items-baseline justify-between my-2">
                  <div>
                    <div className="text-xs text-slate-400">यात्री: {activeRide.riderName}</div>
                    <div className="text-lg font-extrabold text-slate-100">
                      {activeRide.pickupLocation.name.split(' (')[0]}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-black text-amber-400">
                      ₹{activeRide.fare}
                    </div>
                    <span className="text-[10px] text-slate-400">{activeRide.distanceKm} KM • Cashless</span>
                  </div>
                </div>

                <div className="bg-slate-950/60 p-2.5 rounded-xl text-xs space-y-1 my-3 border border-slate-800">
                  <div className="flex items-center gap-1 text-emerald-400">
                    <MapPin className="w-3.5 h-3.5" />
                    <span>पिकअप: {activeRide.pickupLocation.name}</span>
                  </div>
                  <div className="flex items-center gap-1 text-red-400">
                    <MapPin className="w-3.5 h-3.5" />
                    <span>ड्रॉप: {activeRide.dropLocation.name}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    onClick={handleAcceptRide}
                    id="btn-accept-ride-request"
                    className="py-3 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-xs shadow-lg flex items-center justify-center gap-1"
                  >
                    <span>स्वीकार करें (Accept Ride)</span>
                  </button>
                  <button
                    onClick={() => rideStore.cancelRide()}
                    id="btn-reject-ride-request"
                    className="py-3 bg-slate-800 hover:bg-slate-700 text-slate-400 rounded-xl text-xs font-semibold"
                  >
                    अस्वीकार (Decline)
                  </button>
                </div>
              </div>
            )}

            {activeRide &&
              ['captain_assigned', 'arrived', 'in_trip'].includes(activeRide.status) && (
                <div className="bg-slate-900 border border-amber-500/50 rounded-2xl p-4 space-y-3.5 shadow-xl">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2.5">
                    <span className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                      चल रही सवारी (Active Trip in Progress)
                    </span>
                    <span className="text-xs font-mono font-bold text-slate-300">
                      Fare: ₹{activeRide.fare}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-bold text-sm text-slate-100">{activeRide.riderName}</h4>
                      <p className="text-xs text-slate-400">{activeRide.pickupLocation.name}</p>
                    </div>
                    <a
                      href={`tel:${activeRide.riderPhone}`}
                      className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 flex items-center gap-1 text-xs font-bold border border-slate-700"
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span>Call</span>
                    </a>
                  </div>

                  {activeRide.status === 'captain_assigned' && (
                    <button
                      onClick={handleCaptainArrived}
                      className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs shadow-md"
                    >
                      मैं पिकअप पर पहुँच गया (I Have Arrived)
                    </button>
                  )}

                  {activeRide.status === 'arrived' && (
                    <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-2">
                      <label className="text-xs text-slate-300 font-semibold block">
                        यात्री का 4-अंकीय OTP दर्ज करें (Enter Passenger OTP):
                      </label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          maxLength={4}
                          value={inputOtp}
                          onChange={(e) => setInputOtp(e.target.value)}
                          placeholder="Ex: 4821"
                          className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-center text-base font-mono font-bold text-amber-400 focus:outline-none focus:border-amber-400"
                        />
                        <button
                          onClick={handleStartTripWithOtp}
                          className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-xs"
                        >
                          राइड शुरू करें (Start Trip)
                        </button>
                      </div>
                      {otpError && (
                        <p className="text-[11px] text-red-400 font-bold">{otpError}</p>
                      )}
                      <p className="text-[10px] text-slate-400 flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3 text-emerald-400 inline" />
                        <span>सुरक्षा नियम: बिना यात्री के 4-अंकीय वास्तविक OTP के ट्रिप शुरू नहीं हो सकती।</span>
                      </p>
                    </div>
                  )}

                  {activeRide.status === 'in_trip' && (
                    <div className="space-y-2">
                      <div className="bg-emerald-950/40 border border-emerald-500/30 rounded-xl p-3 text-xs text-emerald-300 flex items-center justify-between">
                        <span>ड्रॉप की ओर प्रस्थान... (Heading to Drop)</span>
                        <span className="font-bold">{activeRide.dropLocation.name.split(' (')[0]}</span>
                      </div>
                      <button
                        onClick={handleCompleteTrip}
                        className="w-full py-3.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 text-slate-950 font-black rounded-xl text-xs shadow-lg shadow-emerald-500/20"
                      >
                        राइड समाप्त करें और किराया प्राप्त करें (Complete Ride)
                      </button>
                    </div>
                  )}
                </div>
              )}

            {captain.isOnline && (!activeRide || activeRide.status === 'idle') && (
              <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-6 text-center space-y-2">
                <div className="w-12 h-12 mx-auto rounded-full bg-emerald-500/15 text-emerald-400 flex items-center justify-center animate-pulse">
                  <MapPin className="w-6 h-6" />
                </div>
                <h4 className="font-bold text-sm text-slate-200">अलवर में लाइव ड्यूटी चालू है</h4>
                <p className="text-xs text-slate-400">
                  अलवर, किशनगढ़, मेव बड़ौदा, काटी घाटी या जत्याना से नई बुकिंग आते ही स्क्रीन पर साउंड अलर्ट बजेगा।
                </p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'wallet' && (
          <div className="space-y-4">
            <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-amber-950 border border-amber-500/40 rounded-3xl p-5 shadow-xl relative overflow-hidden">
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                <span>Nafis Ride Captain Wallet</span>
                <span className="font-mono text-amber-400 font-bold">ALWAR REGION</span>
              </div>
              <div className="text-3xl font-black text-amber-400 mb-3">
                ₹{captain.walletBalance}
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => {
                    alert(`₹${captain.walletBalance} payout requested to UPI ID: ${captain.upiId}. Processed by Founder Nafis Khan accounts.`);
                  }}
                  className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs flex items-center justify-center gap-1"
                >
                  <ArrowUpRight className="w-4 h-4" />
                  <span>पैसे बैंक में निकालें (Withdraw)</span>
                </button>
              </div>
            </div>

            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 text-center space-y-3">
              <div className="flex items-center justify-center gap-2 text-xs font-bold text-slate-200">
                <QrCode className="w-4 h-4 text-amber-400" />
                <span>आपका व्यक्तिगत UPI भुगतान क्यूआर कोड (Captain QR)</span>
              </div>
              <p className="text-[11px] text-slate-400 max-w-xs mx-auto">
                सवारी पूरी होने पर यात्री को यह क्यूआर कोड दिखाएं। यात्री सीधे PhonePe, Google Pay या Paytm से आपके खाते में भुगतान कर सकेंगे।
              </p>

              <div className="inline-block p-3 bg-white rounded-2xl shadow-lg">
                <img
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=upi://pay?pa=${captain.upiId}&pn=NafisRideCaptain_${captain.name.replace(/\s+/g, '')}&cu=INR`}
                  alt="Captain UPI QR"
                  className="w-44 h-44 mx-auto"
                />
              </div>

              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-xs font-mono text-amber-300">
                UPI ID: {captain.upiId}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'id_card' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-xs text-slate-300 font-bold">
                <BadgeCheck className="w-4 h-4 text-amber-400" />
                <span>डिजिटल कप्तान पहचान पत्र (Smart ID Card)</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIdCardSide(idCardSide === 'front' ? 'back' : 'front')}
                  id="btn-flip-id-card"
                  className="flex items-center gap-1 px-3 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded-xl text-xs font-bold transition-all active:scale-95"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                  <span>{idCardSide === 'front' ? 'पीछे देखें (Back)' : 'आगे देखें (Front)'}</span>
                </button>

                <button
                  onClick={() => window.print()}
                  id="btn-print-id-card"
                  className="p-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl border border-slate-700"
                  title="Print / Save ID"
                >
                  <Printer className="w-4 h-4" />
                </button>
              </div>
            </div>

            {idCardSide === 'front' ? (
              <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-amber-950/60 border-2 border-amber-500 rounded-3xl p-5 shadow-2xl relative overflow-hidden transition-all duration-300">
                <div className="absolute -top-12 -right-12 w-36 h-36 rounded-full bg-amber-500/10 border-4 border-amber-500/20 pointer-events-none transform rotate-45 flex items-center justify-center">
                  <span className="text-[10px] font-black text-amber-400/30 uppercase tracking-widest">
                    NAFIS SECURE
                  </span>
                </div>

                <div className="flex items-center justify-between border-b border-amber-500/30 pb-3 mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-9 h-9 rounded-xl bg-amber-500 text-slate-950 font-black flex items-center justify-center text-sm shadow">
                      NR
                    </div>
                    <div>
                      <h3 className="font-black text-sm text-amber-400 tracking-wider">
                        NAFIS RIDE
                      </h3>
                      <p className="text-[8px] text-slate-400 uppercase tracking-widest font-mono">
                        GOVT RECOGNIZED CAPTAIN ID
                      </p>
                    </div>
                  </div>

                  <div className="bg-emerald-500/20 border border-emerald-400/50 px-2.5 py-1 rounded-full text-[10px] font-black text-emerald-300 flex items-center gap-1 shadow-sm">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>VERIFIED</span>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="relative">
                    <img
                      src={captain.photoUrl}
                      alt={captain.name}
                      className="w-20 h-24 rounded-2xl object-cover border-2 border-amber-400 shadow-md flex-shrink-0"
                    />
                    <div className="absolute -bottom-1 -right-1 bg-amber-500 text-slate-950 rounded-full p-0.5">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                    </div>
                  </div>

                  <div className="space-y-1 text-xs flex-1">
                    <div className="text-[9px] text-slate-400 tracking-wider">CAPTAIN NAME</div>
                    <div className="text-base font-black text-white leading-tight">
                      {captain.name}
                    </div>

                    <div className="grid grid-cols-2 gap-2 mt-2 pt-1 border-t border-slate-800">
                      <div>
                        <div className="text-[9px] text-slate-400">SMART ID</div>
                        <div className="font-mono text-amber-400 font-bold text-xs">
                          NR-ALW-{captain.id.slice(-4).toUpperCase()}
                        </div>
                      </div>
                      <div>
                        <div className="text-[9px] text-slate-400">BLOOD GROUP</div>
                        <div className="font-mono text-red-400 font-bold text-xs">
                          {captain.bloodGroup || 'B+'}
                        </div>
                      </div>
                    </div>

                    <div className="pt-1">
                      <div className="text-[9px] text-slate-400">VEHICLE & PLATE</div>
                      <div className="text-slate-200 font-mono font-bold text-xs">
                        {captain.vehiclePlate} ({captain.vehicleType.toUpperCase()})
                      </div>
                      <div className="text-[10px] text-slate-400">{captain.vehicleModel}</div>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                  <div>
                    <div className="text-[8px] text-slate-400 uppercase">Valid Operating Radius</div>
                    <div className="text-[11px] font-bold text-slate-200">
                      Alwar District (Max 30 KM)
                    </div>
                    <div className="text-[8px] text-amber-400/90 font-mono">
                      VALID TILL: {captain.idCardIssuedDate ? '2028-12-31' : 'ACTIVE'}
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="font-shayari text-sm text-amber-400 font-bold">
                      नफीस ख़ान ({FOUNDER_NAME})
                    </div>
                    <div className="text-[8px] text-slate-400 uppercase tracking-wider">
                      संस्थापक / Founder & Chief Executive
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 border-2 border-slate-700 rounded-3xl p-5 shadow-2xl relative overflow-hidden transition-all duration-300 space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="text-[11px] font-black text-amber-400 uppercase tracking-wider">
                    Official Verification & Compliance
                  </div>
                  <span className="text-[9px] font-mono text-slate-400">
                    ID: NR-ALW-{captain.id.slice(-4).toUpperCase()}
                  </span>
                </div>

                <div className="flex items-center gap-4">
                  <div className="bg-white p-2 rounded-xl flex-shrink-0 shadow">
                    <img
                      src={`https://api.qrserver.com/v1/create-qr-code/?size=100x100&data=https://nafisride.in/verify?id=${captain.id}`}
                      alt="Verification QR"
                      className="w-20 h-20"
                    />
                  </div>

                  <div className="text-[11px] space-y-1 text-slate-300 font-mono flex-1">
                    <div>
                      <span className="text-slate-500">DL NO: </span>
                      <span className="text-white font-bold">
                        {captain.kycDocs?.drivingLicenseNumber || 'RJ-02-2021008892'}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500">DL EXPIRY: </span>
                      <span className="text-emerald-400 font-bold">
                        {captain.kycDocs?.dlExpiryDate || '2031-09-20'}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500">AADHAAR: </span>
                      <span className="text-slate-200">
                        {captain.kycDocs?.aadhaarNumber ? `XXXX-XXXX-${captain.kycDocs.aadhaarNumber.slice(-4)}` : 'XXXX-XXXX-8921'}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500">RC NO: </span>
                      <span className="text-amber-400">
                        {captain.kycDocs?.rcNumber || captain.vehiclePlate.replace(/-/g, '')}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-[10px] space-y-1 text-slate-400">
                  <div className="flex items-center justify-between">
                    <span>24/7 Founder Control Room:</span>
                    <span className="text-amber-400 font-bold font-mono">{FOUNDER_SOS_HOTLINE}</span>
                  </div>
                  <div>
                    Emergency Contact: <span className="text-white font-bold">{captain.emergencyContact || '+91 70236 08919'}</span>
                  </div>
                  <p className="text-[9px] text-slate-500 pt-1 border-t border-slate-900 leading-tight">
                    This card is non-transferable property of Nafis Ride / नफीस राइड (Founded strictly by Nafis Khan / नफीस ख़ान). Must be produced upon demand by Alwar traffic police.
                  </p>
                </div>
              </div>
            )}

            <div className="text-center text-xs text-slate-400 flex items-center justify-center gap-1">
              <span>चेकिंग या सवारी के दौरान यह डिजिटल आईडी दिखाएं।</span>
            </div>
          </div>
        )}

        {activeTab === 'kyc' && (
          <div className="space-y-4">
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <h3 className="font-extrabold text-sm text-slate-100 flex items-center gap-2">
                    <FileText className="w-4 h-4 text-amber-400" />
                    <span>ड्राइवर KYC सत्यापन (Driver Document Verification)</span>
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    अलवर में सुरक्षित राइड के लिए आधार, DL व RC दस्तावेज़ अनिवार्य हैं।
                  </p>
                </div>

                <span
                  className={`text-[10px] px-2.5 py-0.5 rounded-full font-black uppercase tracking-wider ${
                    captain.kycStatus === 'approved'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-500/40'
                      : captain.kycStatus === 'rejected'
                      ? 'bg-red-950 text-red-400 border border-red-500/40'
                      : 'bg-amber-950 text-amber-400 border border-amber-500/40'
                  }`}
                >
                  {captain.kycStatus}
                </span>
              </div>

              {captain.kycStatus === 'approved' && (
                <div className="mb-3 p-3 bg-emerald-950/70 border border-emerald-500/60 rounded-xl text-xs text-emerald-300 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                    <div>
                      <div className="font-black">दस्तावेज़ सत्यापित एवं स्वीकृत (KYC Approved)</div>
                      <div className="text-[10px] text-emerald-400/80">आपका स्मार्ट पहचान पत्र सक्रिय कर दिया गया है।</div>
                    </div>
                  </div>
                  <button
                    onClick={() => setActiveTab('id_card')}
                    className="px-2.5 py-1 bg-emerald-500 text-slate-950 font-bold rounded-lg text-[10px]"
                  >
                    स्मार्ट कार्ड देखें
                  </button>
                </div>
              )}

              {kycSubmittedNotice && (
                <div className="mb-3 p-3 bg-emerald-950 border border-emerald-500 rounded-xl text-xs text-emerald-300 flex items-center gap-2 animate-fadeIn">
                  <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                  <span>KYC दस्तावेज़ सफलतापूर्वक जमा कर दिए गए हैं! व्यवस्थापक समीक्षा प्रक्रिया में हैं।</span>
                </div>
              )}

              <div className="mb-3 p-2.5 bg-slate-950/80 border border-dashed border-amber-500/40 rounded-xl flex items-center justify-between">
                <span className="text-[11px] text-slate-300">त्वरित टेस्टिंग हेतु असली जैसे दस्तावेज़ भरें:</span>
                <button
                  type="button"
                  onClick={handleLoadSampleAlwarDocs}
                  className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/50 text-amber-300 font-bold text-[10px] rounded-lg flex items-center gap-1 active:scale-95"
                >
                  <Sparkles className="w-3 h-3 text-amber-400" />
                  <span>अलवर सैंपल लोड करें</span>
                </button>
              </div>

              <form onSubmit={handleSubmitKyc} className="space-y-3.5 text-xs">
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-slate-300 font-bold block">
                      1. आधार कार्ड नंबर (12-Digit Aadhaar UID)
                    </label>
                    <span className="text-[10px] text-emerald-400 font-mono">UIDAI Verified</span>
                  </div>
                  <input
                    type="text"
                    required
                    value={kycForm.aadhaarNumber}
                    onChange={(e) => setKycForm({ ...kycForm, aadhaarNumber: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-amber-400"
                    placeholder="XXXX-XXXX-8921"
                  />
                  <div className="grid grid-cols-2 gap-2 pt-1">
                    <div className="p-2 bg-slate-900 border border-slate-800 rounded-lg text-center">
                      <div className="text-[9px] text-slate-400 mb-1">आधार आगे की फोटो (Front)</div>
                      <div className="h-12 bg-slate-950 rounded border border-slate-800 flex items-center justify-center text-[10px] text-amber-400 font-mono overflow-hidden">
                        <img src={kycForm.aadhaarPhotoUrl} alt="Aadhaar Front" className="w-full h-full object-cover" />
                      </div>
                    </div>
                    <div className="p-2 bg-slate-900 border border-slate-800 rounded-lg text-center">
                      <div className="text-[9px] text-slate-400 mb-1">आधार पीछे की फोटो (Back)</div>
                      <div className="h-12 bg-slate-950 rounded border border-slate-800 flex items-center justify-center text-[10px] text-amber-400 font-mono overflow-hidden">
                        <img src={kycForm.aadhaarBackPhotoUrl} alt="Aadhaar Back" className="w-full h-full object-cover" />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-slate-300 font-bold block">
                      2. ड्राइविंग लाइसेंस विवरण (Driving License DL)
                    </label>
                    <span className="text-[10px] text-amber-400 font-mono">Transport Dept RJ-02</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-0.5">लाइसेंस नंबर (DL Number)</span>
                      <input
                        type="text"
                        required
                        value={kycForm.drivingLicenseNumber}
                        onChange={(e) => setKycForm({ ...kycForm, drivingLicenseNumber: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-amber-400"
                        placeholder="RJ-02-2021008892"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-400 block mb-0.5">वैधता समाप्ति (DL Expiry)</span>
                      <input
                        type="date"
                        required
                        value={kycForm.dlExpiryDate}
                        onChange={(e) => setKycForm({ ...kycForm, dlExpiryDate: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                  <label className="text-slate-300 font-bold block">
                    3. वाहन पंजीकरण (Vehicle RC & Details)
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-slate-400 text-[10px] block mb-0.5">वाहन प्रकार</label>
                      <select
                        value={kycForm.vehicleType}
                        onChange={(e) =>
                          setKycForm({ ...kycForm, vehicleType: e.target.value as VehicleType })
                        }
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                      >
                        <option value="bike">Bike (बाइक)</option>
                        <option value="auto">Auto (ऑटो)</option>
                        <option value="eriksha">E-Riksha (ई-रिक्शा)</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-slate-400 text-[10px] block mb-0.5">गाड़ी नंबर (RC Plate)</label>
                      <input
                        type="text"
                        required
                        value={kycForm.vehiclePlate}
                        onChange={(e) => setKycForm({ ...kycForm, vehiclePlate: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono uppercase focus:outline-none focus:border-amber-400"
                        placeholder="RJ-02-SB-4819"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-slate-400 text-[10px] block mb-0.5">गाड़ी मॉडल (Make & Model)</label>
                    <input
                      type="text"
                      required
                      value={kycForm.vehicleModel}
                      onChange={(e) => setKycForm({ ...kycForm, vehicleModel: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                      placeholder="Hero Splendor Plus (BS6)"
                    />
                  </div>
                </div>

                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                  <label className="text-slate-300 font-bold block">
                    4. आपातकालीन विवरण (Emergency & Medical)
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-slate-400 text-[10px] block mb-0.5">ब्लड ग्रुप (Blood Group)</label>
                      <select
                        value={kycForm.bloodGroup}
                        onChange={(e) => setKycForm({ ...kycForm, bloodGroup: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-400 font-mono"
                      >
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-slate-400 text-[10px] block mb-0.5">इमरजेंसी मोबाइल नंबर</label>
                      <input
                        type="text"
                        required
                        value={kycForm.emergencyContact}
                        onChange={(e) => setKycForm({ ...kycForm, emergencyContact: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-amber-400"
                        placeholder="+91 70236 08919"
                      />
                    </div>
                  </div>
                </div>

                <button
                  type="submit"
                  id="btn-submit-kyc"
                  className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-amber-400 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black rounded-xl text-xs shadow-lg mt-2 flex items-center justify-center gap-2 active:scale-98 transition-all"
                >
                  <UploadCloud className="w-4 h-4" />
                  <span>दस्तावेज़ जमा करें (Submit All Documents to Admin)</span>
                </button>
              </form>
            </div>
          </div>
        )}
      </div>

      <footer className="flex-shrink-0 bg-slate-900 border-t border-slate-800 px-4 py-2 text-center text-[10px] text-slate-400">
        <span className="text-amber-400 font-bold">{FOUNDER_TAGLINE}</span> • Support:{' '}
        <a href={`mailto:${SUPPORT_EMAIL}`} className="text-amber-400 underline">
          {SUPPORT_EMAIL}
        </a>
      </footer>
    </div>
  );
};
