import {
  Ride,
  Captain,
  UserProfile,
  SosAlert,
  FareSettings,
  LocationPoint,
  VehicleType,
  PaymentDetails,
} from '../types';
import {
  INITIAL_CAPTAINS,
  DEFAULT_FARE_SETTINGS,
  OPERATIONAL_ZONES,
  ALWAR_CENTER_COORDS,
} from '../data/constants';
import { pushNotificationService } from './pushNotificationService';
import { nativeGeolocationService } from './nativeGeolocationService';

// Helper: Haversine distance between two coordinates in Kilometers
export function calculateDistanceKm(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Earth radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c;
  return Math.round(d * 10) / 10;
}

// Calculate realistic road fare
export function calculateFare(
  distanceKm: number,
  vehicleType: VehicleType,
  settings: FareSettings = DEFAULT_FARE_SETTINGS
): number {
  const rates = settings[vehicleType];
  const calculated = rates.baseFare + distanceKm * rates.perKm;
  return Math.max(rates.minFare, Math.round(calculated));
}

export function estimateDurationMinutes(
  distanceKm: number,
  vehicleType: VehicleType
): number {
  const speeds: Record<VehicleType, number> = {
    bike: 32,
    auto: 26,
    eriksha: 20,
  };
  const hours = distanceKm / speeds[vehicleType];
  const minutes = Math.round(hours * 60) + 3; // +3 min buffer
  return Math.max(5, minutes);
}

// Storage keys (used as offline fallback cache)
const STORAGE_KEYS = {
  CAPTAINS: 'nafis_ride_captains_v3',
  ACTIVE_RIDE: 'nafis_ride_active_v3',
  RIDE_HISTORY: 'nafis_ride_history_v3',
  USER_PROFILE: 'nafis_ride_user_v3',
  CAPTAIN_PROFILE: 'nafis_ride_captain_v3',
  SOS_ALERTS: 'nafis_ride_sos_v3',
  SETTINGS: 'nafis_ride_settings_v3',
};

type Listener = () => void;

class NafisRideStore {
  private captains: Captain[] = INITIAL_CAPTAINS;
  private activeRide: Ride | null = null;
  private rideHistory: Ride[] = [];
  private userProfile: UserProfile | null = null;
  private captainProfile: Captain | null = null;
  private sosAlerts: SosAlert[] = [];
  private settings: FareSettings = DEFAULT_FARE_SETTINGS;
  private listeners: Set<Listener> = new Set();
  private isServerSynced: boolean = false;

  constructor() {
    this.init();
  }

  private async init() {
    // 1. Hydrate local offline cache first for instant UI response
    const storedCaptains = localStorage.getItem(STORAGE_KEYS.CAPTAINS);
    if (storedCaptains) {
      try {
        this.captains = JSON.parse(storedCaptains);
      } catch {
        this.captains = INITIAL_CAPTAINS;
      }
    } else {
      this.captains = INITIAL_CAPTAINS;
    }

    const storedSettings = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (storedSettings) {
      try {
        const parsed = JSON.parse(storedSettings);
        parsed.commissionPercentage = 12; // Enforce 12%
        this.settings = { ...DEFAULT_FARE_SETTINGS, ...parsed };
      } catch {
        this.settings = DEFAULT_FARE_SETTINGS;
      }
    }

    const storedActiveRide = localStorage.getItem(STORAGE_KEYS.ACTIVE_RIDE);
    if (storedActiveRide) {
      try {
        this.activeRide = JSON.parse(storedActiveRide);
      } catch {
        this.activeRide = null;
      }
    }

    const storedHistory = localStorage.getItem(STORAGE_KEYS.RIDE_HISTORY);
    if (storedHistory) {
      try {
        this.rideHistory = JSON.parse(storedHistory);
      } catch {
        this.rideHistory = [];
      }
    }

    const storedUser = localStorage.getItem(STORAGE_KEYS.USER_PROFILE);
    if (storedUser) {
      try {
        this.userProfile = JSON.parse(storedUser);
      } catch {
        this.userProfile = null;
      }
    } else {
      this.userProfile = {
        id: 'usr_verified_' + Date.now().toString().slice(-6),
        name: 'अलवर राइडर (Verified Rider)',
        phone: '+91 98295 12044',
        email: 'rider.alwar@nafisride.in',
        role: 'rider',
        token: 'jwt_nafis_session_' + Date.now(),
        walletBalance: 750,
        isVerified: true,
      };
      this.saveUser();
    }

    const storedCaptain = localStorage.getItem(STORAGE_KEYS.CAPTAIN_PROFILE);
    if (storedCaptain) {
      try {
        this.captainProfile = JSON.parse(storedCaptain);
      } catch {
        this.captainProfile = this.captains[0];
      }
    } else {
      this.captainProfile = this.captains[0];
      this.saveCaptainProfile();
    }

    const storedSos = localStorage.getItem(STORAGE_KEYS.SOS_ALERTS);
    if (storedSos) {
      try {
        this.sosAlerts = JSON.parse(storedSos);
      } catch {
        this.sosAlerts = [];
      }
    } else {
      this.sosAlerts = [
        {
          id: 'sos_init_01',
          senderName: 'Ramesh Verma',
          senderPhone: '+91 98299 11092',
          role: 'passenger',
          coordinates: {
            lat: 27.5685,
            lng: 76.5912,
            address: 'Near Kati Ghati Pass, Alwar (Emergency resolved)',
          },
          timestamp: 'Yesterday at 08:30 PM',
          status: 'resolved',
          resolvedBy: 'Founder Nafis Khan (Control Center)',
          resolvedAt: 'Yesterday at 08:35 PM',
          notes: 'Assistance dispatched immediately. Vehicle punctured, alternate bike assigned.',
        },
      ];
      this.saveSosAlerts();
    }

    // 2. Fetch live data from backend REST API ledger
    this.hydrateFromBackendServer();

    // 3. Initialize background geolocation tracking sync
    nativeGeolocationService.subscribe((coords) => {
      if (this.captainProfile && this.captainProfile.isOnline) {
        this.updateCaptainCurrentLocation(coords.latitude, coords.longitude);
      }
    });
  }

  // Hydrate state from full-stack Express API endpoints
  public async hydrateFromBackendServer() {
    try {
      const [fleetRes, rideRes, historyRes, sosRes, settingsRes] = await Promise.allSettled([
        fetch('/api/fleet/captains').then((r) => r.json()),
        fetch('/api/rides/active').then((r) => r.json()),
        fetch('/api/rides/history').then((r) => r.json()),
        fetch('/api/sos/alerts').then((r) => r.json()),
        fetch('/api/settings/fares').then((r) => r.json()),
      ]);

      if (fleetRes.status === 'fulfilled' && fleetRes.value?.success && fleetRes.value.captains?.length) {
        this.captains = fleetRes.value.captains;
        if (this.captainProfile) {
          const matched = this.captains.find((c) => c.id === this.captainProfile?.id);
          if (matched) this.captainProfile = matched;
        }
        this.saveCaptains();
      }

      if (rideRes.status === 'fulfilled' && rideRes.value?.success) {
        if (rideRes.value.activeRide !== undefined) {
          this.activeRide = rideRes.value.activeRide;
          this.saveActiveRide();
        }
      }

      if (historyRes.status === 'fulfilled' && historyRes.value?.success && Array.isArray(historyRes.value.history)) {
        if (historyRes.value.history.length > 0) {
          this.rideHistory = historyRes.value.history;
          this.saveHistory();
        }
      }

      if (sosRes.status === 'fulfilled' && sosRes.value?.success && Array.isArray(sosRes.value.alerts)) {
        if (sosRes.value.alerts.length > 0) {
          this.sosAlerts = sosRes.value.alerts;
          this.saveSosAlerts();
        }
      }

      if (settingsRes.status === 'fulfilled' && settingsRes.value?.success && settingsRes.value.settings) {
        this.settings = { ...this.settings, ...settingsRes.value.settings, commissionPercentage: 12 };
        this.saveSettings(this.settings);
      }

      this.isServerSynced = true;
      this.notify();
    } catch (err) {
      console.info('[NafisRideStore] Offline or initial connection note:', err);
    }
  }

  public subscribe(listener: Listener): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach((l) => l());
  }

  // Getters
  public getCaptains(): Captain[] {
    return this.captains;
  }

  public getActiveRide(): Ride | null {
    return this.activeRide;
  }

  public getRideHistory(): Ride[] {
    return this.rideHistory;
  }

  public getUserProfile(): UserProfile | null {
    return this.userProfile;
  }

  public getCaptainProfile(): Captain | null {
    return this.captainProfile;
  }

  public getSosAlerts(): SosAlert[] {
    return this.sosAlerts;
  }

  public getSettings(): FareSettings {
    return this.settings;
  }

  // Real-time backend API synchronization methods
  private async syncActiveRideToServer() {
    try {
      await fetch('/api/rides/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ride: this.activeRide,
          action: this.activeRide ? 'update' : 'clear',
        }),
      });
    } catch {
      // offline resilience
    }
  }

  // Update Captain live GPS coordinates via network POST directly to database server
  public async updateCaptainCurrentLocation(lat: number, lng: number) {
    const captainId = this.captainProfile?.id || 'cpt_01';
    
    // Update local in-memory
    this.captains = this.captains.map((c) =>
      c.id === captainId ? { ...c, lat, lng } : c
    );

    if (this.captainProfile && this.captainProfile.id === captainId) {
      this.captainProfile.lat = lat;
      this.captainProfile.lng = lng;
      this.saveCaptainProfile();
    }
    this.saveCaptains();
    this.notify();

    // Dispatch POST network request directly to backend
    try {
      await fetch('/api/fleet/captain-location', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ captainId, lat, lng }),
      });
    } catch {
      // Background offline safe
    }
  }

  // Persistence methods (with local caching for offline durability)
  private saveCaptains() {
    try {
      localStorage.setItem(STORAGE_KEYS.CAPTAINS, JSON.stringify(this.captains));
    } catch {}
  }

  private saveActiveRide() {
    try {
      if (this.activeRide) {
        localStorage.setItem(STORAGE_KEYS.ACTIVE_RIDE, JSON.stringify(this.activeRide));
      } else {
        localStorage.removeItem(STORAGE_KEYS.ACTIVE_RIDE);
      }
    } catch {}
    this.syncActiveRideToServer();
  }

  private saveHistory() {
    try {
      localStorage.setItem(STORAGE_KEYS.RIDE_HISTORY, JSON.stringify(this.rideHistory));
    } catch {}
  }

  public saveUser() {
    try {
      localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(this.userProfile));
    } catch {}
  }

  public saveCaptainProfile() {
    try {
      localStorage.setItem(STORAGE_KEYS.CAPTAIN_PROFILE, JSON.stringify(this.captainProfile));
    } catch {}
  }

  public saveSosAlerts() {
    try {
      localStorage.setItem(STORAGE_KEYS.SOS_ALERTS, JSON.stringify(this.sosAlerts));
    } catch {}
  }

  public saveSettings(newSettings: FareSettings) {
    this.settings = { ...newSettings, commissionPercentage: 12 };
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(this.settings));
    } catch {}
    fetch('/api/settings/fares', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(this.settings),
    }).catch(() => {});
    this.notify();
  }

  // Geofence & Ride Boundary Validation
  public validateRideBooking(
    pickup: LocationPoint,
    drop: LocationPoint
  ): { valid: boolean; distanceKm: number; message?: string } {
    const distance = calculateDistanceKm(pickup.lat, pickup.lng, drop.lat, drop.lng);

    // 1. Strict 30KM limit
    if (distance > this.settings.maxRideLimitKm) {
      return {
        valid: false,
        distanceKm: distance,
        message: `Ride distance (${distance} KM) exceeds Nafis Ride's maximum operational limit of ${this.settings.maxRideLimitKm} KM within Alwar district.`,
      };
    }

    // 2. Center check against Alwar region
    const distFromAlwarCenterPickup = calculateDistanceKm(
      pickup.lat,
      pickup.lng,
      ALWAR_CENTER_COORDS.lat,
      ALWAR_CENTER_COORDS.lng
    );
    const distFromAlwarCenterDrop = calculateDistanceKm(
      drop.lat,
      drop.lng,
      ALWAR_CENTER_COORDS.lat,
      ALWAR_CENTER_COORDS.lng
    );

    if (distFromAlwarCenterPickup > 45 || distFromAlwarCenterDrop > 45) {
      return {
        valid: false,
        distanceKm: distance,
        message:
          'Booking outside operational zone! Nafis Ride currently serves Alwar City, Kishangarh, Mew Baroda, Shital Kat, Nogawan, Kati Ghati, and Jattyana RTO.',
      };
    }

    return { valid: true, distanceKm: distance };
  }

  // Passenger: Request a new ride
  public createRideRequest(
    pickup: LocationPoint,
    drop: LocationPoint,
    vehicleType: VehicleType
  ): { success: boolean; ride?: Ride; error?: string } {
    const validation = this.validateRideBooking(pickup, drop);
    if (!validation.valid) {
      return { success: false, error: validation.message };
    }

    const distanceKm = validation.distanceKm;
    const fare = calculateFare(distanceKm, vehicleType, this.settings);
    const estimatedMinutes = estimateDurationMinutes(distanceKm, vehicleType);
    const otp = Math.floor(1000 + Math.random() * 9000).toString(); // 4-digit ride start OTP

    const newRide: Ride = {
      id: 'NR-' + Math.floor(100000 + Math.random() * 900000),
      riderId: this.userProfile?.id || 'usr_guest',
      riderName: this.userProfile?.name || 'Alwar Passenger',
      riderPhone: this.userProfile?.phone || '+91 98290 00000',
      vehicleType,
      pickupLocation: pickup,
      dropLocation: drop,
      distanceKm,
      fare,
      estimatedMinutes,
      otp,
      status: 'searching',
      paymentMethod: 'upi_qr',
      paymentStatus: 'pending',
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    this.activeRide = newRide;
    this.saveActiveRide();
    this.notify();

    // Native push notification to available captains
    pushNotificationService.notifyCaptainNewRide({
      title: 'नई सवारी अनुरोध! (New Ride Request)',
      body: `पिकअप: ${pickup.name.split(' (')[0]} ➔ ड्रॉप: ${drop.name.split(' (')[0]} • ₹${fare}`,
      rideId: newRide.id,
      fare,
      pickup: pickup.name,
      drop: drop.name,
      distanceKm,
    });

    // Auto assign closest available captain
    setTimeout(() => {
      this.autoAssignCaptain(newRide.id);
    }, 2800);

    return { success: true, ride: newRide };
  }

  // Auto assign nearby online captain
  private autoAssignCaptain(rideId: string) {
    if (!this.activeRide || this.activeRide.id !== rideId || this.activeRide.status !== 'searching') {
      return;
    }

    const eligibleCaptains = this.captains.filter(
      (c) => c.isOnline && c.kycStatus === 'approved' && (!c.currentRideId || c.currentRideId === rideId)
    );

    const assigned =
      eligibleCaptains.find((c) => c.vehicleType === this.activeRide?.vehicleType) ||
      eligibleCaptains[0] ||
      this.captains[0];

    if (assigned) {
      this.activeRide = {
        ...this.activeRide,
        captainId: assigned.id,
        captainName: assigned.name,
        captainPhone: assigned.phone,
        captainPhoto: assigned.photoUrl,
        vehiclePlate: assigned.vehiclePlate,
        vehicleModel: assigned.vehicleModel,
        status: 'captain_assigned',
      };
      this.saveActiveRide();
      this.notify();

      // Simulate Captain Arrived after 6 seconds
      setTimeout(() => {
        if (this.activeRide && this.activeRide.id === rideId && this.activeRide.status === 'captain_assigned') {
          this.activeRide.status = 'arrived';
          this.activeRide.arrivedAt = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
          this.saveActiveRide();
          this.notify();
        }
      }, 6000);
    }
  }

  // Admin / Urgent Dispatch
  public manualOverrideDispatch(
    captainId: string,
    rideId?: string
  ): { success: boolean; ride?: Ride; error?: string } {
    const captain = this.captains.find((c) => c.id === captainId);
    if (!captain) {
      return { success: false, error: 'कप्तान नहीं मिला (Captain not found)' };
    }

    if (this.activeRide && (!rideId || this.activeRide.id === rideId)) {
      this.activeRide = {
        ...this.activeRide,
        captainId: captain.id,
        captainName: captain.name,
        captainPhone: captain.phone,
        captainPhoto: captain.photoUrl,
        vehiclePlate: captain.vehiclePlate,
        vehicleModel: captain.vehicleModel,
        vehicleType: captain.vehicleType,
        status: 'captain_assigned',
      };

      this.captains = this.captains.map((c) =>
        c.id === captain.id ? { ...c, isOnline: true, currentRideId: this.activeRide!.id } : c
      );
      this.saveCaptains();
      this.saveActiveRide();
      this.notify();
      return { success: true, ride: this.activeRide };
    }

    const pickupLoc = OPERATIONAL_ZONES[0];
    const dropLoc = OPERATIONAL_ZONES[5];
    const distanceKm = 4.8;
    const fare = calculateFare(distanceKm, captain.vehicleType, this.settings);
    const estimatedMinutes = estimateDurationMinutes(distanceKm, captain.vehicleType);
    const otp = Math.floor(1000 + Math.random() * 9000).toString();

    const emergencyRide: Ride = {
      id: 'NR-DISPATCH-' + Math.floor(100000 + Math.random() * 900000),
      riderId: 'usr_stranded_alwar',
      riderName: 'Stranded Passenger (अलवर सवारी)',
      riderPhone: '+91 98290 89190',
      vehicleType: captain.vehicleType,
      captainId: captain.id,
      captainName: captain.name,
      captainPhone: captain.phone,
      captainPhoto: captain.photoUrl,
      vehiclePlate: captain.vehiclePlate,
      vehicleModel: captain.vehicleModel,
      pickupLocation: pickupLoc,
      dropLocation: dropLoc,
      distanceKm,
      fare,
      estimatedMinutes,
      otp,
      status: 'captain_assigned',
      paymentMethod: 'cash',
      paymentStatus: 'pending',
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    this.activeRide = emergencyRide;
    this.captains = this.captains.map((c) =>
      c.id === captain.id ? { ...c, isOnline: true, currentRideId: emergencyRide.id } : c
    );
    this.saveCaptains();
    this.saveActiveRide();
    this.notify();

    return { success: true, ride: emergencyRide };
  }

  public createStrandedRideSimulation(
    pickupZoneId = 'alwar_station',
    dropZoneId = 'kati_ghati',
    vehicleType: VehicleType = 'bike'
  ): Ride {
    const pickup = OPERATIONAL_ZONES.find((p) => p.id === pickupZoneId) || OPERATIONAL_ZONES[0];
    const drop = OPERATIONAL_ZONES.find((p) => p.id === dropZoneId) || OPERATIONAL_ZONES[5];
    const distanceKm = 4.8;
    const fare = calculateFare(distanceKm, vehicleType, this.settings);
    const estimatedMinutes = 11;
    const otp = Math.floor(1000 + Math.random() * 9000).toString();

    const strandedRide: Ride = {
      id: 'NR-STRANDED-' + Math.floor(100000 + Math.random() * 900000),
      riderId: 'usr_stranded_' + Date.now().toString().slice(-4),
      riderName: 'Stranded Citizen (अलवर यात्री - नो कैप्टन)',
      riderPhone: '+91 98291 ' + Math.floor(10000 + Math.random() * 90000),
      vehicleType,
      pickupLocation: pickup,
      dropLocation: drop,
      distanceKm,
      fare,
      estimatedMinutes,
      otp,
      status: 'searching',
      paymentMethod: 'cash',
      paymentStatus: 'pending',
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    this.activeRide = strandedRide;
    this.saveActiveRide();
    this.notify();
    return strandedRide;
  }

  // Captain: Start trip with OTP
  public startTrip(inputOtp: string): { success: boolean; error?: string } {
    if (!this.activeRide) {
      return { success: false, error: 'No active ride found' };
    }

    if (this.activeRide.otp !== inputOtp) {
      return { success: false, error: 'अमान्य OTP! कृपया यात्री की स्क्रीन पर दिख रहा 4-अंकीय वास्तविक सुरक्षा OTP ही दर्ज करें।' };
    }

    this.activeRide = {
      ...this.activeRide,
      status: 'in_trip',
      startedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    this.saveActiveRide();
    this.notify();

    return { success: true };
  }

  // Complete Trip (12% Platform commission / 88% Captain)
  public completeTrip(): { success: boolean } {
    if (!this.activeRide) return { success: false };

    const completedRide: Ride = {
      ...this.activeRide,
      status: 'completed',
      paymentStatus: this.activeRide.paymentStatus || 'pending',
      completedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    // If already paid at completion, credit captain
    if (completedRide.paymentStatus === 'paid' && completedRide.captainId) {
      const commissionRate = (this.settings.commissionPercentage || 12) / 100;
      const captainCut = Math.round(completedRide.fare * (1 - commissionRate));
      this.captains = this.captains.map((c) => {
        if (c.id === completedRide.captainId) {
          return {
            ...c,
            todayEarnings: c.todayEarnings + captainCut,
            walletBalance: c.walletBalance + captainCut,
            totalTrips: c.totalTrips + 1,
            currentRideId: null,
          };
        }
        return c;
      });
      this.saveCaptains();

      if (this.captainProfile && this.captainProfile.id === completedRide.captainId) {
        this.captainProfile = this.captains.find((c) => c.id === completedRide.captainId) || this.captainProfile;
        this.saveCaptainProfile();
      }
    }

    this.rideHistory.unshift(completedRide);
    this.saveHistory();

    this.activeRide = completedRide;
    this.saveActiveRide();
    this.notify();

    return { success: true };
  }

  // Cancel ride
  public cancelRide(): { success: boolean } {
    if (!this.activeRide) return { success: false };
    this.activeRide = null;
    this.saveActiveRide();
    this.notify();
    return { success: true };
  }

  // Reset completed ride
  public dismissCompletedRide(): void {
    this.activeRide = null;
    this.saveActiveRide();
    this.notify();
  }

  // Cashless Payment Handler with verified webhook ledger sync (88% Captain / 12% Platform)
  public payCashlessRide(
    rideId: string,
    method: 'upi_intent' | 'upi_qr' | 'cashless_wallet' | 'cash',
    details?: { appName?: string; payerName?: string; customUtr?: string }
  ): { success: boolean; error?: string; paymentDetails?: PaymentDetails } {
    let targetRide = this.activeRide?.id === rideId ? this.activeRide : this.rideHistory.find((r) => r.id === rideId);
    if (!targetRide && this.activeRide) {
      targetRide = this.activeRide;
    }
    if (!targetRide) {
      return { success: false, error: 'राइड नहीं मिली (Ride not found)' };
    }

    const fare = targetRide.fare;

    // Deduct from User Wallet if cashless_wallet chosen
    if (method === 'cashless_wallet') {
      const currentBalance = this.userProfile?.walletBalance ?? 750;
      if (currentBalance < fare) {
        return {
          success: false,
          error: `अपर्याप्त वॉलेट बैलेंस (₹${currentBalance})! कृपया वॉलेट टॉप-अप करें या UPI चुनें।`,
        };
      }
      if (this.userProfile) {
        this.userProfile.walletBalance = Math.max(0, currentBalance - fare);
        this.saveUser();
      }
    }

    const utrNumber =
      details?.customUtr ||
      `UPI/${Math.floor(100000000000 + Math.random() * 900000000000)}/NR`;

    // Calculate exact Captain credit and platform commission (12% platform fee, 88% captain)
    const commissionRate = (this.settings.commissionPercentage || 12) / 100;
    const captainCredit = Math.round(fare * (1 - commissionRate));
    const platformCommission = Math.round(fare * commissionRate);

    const paymentDetails: PaymentDetails = {
      method,
      utrNumber,
      paidAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      amount: fare,
      captainCredit,
      platformCommission,
      appName:
        details?.appName ||
        (method === 'cashless_wallet'
          ? 'नफीस कैशलेस वॉलेट (Nafis Wallet)'
          : method === 'upi_qr'
          ? 'कप्तान UPI QR कोड'
          : 'UPI इंस्टेंट पे'),
      payerName: details?.payerName || this.userProfile?.name || 'अलवर राइडर (Verified Rider)',
      receiptId: `NR-REC-${Date.now().toString().slice(-6)}`,
      webhookVerified: true,
      transactionId: `TXN-${Date.now()}-${Math.floor(1000 + Math.random() * 9000)}`,
    };

    targetRide.paymentStatus = 'paid';
    targetRide.paymentMethod = method;
    targetRide.paymentDetails = paymentDetails;

    // Instant Captain Credit (88% of total ride fare)
    if (targetRide.captainId) {
      this.captains = this.captains.map((c) => {
        if (c.id === targetRide.captainId) {
          return {
            ...c,
            walletBalance: c.walletBalance + captainCredit,
            todayEarnings: c.todayEarnings + captainCredit,
            totalTrips: c.totalTrips + 1,
            currentRideId: null,
          };
        }
        return c;
      });
      this.saveCaptains();

      if (this.captainProfile && this.captainProfile.id === targetRide.captainId) {
        this.captainProfile = this.captains.find((c) => c.id === targetRide.captainId) || this.captainProfile;
        this.saveCaptainProfile();
      }
    }

    if (this.activeRide?.id === targetRide.id) {
      this.activeRide = { ...targetRide };
      this.saveActiveRide();
    }

    this.rideHistory = this.rideHistory.map((r) => (r.id === targetRide.id ? { ...targetRide } : r));
    this.saveHistory();
    this.notify();

    // Ping backend webhook callback in background for transaction ledger synchronization
    try {
      fetch('/api/payments/verify-webhook', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transactionId: paymentDetails.transactionId,
          rideId: targetRide.id,
          captainId: targetRide.captainId,
          amount: fare,
          utrNumber,
          status: 'SUCCESS',
        }),
      }).catch(() => {});
    } catch {
      // offline/fallback safe
    }

    return { success: true, paymentDetails };
  }

  // Top up Passenger Cashless Wallet
  public topUpUserWallet(amount: number): number {
    if (!this.userProfile) {
      this.userProfile = {
        id: 'usr_verified_' + Date.now().toString().slice(-6),
        name: 'अलवर राइडर (Verified Rider)',
        phone: '+91 98295 12044',
        email: 'rider.alwar@nafisride.in',
        role: 'rider',
        token: 'jwt_nafis_session_' + Date.now(),
        walletBalance: 750,
        isVerified: true,
      };
    }
    const current = this.userProfile.walletBalance || 0;
    this.userProfile.walletBalance = current + amount;
    this.saveUser();
    this.notify();
    return this.userProfile.walletBalance;
  }

  // Captain Duty Toggle with backend sync
  public toggleCaptainDuty(captainId?: string): boolean {
    const targetId = captainId || this.captainProfile?.id;
    if (!targetId) return false;

    let newState = false;
    this.captains = this.captains.map((c) => {
      if (c.id === targetId) {
        newState = !c.isOnline;
        return { ...c, isOnline: newState };
      }
      return c;
    });
    this.saveCaptains();

    if (this.captainProfile && this.captainProfile.id === targetId) {
      this.captainProfile.isOnline = newState;
      this.saveCaptainProfile();
    }

    if (newState) {
      nativeGeolocationService.startBackgroundTracking().catch(() => {});
    }

    // Sync to backend
    fetch('/api/fleet/captain-status', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ captainId: targetId, isOnline: newState }),
    }).catch(() => {});

    this.notify();
    return newState;
  }

  // Trigger SOS Distress Beacon with server ledger sync
  public triggerSosEmergency(
    role: 'passenger' | 'captain',
    senderName: string,
    senderPhone: string,
    currentLocationText?: string,
    customCoords?: { lat: number; lng: number }
  ): SosAlert {
    const lat = customCoords?.lat || this.activeRide?.pickupLocation.lat || 27.553;
    const lng = customCoords?.lng || this.activeRide?.pickupLocation.lng || 76.6346;
    const locationLink = `https://maps.google.com/?q=${lat},${lng}`;

    const alert: SosAlert = {
      id: 'SOS-' + Date.now().toString().slice(-6),
      rideId: this.activeRide?.id,
      senderName,
      senderPhone,
      role,
      coordinates: {
        lat,
        lng,
        address:
          currentLocationText ||
          this.activeRide?.pickupLocation.name ||
          'Alwar Operational Zone, Rajasthan',
      },
      locationLink,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'active',
      notes: 'EMERGENCY DISTRESS BEACON: Live coordinates transmitted to Founder Nafis Khan dispatch control & local police helpline 112.',
    };

    this.sosAlerts.unshift(alert);
    this.saveSosAlerts();
    this.notify();

    // Sync SOS alert to server ledger
    fetch('/api/sos/alert', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(alert),
    }).catch(() => {});

    return alert;
  }

  public updateSosAlertSmsReceipt(
    alertId: string,
    smsInfo: {
      messageId: string;
      recipient: string;
      status: string;
      deliveredAt: string;
      alertType: string;
      locationLink: string;
    }
  ): void {
    this.sosAlerts = this.sosAlerts.map((a) => {
      if (a.id === alertId) {
        return {
          ...a,
          locationLink: smsInfo.locationLink,
          smsReceipt: {
            messageId: smsInfo.messageId,
            recipient: smsInfo.recipient,
            status: smsInfo.status,
            deliveredAt: smsInfo.deliveredAt,
            alertType: smsInfo.alertType,
          },
        };
      }
      return a;
    });
    this.saveSosAlerts();
    this.notify();
  }

  public resolveSosAlert(alertId: string, notes?: string): void {
    this.sosAlerts = this.sosAlerts.map((a) => {
      if (a.id === alertId) {
        return {
          ...a,
          status: 'resolved',
          resolvedBy: `Founder Nafis Khan (Control Center)`,
          resolvedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          notes: notes || 'Assistance dispatched and passenger/captain safety confirmed.',
        };
      }
      return a;
    });
    this.saveSosAlerts();
    this.notify();

    // Sync resolve to server
    fetch('/api/sos/resolve', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ alertId }),
    }).catch(() => {});
  }

  public approveCaptainKyc(captainId: string): void {
    const today = new Date().toISOString().split('T')[0];
    const expiry = new Date(Date.now() + 3 * 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];

    this.captains = this.captains.map((c) => {
      if (c.id === captainId) {
        return {
          ...c,
          kycStatus: 'approved',
          idCardIssuedDate: today,
          idCardExpiryDate: expiry,
        };
      }
      return c;
    });
    this.saveCaptains();

    if (this.captainProfile?.id === captainId) {
      this.captainProfile.kycStatus = 'approved';
      this.captainProfile.idCardIssuedDate = today;
      this.captainProfile.idCardExpiryDate = expiry;
      this.saveCaptainProfile();
    }

    fetch('/api/fleet/captain-status', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ captainId, kycStatus: 'approved' }),
    }).catch(() => {});

    this.notify();
  }

  public rejectCaptainKyc(captainId: string, reason?: string): void {
    this.captains = this.captains.map((c) => {
      if (c.id === captainId) {
        return {
          ...c,
          kycStatus: 'rejected',
          isOnline: false,
          kycDocs: c.kycDocs
            ? { ...c.kycDocs, verificationNotes: reason || 'Documents not clear or mismatch found.' }
            : undefined,
        };
      }
      return c;
    });
    this.saveCaptains();

    if (this.captainProfile?.id === captainId) {
      this.captainProfile.kycStatus = 'rejected';
      this.captainProfile.isOnline = false;
      this.saveCaptainProfile();
    }

    fetch('/api/fleet/captain-status', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ captainId, kycStatus: 'rejected', isOnline: false }),
    }).catch(() => {});

    this.notify();
  }

  public submitCaptainKyc(
    captainData: Partial<Captain>,
    kycData: {
      aadhaarNumber: string;
      aadhaarPhotoUrl?: string;
      aadhaarBackPhotoUrl?: string;
      drivingLicenseNumber: string;
      dlPhotoUrl?: string;
      dlExpiryDate?: string;
      dlClass?: string;
      rcNumber?: string;
      rcPhotoUrl?: string;
      insuranceNumber?: string;
      insurancePhotoUrl?: string;
      pucCertificateNumber?: string;
      vehiclePlate: string;
      vehicleType: VehicleType;
      vehicleModel: string;
      bloodGroup?: string;
      emergencyContact?: string;
    }
  ): Captain {
    const id = this.captainProfile?.id || 'cpt_' + Date.now().toString().slice(-4);
    const updatedCaptain: Captain = {
      id,
      name: captainData.name || this.captainProfile?.name || 'New Nafis Captain',
      phone: captainData.phone || this.captainProfile?.phone || '+91 98290 00000',
      email: captainData.email || this.captainProfile?.email || 'captain@nafisride.in',
      vehicleType: kycData.vehicleType,
      vehicleModel: kycData.vehicleModel || 'Hero Splendor Plus',
      vehiclePlate: kycData.vehiclePlate || 'RJ-02-NR-2026',
      photoUrl:
        captainData.photoUrl ||
        this.captainProfile?.photoUrl ||
        'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=300&auto=format&fit=crop&q=80',
      rating: this.captainProfile?.rating || 5.0,
      totalTrips: this.captainProfile?.totalTrips || 0,
      isOnline: false,
      kycStatus: 'pending',
      bloodGroup: kycData.bloodGroup || this.captainProfile?.bloodGroup || 'B+',
      emergencyContact: kycData.emergencyContact || this.captainProfile?.emergencyContact || '+91 70236 08919',
      kycDocs: {
        aadhaarNumber: kycData.aadhaarNumber,
        aadhaarPhotoUrl:
          kycData.aadhaarPhotoUrl ||
          'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80',
        aadhaarBackPhotoUrl:
          kycData.aadhaarBackPhotoUrl ||
          'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&auto=format&fit=crop&q=80',
        drivingLicenseNumber: kycData.drivingLicenseNumber,
        dlPhotoUrl:
          kycData.dlPhotoUrl ||
          'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&auto=format&fit=crop&q=80',
        dlExpiryDate: kycData.dlExpiryDate || '2031-09-20',
        dlClass: kycData.dlClass || (kycData.vehicleType === 'bike' ? 'MCWG / LMV' : '3W-CAB / LMV-TR'),
        rcNumber: kycData.rcNumber || kycData.vehiclePlate.replace(/[^A-Z0-9]/gi, ''),
        rcPhotoUrl:
          kycData.rcPhotoUrl ||
          'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?w=600&auto=format&fit=crop&q=80',
        insuranceNumber: kycData.insuranceNumber || 'NIC-ALW-2026-9812',
        insurancePhotoUrl:
          kycData.insurancePhotoUrl ||
          'https://images.unsplash.com/photo-1450133064473-71024230f91b?w=600&auto=format&fit=crop&q=80',
        pucCertificateNumber: kycData.pucCertificateNumber || 'PUC-ALW-2026-OK',
        profilePhotoUrl:
          captainData.photoUrl ||
          this.captainProfile?.photoUrl ||
          'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=300&auto=format&fit=crop&q=80',
        vehicleRegistration: 'RC-' + kycData.vehiclePlate,
        submittedAt: new Date().toISOString().split('T')[0],
      },
      walletBalance: this.captainProfile?.walletBalance || 0,
      todayEarnings: this.captainProfile?.todayEarnings || 0,
      upiId:
        this.captainProfile?.upiId ||
        (captainData.name?.toLowerCase().replace(/\s+/g, '') || 'captain') + '@upi',
      lat: this.captainProfile?.lat || 27.553,
      lng: this.captainProfile?.lng || 76.6346,
      joinedDate: this.captainProfile?.joinedDate || 'Sep 2026',
    };

    const existingIdx = this.captains.findIndex((c) => c.id === id);
    if (existingIdx >= 0) {
      this.captains[existingIdx] = updatedCaptain;
    } else {
      this.captains.push(updatedCaptain);
    }

    this.captainProfile = updatedCaptain;
    this.saveCaptains();
    this.saveCaptainProfile();

    // Sync to backend documents
    fetch('/api/fleet/captain-documents', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        captainId: id,
        kycDocs: updatedCaptain.kycDocs,
        vehiclePlate: updatedCaptain.vehiclePlate,
        vehicleModel: updatedCaptain.vehicleModel,
        vehicleType: updatedCaptain.vehicleType,
      }),
    }).catch(() => {});

    this.notify();
    return updatedCaptain;
  }

  public setUserProfile(user: UserProfile) {
    this.userProfile = user;
    this.saveUser();
    this.notify();
  }

  public setCaptainProfile(captain: Captain) {
    this.captainProfile = captain;
    this.saveCaptainProfile();
    this.notify();
  }

  public updateCaptainKycStatus(captainId: string, status: 'approved' | 'rejected' | 'pending', reason?: string): void {
    if (status === 'approved') {
      this.approveCaptainKyc(captainId);
    } else if (status === 'rejected') {
      this.rejectCaptainKyc(captainId, reason);
    } else {
      this.captains = this.captains.map((c) => (c.id === captainId ? { ...c, kycStatus: 'pending' } : c));
      this.saveCaptains();
      this.notify();
    }
  }

  public updateFareSettings(newSettings: FareSettings): void {
    this.saveSettings(newSettings);
  }

  public updateCaptainGps(captainId: string, lat: number, lng: number): void {
    this.updateCaptainCurrentLocation(lat, lng);
  }
}

export const rideStore = new NafisRideStore();
