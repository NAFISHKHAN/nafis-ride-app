// Audio & Speech Synthesizer for localized Hindi Shayari alerts & chimes

class AudioService {
  private isMuted: boolean = false;
  private audioCtx: AudioContext | null = null;
  private currentUtterance: SpeechSynthesisUtterance | null = null;

  constructor() {
    // Lazy AudioContext to respect browser autoplay policies
  }

  private getAudioContext(): AudioContext {
    if (!this.audioCtx) {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new AudioContextClass();
    }
    if (this.audioCtx.state === 'suspended') {
      this.audioCtx.resume();
    }
    return this.audioCtx;
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    if (this.isMuted && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    return this.isMuted;
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  // Play pleasant acoustic chime
  public playChime(type: 'welcome' | 'booked' | 'milestone' | 'completed' | 'cash' | 'sos' = 'milestone') {
    if (this.isMuted) return;

    try {
      const ctx = this.getAudioContext();
      const now = ctx.currentTime;

      if (type === 'sos') {
        // High-urgency alert siren
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(880, now);
        osc.frequency.linearRampToValueAtTime(440, now + 0.3);
        osc.frequency.linearRampToValueAtTime(880, now + 0.6);
        osc.frequency.linearRampToValueAtTime(440, now + 0.9);

        gain.gain.setValueAtTime(0.3, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 1.2);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 1.2);
        return;
      }

      if (type === 'cash') {
        // Register ding
        const osc1 = ctx.createOscillator();
        const osc2 = ctx.createOscillator();
        const gain = ctx.createGain();

        osc1.type = 'sine';
        osc2.type = 'triangle';
        osc1.frequency.setValueAtTime(987.77, now); // B5
        osc2.frequency.setValueAtTime(1318.51, now + 0.08); // E6

        gain.gain.setValueAtTime(0.2, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);

        osc1.connect(gain);
        osc2.connect(gain);
        gain.connect(ctx.destination);

        osc1.start(now);
        osc1.stop(now + 0.3);
        osc2.start(now + 0.08);
        osc2.stop(now + 0.6);
        return;
      }

      // Melodic arpeggio for Shayari announcements
      const freqs =
        type === 'welcome'
          ? [523.25, 659.25, 783.99, 1046.5] // C Major fanfare
          : type === 'completed'
          ? [440, 554.37, 659.25, 880] // A Major celebratory
          : [587.33, 739.99, 880]; // D Major prompt

      freqs.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.1);

        gain.gain.setValueAtTime(0.15, now + idx * 0.1);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.1 + 0.5);

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.start(now + idx * 0.1);
        osc.stop(now + idx * 0.1 + 0.5);
      });
    } catch {
      // AudioContext might be blocked until user gesture
    }
  }

  // Speak Shayari using Web Speech API with authentic Hindi voice preference
  public speakShayari(text: string, onEnd?: () => void): void {
    if (this.isMuted) return;

    // First play melodic chime
    this.playChime('milestone');

    if (!('speechSynthesis' in window)) {
      if (onEnd) onEnd();
      return;
    }

    try {
      window.speechSynthesis.cancel(); // cancel any active speech

      const utterance = new SpeechSynthesisUtterance(text);
      this.currentUtterance = utterance;

      // Find Hindi voice if available
      const voices = window.speechSynthesis.getVoices();
      const hindiVoice = voices.find(
        (v) =>
          v.lang.startsWith('hi') ||
          v.lang.includes('IN') ||
          v.name.toLowerCase().includes('hindi') ||
          v.name.toLowerCase().includes('india'),
      );

      if (hindiVoice) {
        utterance.voice = hindiVoice;
        utterance.lang = hindiVoice.lang;
      } else {
        utterance.lang = 'hi-IN';
      }

      utterance.rate = 0.92; // slightly measured, poetic pace
      utterance.pitch = 1.05;
      utterance.volume = 1.0;

      utterance.onend = () => {
        this.currentUtterance = null;
        if (onEnd) onEnd();
      };

      utterance.onerror = () => {
        this.currentUtterance = null;
        if (onEnd) onEnd();
      };

      // Slight delay so chime finishes gracefully
      setTimeout(() => {
        window.speechSynthesis.speak(utterance);
      }, 350);
    } catch {
      if (onEnd) onEnd();
    }
  }

  public stopSpeaking(): void {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
  }
}

export const audioService = new AudioService();
