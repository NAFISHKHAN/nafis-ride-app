/**
 * Native Push Notification Service for Nafis Ride
 * Uses @capacitor/push-notifications to alert KYC-approved Captains in Alwar
 * when an unassigned ride is triggered.
 */

import { PushNotifications, Token, ActionPerformed, PushNotificationSchema } from '@capacitor/push-notifications';
import { audioService } from './audioService';

export interface PushNotificationPayload {
  title: string;
  body: string;
  rideId: string;
  fare: number;
  pickup: string;
  drop: string;
  distanceKm: number;
}

type PushActionListener = (action: ActionPerformed) => void;

class PushNotificationService {
  private deviceToken: string | null = null;
  private actionListeners: Set<PushActionListener> = new Set();
  private isInitialized = false;

  public async initialize(): Promise<boolean> {
    if (this.isInitialized) return true;

    try {
      // 1. Request permission
      let permStatus = await PushNotifications.checkPermissions();
      if (permStatus.receive === 'prompt') {
        permStatus = await PushNotifications.requestPermissions();
      }

      if (permStatus.receive !== 'granted') {
        console.warn('[Push Notification Service] Permission denied');
        return false;
      }

      // 2. Register with Apple / Google APNS / FCM
      await PushNotifications.register();

      // 3. Setup Listeners
      await PushNotifications.addListener('registration', (token: Token) => {
        this.deviceToken = token.value;
        console.log('[Push Notification Service] Registered token:', token.value);
      });

      await PushNotifications.addListener('registrationError', (error: unknown) => {
        console.warn('[Push Notification Service] Registration error:', error);
      });

      await PushNotifications.addListener('pushNotificationReceived', (notification: PushNotificationSchema) => {
        console.log('[Push Notification Service] Received foreground notification:', notification);
        audioService.playChime('booked');
      });

      await PushNotifications.addListener('pushNotificationActionPerformed', (action: ActionPerformed) => {
        console.log('[Push Notification Service] Action performed:', action);
        this.actionListeners.forEach((fn) => fn(action));
      });

      this.isInitialized = true;
      return true;
    } catch (err) {
      console.warn('[Push Notification Service] Native push not available in web preview:', err);
      return false;
    }
  }

  public async initializePushNotifications(): Promise<boolean> {
    return this.initialize();
  }

  public onAction(listener: PushActionListener): () => void {
    this.actionListeners.add(listener);
    return () => this.actionListeners.delete(listener);
  }

  public getDeviceToken(): string | null {
    return this.deviceToken;
  }

  /**
   * Dispatches instant high-priority native notification to Captains in Alwar
   */
  public notifyCaptainNewRide(payload: PushNotificationPayload): void {
    console.log('[Push Notifications] Dispatching high-priority ride alert to Alwar Captains:', payload);

    // If native device notification API is available (e.g. Capacitor Local Notification or Web Notification)
    if ('Notification' in window && Notification.permission === 'granted') {
      try {
        new Notification(`नफीस राइड: नई सवारी! ₹${payload.fare}`, {
          body: `पिकअप: ${payload.pickup} ➔ ड्रॉप: ${payload.drop} (${payload.distanceKm} KM)`,
          icon: '/public/icon.png',
          badge: '/public/icon.png',
          tag: `ride-${payload.rideId}`,
        });
      } catch {
        // ignore notification constructor failures in some frames
      }
    }

    // Play chime sound
    audioService.playChime('booked');
  }
}

export const pushNotificationService = new PushNotificationService();
